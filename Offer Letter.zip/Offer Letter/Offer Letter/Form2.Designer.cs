﻿namespace Offer_Letter
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.appntlbl = new System.Windows.Forms.Label();
            this.datelbl = new System.Windows.Forms.Label();
            this.tdylbl = new System.Windows.Forms.Label();
            this.addresslbl = new System.Windows.Forms.Label();
            this.wlcmelbl = new System.Windows.Forms.Label();
            this.desglbl2 = new System.Windows.Forms.Label();
            this.dojlbl = new System.Windows.Forms.Label();
            this.dojlbl2 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.slrylbl2 = new System.Windows.Forms.Label();
            this.plcelbl = new System.Windows.Forms.Label();
            this.plcelbl2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.prbtnlbl2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lvelbl2 = new System.Windows.Forms.Label();
            this.lvelbl3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // appntlbl
            // 
            this.appntlbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.appntlbl.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appntlbl.Location = new System.Drawing.Point(0, 0);
            this.appntlbl.Name = "appntlbl";
            this.appntlbl.Size = new System.Drawing.Size(1079, 23);
            this.appntlbl.TabIndex = 0;
            this.appntlbl.Text = "Appointment Letter";
            this.appntlbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // datelbl
            // 
            this.datelbl.AutoSize = true;
            this.datelbl.Location = new System.Drawing.Point(28, 17);
            this.datelbl.Name = "datelbl";
            this.datelbl.Size = new System.Drawing.Size(0, 13);
            this.datelbl.TabIndex = 1;
            this.datelbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tdylbl
            // 
            this.tdylbl.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tdylbl.Location = new System.Drawing.Point(31, 81);
            this.tdylbl.Name = "tdylbl";
            this.tdylbl.Size = new System.Drawing.Size(195, 22);
            this.tdylbl.TabIndex = 2;
            this.tdylbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // addresslbl
            // 
            this.addresslbl.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addresslbl.Location = new System.Drawing.Point(31, 117);
            this.addresslbl.Name = "addresslbl";
            this.addresslbl.Size = new System.Drawing.Size(195, 119);
            this.addresslbl.TabIndex = 3;
            this.addresslbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wlcmelbl
            // 
            this.wlcmelbl.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wlcmelbl.Location = new System.Drawing.Point(31, 265);
            this.wlcmelbl.Name = "wlcmelbl";
            this.wlcmelbl.Size = new System.Drawing.Size(551, 22);
            this.wlcmelbl.TabIndex = 5;
            this.wlcmelbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // desglbl2
            // 
            this.desglbl2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.desglbl2.Location = new System.Drawing.Point(28, 296);
            this.desglbl2.Name = "desglbl2";
            this.desglbl2.Size = new System.Drawing.Size(812, 41);
            this.desglbl2.TabIndex = 6;
            // 
            // dojlbl
            // 
            this.dojlbl.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dojlbl.Location = new System.Drawing.Point(42, 346);
            this.dojlbl.Name = "dojlbl";
            this.dojlbl.Size = new System.Drawing.Size(110, 22);
            this.dojlbl.TabIndex = 7;
            this.dojlbl.Text = "Date of Joining : ";
            this.dojlbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dojlbl2
            // 
            this.dojlbl2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dojlbl2.Location = new System.Drawing.Point(158, 340);
            this.dojlbl2.Name = "dojlbl2";
            this.dojlbl2.Size = new System.Drawing.Size(673, 34);
            this.dojlbl2.TabIndex = 8;
            this.dojlbl2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(42, 388);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 22);
            this.label2.TabIndex = 9;
            this.label2.Text = "Salary : ";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // slrylbl2
            // 
            this.slrylbl2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slrylbl2.Location = new System.Drawing.Point(158, 382);
            this.slrylbl2.Name = "slrylbl2";
            this.slrylbl2.Size = new System.Drawing.Size(673, 34);
            this.slrylbl2.TabIndex = 10;
            this.slrylbl2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // plcelbl
            // 
            this.plcelbl.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plcelbl.Location = new System.Drawing.Point(42, 431);
            this.plcelbl.Name = "plcelbl";
            this.plcelbl.Size = new System.Drawing.Size(110, 22);
            this.plcelbl.TabIndex = 11;
            this.plcelbl.Text = "Place/Transfer : ";
            this.plcelbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // plcelbl2
            // 
            this.plcelbl2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plcelbl2.Location = new System.Drawing.Point(158, 425);
            this.plcelbl2.Name = "plcelbl2";
            this.plcelbl2.Size = new System.Drawing.Size(673, 34);
            this.plcelbl2.TabIndex = 12;
            this.plcelbl2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 480);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 15);
            this.label3.TabIndex = 13;
            this.label3.Text = "Probation/Confirmation :";
            // 
            // prbtnlbl2
            // 
            this.prbtnlbl2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prbtnlbl2.Location = new System.Drawing.Point(158, 470);
            this.prbtnlbl2.Name = "prbtnlbl2";
            this.prbtnlbl2.Size = new System.Drawing.Size(673, 34);
            this.prbtnlbl2.TabIndex = 14;
            this.prbtnlbl2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(158, 523);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(673, 46);
            this.label4.TabIndex = 15;
            this.label4.Text = resources.GetString("label4.Text");
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(158, 582);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(673, 32);
            this.label5.TabIndex = 16;
            this.label5.Text = resources.GetString("label5.Text");
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(108, 632);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 15);
            this.label6.TabIndex = 17;
            this.label6.Text = "Leave :";
            // 
            // lvelbl2
            // 
            this.lvelbl2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvelbl2.Location = new System.Drawing.Point(158, 623);
            this.lvelbl2.Name = "lvelbl2";
            this.lvelbl2.Size = new System.Drawing.Size(676, 32);
            this.lvelbl2.TabIndex = 18;
            this.lvelbl2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lvelbl3
            // 
            this.lvelbl3.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvelbl3.Location = new System.Drawing.Point(158, 655);
            this.lvelbl3.Name = "lvelbl3";
            this.lvelbl3.Size = new System.Drawing.Size(682, 60);
            this.lvelbl3.TabIndex = 19;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(961, 470);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 20;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(958, 656);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 21;
            this.label1.Visible = false;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(958, 692);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 23);
            this.label7.TabIndex = 22;
            this.label7.Visible = false;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(967, 623);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 23);
            this.label8.TabIndex = 23;
            this.label8.Visible = false;
            // 
            // Form2
            // 
            this.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMargin = new System.Drawing.Size(1, 1);
            this.AutoScrollMinSize = new System.Drawing.Size(1, 1);
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1079, 733);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lvelbl3);
            this.Controls.Add(this.lvelbl2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.prbtnlbl2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.plcelbl2);
            this.Controls.Add(this.plcelbl);
            this.Controls.Add(this.slrylbl2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dojlbl2);
            this.Controls.Add(this.dojlbl);
            this.Controls.Add(this.desglbl2);
            this.Controls.Add(this.wlcmelbl);
            this.Controls.Add(this.addresslbl);
            this.Controls.Add(this.tdylbl);
            this.Controls.Add(this.datelbl);
            this.Controls.Add(this.appntlbl);
            this.Name = "Form2";
            this.Text = "Form2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label appntlbl;
        private System.Windows.Forms.Label datelbl;
        public System.Windows.Forms.Label tdylbl;
        public System.Windows.Forms.Label addresslbl;
        public System.Windows.Forms.Label wlcmelbl;
        public System.Windows.Forms.Label desglbl2;
        public System.Windows.Forms.Label dojlbl;
        public System.Windows.Forms.Label dojlbl2;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label slrylbl2;
        public System.Windows.Forms.Label plcelbl;
        public System.Windows.Forms.Label plcelbl2;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label prbtnlbl2;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label lvelbl2;
        public System.Windows.Forms.Label lvelbl3;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label8;
    }
}