﻿namespace Offer_Letter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.probtnperdtxtbx = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.plcejoingtxtbx = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.slrytxtbx = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dojtxtbx = new System.Windows.Forms.TextBox();
            this.dojlbl1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.addrstxtbx = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lnmetxtbx = new System.Windows.Forms.TextBox();
            this.fnmetxtbx = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.rspcttxtbx = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.bnftstxtbx = new System.Windows.Forms.TextBox();
            this.wrktxtbx = new System.Windows.Forms.Label();
            this.tmewrktxtbx = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.desgntxtbx = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(525, 676);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 25);
            this.button1.TabIndex = 15;
            this.button1.Text = "Show Offer letter";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // probtnperdtxtbx
            // 
            this.probtnperdtxtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.probtnperdtxtbx.Location = new System.Drawing.Point(597, 532);
            this.probtnperdtxtbx.Name = "probtnperdtxtbx";
            this.probtnperdtxtbx.Size = new System.Drawing.Size(264, 22);
            this.probtnperdtxtbx.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(290, 530);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(205, 22);
            this.label8.TabIndex = 13;
            this.label8.Text = "PROBATION PERIOD";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // plcejoingtxtbx
            // 
            this.plcejoingtxtbx.AutoCompleteCustomSource.AddRange(new string[] {
            "BANGALORE",
            "COIMBATORE",
            "CHENNAI",
            "SALEM"});
            this.plcejoingtxtbx.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.plcejoingtxtbx.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.plcejoingtxtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plcejoingtxtbx.Location = new System.Drawing.Point(597, 471);
            this.plcejoingtxtbx.Name = "plcejoingtxtbx";
            this.plcejoingtxtbx.Size = new System.Drawing.Size(264, 22);
            this.plcejoingtxtbx.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(303, 469);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(192, 22);
            this.label7.TabIndex = 11;
            this.label7.Text = "PLACE OF JOINING";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // slrytxtbx
            // 
            this.slrytxtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slrytxtbx.Location = new System.Drawing.Point(597, 407);
            this.slrytxtbx.Name = "slrytxtbx";
            this.slrytxtbx.Size = new System.Drawing.Size(264, 22);
            this.slrytxtbx.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(345, 407);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(150, 22);
            this.label6.TabIndex = 9;
            this.label6.Text = "SALARY(YEAR)";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dojtxtbx
            // 
            this.dojtxtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dojtxtbx.Location = new System.Drawing.Point(597, 345);
            this.dojtxtbx.Name = "dojtxtbx";
            this.dojtxtbx.Size = new System.Drawing.Size(264, 22);
            this.dojtxtbx.TabIndex = 8;
            // 
            // dojlbl1
            // 
            this.dojlbl1.AutoSize = true;
            this.dojlbl1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dojlbl1.Location = new System.Drawing.Point(315, 343);
            this.dojlbl1.Name = "dojlbl1";
            this.dojlbl1.Size = new System.Drawing.Size(180, 22);
            this.dojlbl1.TabIndex = 7;
            this.dojlbl1.Text = "DATE OF JOINING";
            this.dojlbl1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(387, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 22);
            this.label4.TabIndex = 6;
            this.label4.Text = "ADDRESS";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // addrstxtbx
            // 
            this.addrstxtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addrstxtbx.Location = new System.Drawing.Point(597, 156);
            this.addrstxtbx.Multiline = true;
            this.addrstxtbx.Name = "addrstxtbx";
            this.addrstxtbx.Size = new System.Drawing.Size(264, 100);
            this.addrstxtbx.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(142, 181);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 22);
            this.label3.TabIndex = 4;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lnmetxtbx
            // 
            this.lnmetxtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnmetxtbx.Location = new System.Drawing.Point(597, 102);
            this.lnmetxtbx.Name = "lnmetxtbx";
            this.lnmetxtbx.Size = new System.Drawing.Size(264, 22);
            this.lnmetxtbx.TabIndex = 3;
            // 
            // fnmetxtbx
            // 
            this.fnmetxtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fnmetxtbx.Location = new System.Drawing.Point(597, 51);
            this.fnmetxtbx.Name = "fnmetxtbx";
            this.fnmetxtbx.Size = new System.Drawing.Size(264, 22);
            this.fnmetxtbx.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(371, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "LAST NAME";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(363, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "FIRST NAME";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // rspcttxtbx
            // 
            this.rspcttxtbx.AutoCompleteCustomSource.AddRange(new string[] {
            "Mr.",
            "Ms.",
            "Mrs."});
            this.rspcttxtbx.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.rspcttxtbx.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.rspcttxtbx.Location = new System.Drawing.Point(559, 51);
            this.rspcttxtbx.Name = "rspcttxtbx";
            this.rspcttxtbx.Size = new System.Drawing.Size(32, 22);
            this.rspcttxtbx.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(387, 590);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 22);
            this.label5.TabIndex = 17;
            this.label5.Text = "BENEFITS";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // bnftstxtbx
            // 
            this.bnftstxtbx.AutoCompleteCustomSource.AddRange(new string[] {
            "Eligible",
            "Not Eligible"});
            this.bnftstxtbx.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.bnftstxtbx.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.bnftstxtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bnftstxtbx.Location = new System.Drawing.Point(597, 590);
            this.bnftstxtbx.Name = "bnftstxtbx";
            this.bnftstxtbx.Size = new System.Drawing.Size(264, 22);
            this.bnftstxtbx.TabIndex = 18;
            // 
            // wrktxtbx
            // 
            this.wrktxtbx.AutoSize = true;
            this.wrktxtbx.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wrktxtbx.Location = new System.Drawing.Point(387, 646);
            this.wrktxtbx.Name = "wrktxtbx";
            this.wrktxtbx.Size = new System.Drawing.Size(159, 22);
            this.wrktxtbx.TabIndex = 19;
            this.wrktxtbx.Text = "TIME OF WORK";
            this.wrktxtbx.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tmewrktxtbx
            // 
            this.tmewrktxtbx.AutoCompleteCustomSource.AddRange(new string[] {
            "Full",
            "Part"});
            this.tmewrktxtbx.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.tmewrktxtbx.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tmewrktxtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tmewrktxtbx.Location = new System.Drawing.Point(597, 648);
            this.tmewrktxtbx.Name = "tmewrktxtbx";
            this.tmewrktxtbx.Size = new System.Drawing.Size(264, 22);
            this.tmewrktxtbx.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(350, 287);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(145, 22);
            this.label9.TabIndex = 21;
            this.label9.Text = "DESIGNATION";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // desgntxtbx
            // 
            this.desgntxtbx.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.desgntxtbx.Location = new System.Drawing.Point(597, 287);
            this.desgntxtbx.Name = "desgntxtbx";
            this.desgntxtbx.Size = new System.Drawing.Size(264, 22);
            this.desgntxtbx.TabIndex = 22;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.PapayaWhip;
            this.ClientSize = new System.Drawing.Size(1259, 733);
            this.Controls.Add(this.desgntxtbx);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.tmewrktxtbx);
            this.Controls.Add(this.wrktxtbx);
            this.Controls.Add(this.bnftstxtbx);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.rspcttxtbx);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.probtnperdtxtbx);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.plcejoingtxtbx);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.slrytxtbx);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dojtxtbx);
            this.Controls.Add(this.dojlbl1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.addrstxtbx);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lnmetxtbx);
            this.Controls.Add(this.fnmetxtbx);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "Appointment Letter";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox probtnperdtxtbx;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox plcejoingtxtbx;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox slrytxtbx;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox dojtxtbx;
        private System.Windows.Forms.Label dojlbl1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox addrstxtbx;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox lnmetxtbx;
        private System.Windows.Forms.TextBox fnmetxtbx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox rspcttxtbx;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox bnftstxtbx;
        private System.Windows.Forms.Label wrktxtbx;
        private System.Windows.Forms.TextBox tmewrktxtbx;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.TextBox desgntxtbx;

    }
}

