﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace Offer_Letter
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        Form3 frm3 = new Form3();
        ResourceManager rm = new ResourceManager("Offer_Letter.Properties.Resources", Assembly.GetExecutingAssembly());
        StringBuilder sb = new StringBuilder();
        Properties.Settings st = new Properties.Settings();
        private void button1_Click(object sender, EventArgs e)
        {
            sb.AppendLine();
            sb.AppendLine();
            frm3.lbl.Text = sb.Append(rm.GetString("point1").Trim()).ToString();
            sb.AppendLine();
            sb.AppendLine();
            frm3.lbl.Text = sb.Append(rm.GetString("point2").Trim()).ToString();
            sb.AppendLine();
            sb.AppendLine();
            frm3.lbl.Text = sb.Append(rm.GetString("point3").Trim()).ToString();
            sb.AppendLine();
            sb.AppendLine();
            frm3.lbl.Text = sb.Append(rm.GetString("point4").Trim()).ToString();
            sb.AppendLine();
            sb.AppendLine();
            frm3.lbl.Text = sb.Append(rm.GetString("point5").Trim()).ToString();
            sb.AppendLine();
            sb.AppendLine();
            frm3.lbl.Text = sb.Append(rm.GetString("point6").Trim()).ToString();
            sb.AppendLine();
            sb.AppendLine();
            frm3.lbl.Text = sb.Append(rm.GetString("point7").Trim()).ToString();
            sb.AppendLine();
            sb.AppendLine();
            frm3.lbl.Text = sb.Append(rm.GetString("point8").Trim()).ToString();
            sb.AppendLine();
            sb.AppendLine();
            frm3.lbl.Text = sb.Append(rm.GetString("point9").Trim()).ToString();
            sb.AppendLine();
            sb.AppendLine();
            frm3.lbl.Text = sb.Append(String.Concat("We welcome you to ", rm.GetString("cmpnynme").Trim().ToString(), " and look forward to a fruitful collaboration.")).ToString();
            sb.AppendLine();
            sb.AppendLine();
            frm3.lbl.Text = sb.Append("With Best Wishes,").ToString();
            sb.AppendLine();
            sb.AppendLine();
            frm3.lbl.Text = sb.Append(rm.GetString("cmpnynme").Trim()).ToString();
            sb.AppendLine();
            sb.AppendLine();
            frm3.lbl.Text = sb.Append(String.Concat("Name : ",label1.Text.Trim(),label7.Text.Trim())).ToString();
            sb.AppendLine();
            sb.AppendLine();
            frm3.lbl.Text = sb.Append(String.Concat("Designation : ",label8.Text.Trim())).ToString();
            sb.AppendLine();
            sb.AppendLine();
            frm3.ShowDialog();
        }

    }
}
