﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VehicleParking
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Properties.Settings st = new Properties.Settings();
        Form2 frm2 = new Form2();
        private void btn_entry_Click(object sender, EventArgs e)
        {
            if (txtbx_nme.Text == "" || txtbx_phnnumbr.Text == "" || txtbx_vechlenmbr.Text == "")
            {
                MessageBox.Show("Please enter the Blank Field", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (st.Name == "" || st.Name1 == "" || st.Name2 == "" || st.Name3 == "" || st.Name4 == "" || st.Name5 == "" || st.Name6 == "" ||
                    st.Name7 == "" || st.Name8 == "" || st.Name9 == "" || st.Name10 == "" || st.Name11 == "" || st.Name12 == "" || st.Name13 == "" || st.Name14 == "")
                {
                    if (st.Vehicle == txtbx_vechlenmbr.Text || st.Vehicle1 == txtbx_vechlenmbr.Text || st.Vehicle2 == txtbx_vechlenmbr.Text || st.Vehicle3 == txtbx_vechlenmbr.Text || st.Vehicle4 == txtbx_vechlenmbr.Text || st.Vehicle5 == txtbx_vechlenmbr.Text ||
                        st.Vehicle6 == txtbx_vechlenmbr.Text || st.Vehicle7 == txtbx_vechlenmbr.Text || st.Vehicle8 == txtbx_vechlenmbr.Text || st.Vehicle9 == txtbx_vechlenmbr.Text || st.Vehicle10 == txtbx_vechlenmbr.Text || st.Vehicle11 == txtbx_vechlenmbr.Text ||
                        st.Vehicle12 == txtbx_vechlenmbr.Text || st.Vehicle13 == txtbx_vechlenmbr.Text || st.Vehicle14 == txtbx_vechlenmbr.Text)
                    {
                        MessageBox.Show("The Vehicle is Already Registered", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                       
                    
                        if (st.Name == "")
                        {
                            st.Name = txtbx_nme.Text;
                            st.Vehicle = txtbx_vechlenmbr.Text;
                            st.Phonenumbr = txtbx_phnnumbr.Text;
                            st.checkintime = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle);

                        }
                        else if (st.Name1 == "")
                        {
                            st.Name1 = txtbx_nme.Text;
                            st.Vehicle1 = txtbx_vechlenmbr.Text;
                            st.Phonenumbr1 = txtbx_phnnumbr.Text;
                            st.checkintime1 = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle1);

                        }
                        else if (st.Name2 == "")
                        {
                            st.Name2 = txtbx_nme.Text;
                            st.Vehicle2 = txtbx_vechlenmbr.Text;
                            st.Phonenumbr2 = txtbx_phnnumbr.Text;
                            st.checkintime2 = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle2);

                        }
                        else if (st.Name3 == "")
                        {
                            st.Name3 = txtbx_nme.Text;
                            st.Vehicle3 = txtbx_vechlenmbr.Text;
                            st.Phonenumbr3 = txtbx_phnnumbr.Text;
                            st.checkintime3 = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle3);

                        }
                        else if (st.Name4 == "")
                        {
                            st.Name4 = txtbx_nme.Text;
                            st.Vehicle4 = txtbx_vechlenmbr.Text;
                            st.Phonenumbr4 = txtbx_phnnumbr.Text;
                            st.checkintime4 = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle4);

                        }
                        else if (st.Name5 == "")
                        {
                            st.Name5 = txtbx_nme.Text;
                            st.Vehicle5 = txtbx_vechlenmbr.Text;
                            st.Phonenumbr5 = txtbx_phnnumbr.Text;
                            st.checkintime5 = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle5);

                        }
                        else if (st.Name6 == "")
                        {
                            st.Name6 = txtbx_nme.Text;
                            st.Vehicle6 = txtbx_vechlenmbr.Text;
                            st.Phonenumbr6 = txtbx_phnnumbr.Text;
                            st.checkintime6 = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle6);

                        }
                        else if (st.Name7 == "")
                        {
                            st.Name7 = txtbx_nme.Text;
                            st.Vehicle7 = txtbx_vechlenmbr.Text;
                            st.Phonenumbr7 = txtbx_phnnumbr.Text;
                            st.checkintime7 = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle7);

                        }
                        else if (st.Name8 == "")
                        {
                            st.Name8 = txtbx_nme.Text;
                            st.Vehicle8 = txtbx_vechlenmbr.Text;
                            st.Phonenumbr8 = txtbx_phnnumbr.Text;
                            st.checkintime8 = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle8);

                        }
                        else if (st.Name9 == "")
                        {
                            st.Name9 = txtbx_nme.Text;
                            st.Vehicle9 = txtbx_vechlenmbr.Text;
                            st.Phonenumbr9 = txtbx_phnnumbr.Text;
                            st.checkintime9 = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle9);

                        }
                        else if (st.Name10 == "")
                        {
                            st.Name10 = txtbx_nme.Text;
                            st.Vehicle10 = txtbx_vechlenmbr.Text;
                            st.Phonenumbr10 = txtbx_phnnumbr.Text;
                            st.checkintime10 = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle10);

                        }
                        else if (st.Name11 == "")
                        {
                            st.Name11 = txtbx_nme.Text;
                            st.Vehicle11 = txtbx_vechlenmbr.Text;
                            st.Phonenumbr11 = txtbx_phnnumbr.Text;
                            st.checkintime11 = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle11);

                        }
                        else if (st.Name12 == "")
                        {
                            st.Name12 = txtbx_nme.Text;
                            st.Vehicle12 = txtbx_vechlenmbr.Text;
                            st.Phonenumbr12 = txtbx_phnnumbr.Text;
                            st.checkintime12 = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle12);

                        }
                        else if (st.Name13 == "")
                        {
                            st.Name13 = txtbx_nme.Text;
                            st.Vehicle13 = txtbx_vechlenmbr.Text;
                            st.Phonenumbr13 = txtbx_phnnumbr.Text;
                            st.checkintime13 = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle13);

                        }
                        else if (st.Name14 == "")
                        {
                            st.Name14 = txtbx_nme.Text;
                            st.Vehicle14 = txtbx_vechlenmbr.Text;
                            st.Phonenumbr14 = txtbx_phnnumbr.Text;
                            st.checkintime14 = DateTime.Now;
                            listbx_vechlenumbr.Items.Add(st.Vehicle14);

                        }
                        else
                        {
                            MessageBox.Show("Sorry, The Parking lot is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    

                }
                else
                {
                    MessageBox.Show("Sorry, The Parking lot is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int k = listbx_vechlenumbr.SelectedItems.Count;
            for (int i = 0; i < k; i++)
            {
                if (listbx_vechlenumbr.Text == st.Vehicle)
                {
                    txtbx_nme.Text = st.Name;
                    txtbx_vechlenmbr.Text = st.Vehicle;
                    txtbx_phnnumbr.Text = st.Phonenumbr;

                    frm2.txtbx_nme2.Text = st.Name;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr;
                    frm2.txtbx_chckintme2.Text = st.checkintime.ToString();
                    frm2.dateTimePicker1.Value = st.checkintime;
                    listbx_vechlenumbr.Items.Remove(listbx_vechlenumbr.SelectedItem);
                    frm2.ShowDialog();
                    st.Name = "";
                    st.Vehicle = "";
                    st.Phonenumbr = "";
                   
                    
                }
                else if (listbx_vechlenumbr.Text == st.Vehicle1)
                {
                    txtbx_nme.Text = st.Name1;
                    txtbx_vechlenmbr.Text = st.Vehicle1;
                    txtbx_phnnumbr.Text = st.Phonenumbr1;

                    frm2.txtbx_nme2.Text = st.Name1;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle1;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr1;
                    frm2.txtbx_chckintme2.Text = st.checkintime1.ToString();
                    frm2.dateTimePicker1.Value = st.checkintime1;
                    listbx_vechlenumbr.Items.Remove(txtbx_vechlenmbr.Text);
                    frm2.ShowDialog();
                    st.Name1 = "";
                    st.Vehicle1 = "";
                    st.Phonenumbr1 = "";
                    
                }
                else if (listbx_vechlenumbr.Text == st.Vehicle2)
                {
                    txtbx_nme.Text = st.Name2;
                    txtbx_vechlenmbr.Text = st.Vehicle2;
                    txtbx_phnnumbr.Text = st.Phonenumbr2;

                    frm2.txtbx_nme2.Text = st.Name2;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle2;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr2;
                    frm2.txtbx_chckintme2.Text = st.checkintime2.ToString();
                    frm2.dateTimePicker1.Value = st.checkintime2;
                    listbx_vechlenumbr.Items.Remove(txtbx_vechlenmbr.Text);
                    frm2.ShowDialog() ;
                    st.Name2 = "";
                    st.Vehicle2 = "";
                    st.Phonenumbr2 = "";
                  
                }
                else if (listbx_vechlenumbr.Text == st.Vehicle3)
                {
                    txtbx_nme.Text = st.Name3;
                    txtbx_vechlenmbr.Text = st.Vehicle3;
                    txtbx_phnnumbr.Text = st.Phonenumbr3;

                    frm2.txtbx_nme2.Text = st.Name3;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle3;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr3;
                    frm2.txtbx_chckintme2.Text = st.checkintime3.ToString();
                    frm2.dateTimePicker1.Value = st.checkintime3;
                    listbx_vechlenumbr.Items.Remove(txtbx_vechlenmbr.Text);
                    frm2.ShowDialog();
                    st.Name3 = "";
                    st.Vehicle3 = "";
                    st.Phonenumbr3 = "";
                 
                }
                else if (listbx_vechlenumbr.Text == st.Vehicle4)
                {
                    txtbx_nme.Text = st.Name4;
                    txtbx_vechlenmbr.Text = st.Vehicle4;
                    txtbx_phnnumbr.Text = st.Phonenumbr4;

                    frm2.txtbx_nme2.Text = st.Name4;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle4;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr4;
                    frm2.txtbx_chckintme2.Text = st.checkintime4.ToString();
                    frm2.dateTimePicker1.Value = st.checkintime4;
                    listbx_vechlenumbr.Items.Remove(txtbx_vechlenmbr.Text);
                    frm2.ShowDialog();
                    st.Name4 = "";
                    st.Vehicle4 = "";
                    st.Phonenumbr4 = "";
               
                }
                else if (listbx_vechlenumbr.Text == st.Vehicle5)
                {
                    txtbx_nme.Text = st.Name5;
                    txtbx_vechlenmbr.Text = st.Vehicle5;
                    txtbx_phnnumbr.Text = st.Phonenumbr5;

                    frm2.txtbx_nme2.Text = st.Name5;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle5;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr5;
                    frm2.txtbx_chckintme2.Text = st.checkintime5.ToString();
                    frm2.dateTimePicker1.Value = st.checkintime5;
                    listbx_vechlenumbr.Items.Remove(txtbx_vechlenmbr.Text);
                    frm2.ShowDialog();
                    st.Name5 = "";
                    st.Vehicle5 = "";
                    st.Phonenumbr5 = "";
                
                }
                else if (listbx_vechlenumbr.Text == st.Vehicle6)
                {
                    txtbx_nme.Text = st.Name6;
                    txtbx_vechlenmbr.Text = st.Vehicle6;
                    txtbx_phnnumbr.Text = st.Phonenumbr6;

                    frm2.txtbx_nme2.Text = st.Name6;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle6;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr6;
                    frm2.txtbx_chckintme2.Text = st.checkintime6.ToString();
                    frm2.dateTimePicker1.Value = st.checkintime6;
                    listbx_vechlenumbr.Items.Remove(txtbx_vechlenmbr.Text);
                    frm2.ShowDialog();
                    st.Name6 = "";
                    st.Vehicle6 = "";
                    st.Phonenumbr6 = "";
                  
                }
                else if (listbx_vechlenumbr.Text == st.Vehicle7)
                {
                    txtbx_nme.Text = st.Name7;
                    txtbx_vechlenmbr.Text = st.Vehicle7;
                    txtbx_phnnumbr.Text = st.Phonenumbr7;

                    frm2.txtbx_nme2.Text = st.Name7;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle7;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr7;
                    frm2.txtbx_chckintme2.Text = st.checkintime7.ToString();
                    frm2.dateTimePicker1.Value = st.checkintime7;
                    listbx_vechlenumbr.Items.Remove(txtbx_vechlenmbr.Text);
                    frm2.ShowDialog();
                    st.Name7 = "";
                    st.Vehicle7 = "";
                    st.Phonenumbr7 = "";
               
                }
                else if (listbx_vechlenumbr.Text == st.Vehicle8)
                {
                    txtbx_nme.Text = st.Name8;
                    txtbx_vechlenmbr.Text = st.Vehicle8;
                    txtbx_phnnumbr.Text = st.Phonenumbr8;

                    frm2.txtbx_nme2.Text = st.Name8;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle8;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr8;
                    frm2.txtbx_chckintme2.Text = st.checkintime8.ToString();
                    frm2.dateTimePicker1.Value = st.checkintime8;
                    listbx_vechlenumbr.Items.Remove(txtbx_vechlenmbr.Text);
                    frm2.ShowDialog();
                    st.Name8 = "";
                    st.Vehicle8 = "";
                    st.Phonenumbr8 = "";
                   
                }
               else if (listbx_vechlenumbr.Text == st.Vehicle9)
                {
                    txtbx_nme.Text = st.Name9;
                    txtbx_vechlenmbr.Text = st.Vehicle9;
                    txtbx_phnnumbr.Text = st.Phonenumbr9;

                    frm2.txtbx_nme2.Text = st.Name9;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle9;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr9;
                    frm2.txtbx_chckintme2.Text = st.checkintime9.ToString();
                    frm2.dateTimePicker1.Value = st.checkintime9;
                    listbx_vechlenumbr.Items.Remove(txtbx_vechlenmbr.Text);
                    frm2.ShowDialog();
                    st.Name9 = "";
                    st.Vehicle9 = "";
                    st.Phonenumbr9 = "";
                  
                }
                else if (listbx_vechlenumbr.Text == st.Vehicle10)
                {
                    txtbx_nme.Text = st.Name10;
                    txtbx_vechlenmbr.Text = st.Vehicle10;
                    txtbx_phnnumbr.Text = st.Phonenumbr10;

                    frm2.txtbx_nme2.Text = st.Name10;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle10;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr10;
                    frm2.txtbx_chckintme2.Text = st.checkintime10.ToString() ;
                    frm2.dateTimePicker1.Value = st.checkintime10;
                    listbx_vechlenumbr.Items.Remove(txtbx_vechlenmbr.Text);
                    frm2.ShowDialog();
                    st.Name10 = "";
                    st.Vehicle10 = "";
                    st.Phonenumbr10 = "";
                    
                }
                else if (listbx_vechlenumbr.Text == st.Vehicle11)
                {
                    txtbx_nme.Text = st.Name11;
                    txtbx_vechlenmbr.Text = st.Vehicle11;
                    txtbx_phnnumbr.Text = st.Phonenumbr11;

                    frm2.txtbx_nme2.Text = st.Name11;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle11;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr11;
                    frm2.txtbx_chckintme2.Text = st.checkintime11.ToString();
                    frm2.dateTimePicker1.Value = st.checkintime11;
                    listbx_vechlenumbr.Items.Remove(txtbx_vechlenmbr.Text);
                    frm2.ShowDialog();
                    st.Name11 = "";
                    st.Vehicle11 = "";
                    st.Phonenumbr11 = "";
                    
                }
                else if (listbx_vechlenumbr.Text == st.Vehicle12)
                {
                    txtbx_nme.Text = st.Name12;
                    txtbx_vechlenmbr.Text = st.Vehicle12;
                    txtbx_phnnumbr.Text = st.Phonenumbr12;

                    frm2.txtbx_nme2.Text = st.Name12;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle12;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr12;
                    frm2.txtbx_chckintme2.Text = st.checkintime12.ToString();
                    frm2.dateTimePicker1.Value = st.checkintime12;
                    listbx_vechlenumbr.Items.Remove(txtbx_vechlenmbr.Text);
                    frm2.ShowDialog();
                    st.Name12 = "";
                    st.Vehicle12 = "";
                    st.Phonenumbr12 = "";
                    
                }
                else  if (listbx_vechlenumbr.Text == st.Vehicle13)
                {
                    txtbx_nme.Text = st.Name13;
                    txtbx_vechlenmbr.Text = st.Vehicle13;
                    txtbx_phnnumbr.Text = st.Phonenumbr13;

                    frm2.txtbx_nme2.Text = st.Name13;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle13;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr13;
                    frm2.txtbx_chckintme2.Text = st.checkintime13.ToString();
                    frm2.dateTimePicker1.Value = st.checkintime13;
                    listbx_vechlenumbr.Items.Remove(txtbx_vechlenmbr.Text);
                    frm2.ShowDialog();
                    st.Name13 = "";
                    st.Vehicle13 = "";
                    st.Phonenumbr13 = "";
                 
                }
                else if (listbx_vechlenumbr.Text == st.Vehicle14)
                {
                    txtbx_nme.Text = st.Name14;
                    txtbx_vechlenmbr.Text = st.Vehicle14;
                    txtbx_phnnumbr.Text = st.Phonenumbr14;

                    frm2.txtbx_nme2.Text = st.Name14;
                    frm2.txtbx_vechlenmbr2.Text = st.Vehicle14;
                    frm2.txtbx_phnnmbr2.Text = st.Phonenumbr14;
                    frm2.txtbx_chckintme2.Text = st.checkintime14.ToString();
                    frm2.dateTimePicker1.Value = st.checkintime14;
                    listbx_vechlenumbr.Items.Remove(txtbx_vechlenmbr.Text);
                    frm2.ShowDialog();
                    st.Name14 = "";
                    st.Vehicle14 = "";
                    st.Phonenumbr14 = "";
                
                }
                else
                {
                    MessageBox.Show("Vehicle not found in the Database","Warning",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }

                
            }
        }
    }
}
