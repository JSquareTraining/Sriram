﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VehicleParking
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
       
        private void Form2_Load(object sender, EventArgs e)
        {

            txtbx_chckouttme.Text = DateTime.Now.ToString();
            int a = DateTime.Now.Minute - dateTimePicker1.Value.Minute;
            txtbx_totlamt2.Text = (a * 0.08333).ToString();
        }

        private void btn_entry2_Click(object sender, EventArgs e)
        {
            this.Hide();
            

        }
    }
}
