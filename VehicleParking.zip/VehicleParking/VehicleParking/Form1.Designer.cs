﻿namespace VehicleParking
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl_nme = new System.Windows.Forms.Label();
            this.lbl_entrydetails = new System.Windows.Forms.Label();
            this.txtbx_nme = new System.Windows.Forms.TextBox();
            this.txtbx_vechlenmbr = new System.Windows.Forms.TextBox();
            this.lbl_vechlenumbr = new System.Windows.Forms.Label();
            this.txtbx_phnnumbr = new System.Windows.Forms.TextBox();
            this.lbl_phnnumbr = new System.Windows.Forms.Label();
            this.listbx_vechlenumbr = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_entry = new System.Windows.Forms.Button();
            this.lbl_vechlenumbr2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1362, 104);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lbl_nme
            // 
            this.lbl_nme.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nme.ForeColor = System.Drawing.Color.White;
            this.lbl_nme.Location = new System.Drawing.Point(141, 96);
            this.lbl_nme.Name = "lbl_nme";
            this.lbl_nme.Size = new System.Drawing.Size(100, 23);
            this.lbl_nme.TabIndex = 1;
            this.lbl_nme.Text = "NAME";
            this.lbl_nme.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_entrydetails
            // 
            this.lbl_entrydetails.Font = new System.Drawing.Font("Palatino Linotype", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_entrydetails.ForeColor = System.Drawing.Color.White;
            this.lbl_entrydetails.Location = new System.Drawing.Point(173, 26);
            this.lbl_entrydetails.Name = "lbl_entrydetails";
            this.lbl_entrydetails.Size = new System.Drawing.Size(251, 35);
            this.lbl_entrydetails.TabIndex = 2;
            this.lbl_entrydetails.Text = "ENTRY DETAILS";
            this.lbl_entrydetails.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtbx_nme
            // 
            this.txtbx_nme.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_nme.Location = new System.Drawing.Point(297, 96);
            this.txtbx_nme.Name = "txtbx_nme";
            this.txtbx_nme.Size = new System.Drawing.Size(230, 25);
            this.txtbx_nme.TabIndex = 3;
            // 
            // txtbx_vechlenmbr
            // 
            this.txtbx_vechlenmbr.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_vechlenmbr.Location = new System.Drawing.Point(297, 141);
            this.txtbx_vechlenmbr.Name = "txtbx_vechlenmbr";
            this.txtbx_vechlenmbr.Size = new System.Drawing.Size(230, 25);
            this.txtbx_vechlenmbr.TabIndex = 5;
            // 
            // lbl_vechlenumbr
            // 
            this.lbl_vechlenumbr.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_vechlenumbr.ForeColor = System.Drawing.Color.White;
            this.lbl_vechlenumbr.Location = new System.Drawing.Point(40, 141);
            this.lbl_vechlenumbr.Name = "lbl_vechlenumbr";
            this.lbl_vechlenumbr.Size = new System.Drawing.Size(201, 23);
            this.lbl_vechlenumbr.TabIndex = 4;
            this.lbl_vechlenumbr.Text = "VEHICLE NUMBER";
            this.lbl_vechlenumbr.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_phnnumbr
            // 
            this.txtbx_phnnumbr.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_phnnumbr.Location = new System.Drawing.Point(297, 189);
            this.txtbx_phnnumbr.Name = "txtbx_phnnumbr";
            this.txtbx_phnnumbr.Size = new System.Drawing.Size(230, 25);
            this.txtbx_phnnumbr.TabIndex = 7;
            // 
            // lbl_phnnumbr
            // 
            this.lbl_phnnumbr.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_phnnumbr.ForeColor = System.Drawing.Color.White;
            this.lbl_phnnumbr.Location = new System.Drawing.Point(61, 189);
            this.lbl_phnnumbr.Name = "lbl_phnnumbr";
            this.lbl_phnnumbr.Size = new System.Drawing.Size(180, 23);
            this.lbl_phnnumbr.TabIndex = 6;
            this.lbl_phnnumbr.Text = "PHONE NUMBER";
            this.lbl_phnnumbr.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // listbx_vechlenumbr
            // 
            this.listbx_vechlenumbr.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbx_vechlenumbr.FormattingEnabled = true;
            this.listbx_vechlenumbr.ItemHeight = 17;
            this.listbx_vechlenumbr.Location = new System.Drawing.Point(934, 159);
            this.listbx_vechlenumbr.Name = "listbx_vechlenumbr";
            this.listbx_vechlenumbr.Size = new System.Drawing.Size(245, 378);
            this.listbx_vechlenumbr.TabIndex = 9;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_entry);
            this.groupBox1.Controls.Add(this.lbl_entrydetails);
            this.groupBox1.Controls.Add(this.lbl_nme);
            this.groupBox1.Controls.Add(this.txtbx_nme);
            this.groupBox1.Controls.Add(this.txtbx_phnnumbr);
            this.groupBox1.Controls.Add(this.lbl_vechlenumbr);
            this.groupBox1.Controls.Add(this.lbl_phnnumbr);
            this.groupBox1.Controls.Add(this.txtbx_vechlenmbr);
            this.groupBox1.Location = new System.Drawing.Point(165, 133);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(601, 404);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            // 
            // btn_entry
            // 
            this.btn_entry.BackColor = System.Drawing.Color.DarkOrchid;
            this.btn_entry.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_entry.Location = new System.Drawing.Point(253, 255);
            this.btn_entry.Name = "btn_entry";
            this.btn_entry.Size = new System.Drawing.Size(78, 31);
            this.btn_entry.TabIndex = 8;
            this.btn_entry.Text = "ENTRY";
            this.btn_entry.UseVisualStyleBackColor = false;
            this.btn_entry.Click += new System.EventHandler(this.btn_entry_Click);
            // 
            // lbl_vechlenumbr2
            // 
            this.lbl_vechlenumbr2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_vechlenumbr2.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_vechlenumbr2.ForeColor = System.Drawing.Color.White;
            this.lbl_vechlenumbr2.Location = new System.Drawing.Point(934, 133);
            this.lbl_vechlenumbr2.Name = "lbl_vechlenumbr2";
            this.lbl_vechlenumbr2.Size = new System.Drawing.Size(245, 23);
            this.lbl_vechlenumbr2.TabIndex = 11;
            this.lbl_vechlenumbr2.Text = " VEHICLE NUMBER";
            this.lbl_vechlenumbr2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkOrchid;
            this.button2.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(934, 552);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(245, 31);
            this.button2.TabIndex = 9;
            this.button2.Text = "CHECKOUT";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(451, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(473, 41);
            this.label1.TabIndex = 12;
            this.label1.Text = "ISSI TWO WHEELER  PARKING";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1362, 741);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lbl_vechlenumbr2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.listbx_vechlenumbr);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl_nme;
        private System.Windows.Forms.Label lbl_entrydetails;
        private System.Windows.Forms.TextBox txtbx_nme;
        private System.Windows.Forms.TextBox txtbx_vechlenmbr;
        private System.Windows.Forms.Label lbl_vechlenumbr;
        private System.Windows.Forms.TextBox txtbx_phnnumbr;
        private System.Windows.Forms.Label lbl_phnnumbr;
        private System.Windows.Forms.ListBox listbx_vechlenumbr;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbl_vechlenumbr2;
        private System.Windows.Forms.Button btn_entry;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
    }
}

