﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace usrcontrol
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
           
        }
        int len = 5;
       
      
        public int max_len
        {
            get
            {
                return len;
            }
            set
            {
                len = value;
            }
        }
        int i = 1;
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Length <= len)
            {

                if (i == 1)
                {
                    textBox1.ForeColor = Color.Blue;
                    i = 2;
                }
                else if(i == 2)
                {
                    textBox1.ForeColor = Color.Red;
                    i = 3;
                }
                else 
                {
                    textBox1.ForeColor = Color.Green;
                    i = 3;
                }
                
            }
            else
            {
                textBox1.Text = textBox1.Text.Remove(len);
                MessageBox.Show("You Exceed Length");
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox1.ReadOnly = true;
        }
        int j = 1;
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
            textBox1.ReadOnly = false;
            if (textBox3.Text.Length <= len)
            {
                if (j == 1)
                {
                    textBox3.BackColor = Color.GreenYellow;
                    
                    j = 2;
                }
                else if (j == 2)
                {
                    textBox3.BackColor = Color.HotPink;
                    
                    j = 3;
                }
                else
                {
                    
                    textBox3.BackColor = Color.IndianRed;
                    
                    j = 1;
                }
            }
            else
            {
                textBox3.Text = textBox3.Text.Remove(len);
                MessageBox.Show("You exceed the length");
            }

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
             int x = button4.Location.X;
            int y = button4.Location.Y;
            x = x+1;
            button4.Location = new Point(x, y);
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            int x = button4.Location.X;
            int y = button4.Location.Y;
            y = y + 1;
            button4.Location = new Point(x, y);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(textBox1.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show(textBox2.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show(textBox3.Text);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show(textBox4.Text);
            MessageBox.Show(textBox5.Text);
        } 

    }
}
