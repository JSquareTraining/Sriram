﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.btn_9 = new System.Windows.Forms.Button();
            this.btn_8 = new System.Windows.Forms.Button();
            this.btn_7 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.btn_6 = new System.Windows.Forms.Button();
            this.btn_5 = new System.Windows.Forms.Button();
            this.btn_4 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.btn_3 = new System.Windows.Forms.Button();
            this.btn_2 = new System.Windows.Forms.Button();
            this.btn_1 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.btn_dot = new System.Windows.Forms.Button();
            this.btn_0 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.txtbx_output = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button1.Location = new System.Drawing.Point(12, 72);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(38, 31);
            this.button1.TabIndex = 1;
            this.button1.Text = "MC";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button2.Location = new System.Drawing.Point(56, 72);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(38, 31);
            this.button2.TabIndex = 2;
            this.button2.Text = "MR";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button3.Location = new System.Drawing.Point(100, 72);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(38, 31);
            this.button3.TabIndex = 3;
            this.button3.Text = "MS";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button4.Location = new System.Drawing.Point(144, 72);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(38, 31);
            this.button4.TabIndex = 4;
            this.button4.Text = "M+";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button5.Cursor = System.Windows.Forms.Cursors.No;
            this.button5.Location = new System.Drawing.Point(188, 72);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(38, 31);
            this.button5.TabIndex = 5;
            this.button5.Text = "M-";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.Location = new System.Drawing.Point(188, 109);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(38, 31);
            this.button6.TabIndex = 10;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.Location = new System.Drawing.Point(144, 109);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(38, 31);
            this.button7.TabIndex = 9;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button8.Image = ((System.Drawing.Image)(resources.GetObject("button8.Image")));
            this.button8.Location = new System.Drawing.Point(100, 109);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(38, 31);
            this.button8.TabIndex = 8;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button9.Image = ((System.Drawing.Image)(resources.GetObject("button9.Image")));
            this.button9.Location = new System.Drawing.Point(56, 109);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(38, 31);
            this.button9.TabIndex = 7;
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button10.Image = ((System.Drawing.Image)(resources.GetObject("button10.Image")));
            this.button10.Location = new System.Drawing.Point(12, 109);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(38, 31);
            this.button10.TabIndex = 6;
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button11.Image = ((System.Drawing.Image)(resources.GetObject("button11.Image")));
            this.button11.Location = new System.Drawing.Point(188, 146);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(38, 31);
            this.button11.TabIndex = 15;
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button12.Image = ((System.Drawing.Image)(resources.GetObject("button12.Image")));
            this.button12.Location = new System.Drawing.Point(144, 146);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(38, 31);
            this.button12.TabIndex = 14;
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // btn_9
            // 
            this.btn_9.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_9.Image = ((System.Drawing.Image)(resources.GetObject("btn_9.Image")));
            this.btn_9.Location = new System.Drawing.Point(100, 146);
            this.btn_9.Name = "btn_9";
            this.btn_9.Size = new System.Drawing.Size(38, 31);
            this.btn_9.TabIndex = 13;
            this.btn_9.UseVisualStyleBackColor = false;
            this.btn_9.Click += new System.EventHandler(this.btn_9_Click);
            // 
            // btn_8
            // 
            this.btn_8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_8.Image = ((System.Drawing.Image)(resources.GetObject("btn_8.Image")));
            this.btn_8.Location = new System.Drawing.Point(56, 146);
            this.btn_8.Name = "btn_8";
            this.btn_8.Size = new System.Drawing.Size(38, 31);
            this.btn_8.TabIndex = 12;
            this.btn_8.UseVisualStyleBackColor = false;
            this.btn_8.Click += new System.EventHandler(this.btn_8_Click);
            // 
            // btn_7
            // 
            this.btn_7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_7.Image = ((System.Drawing.Image)(resources.GetObject("btn_7.Image")));
            this.btn_7.Location = new System.Drawing.Point(12, 146);
            this.btn_7.Name = "btn_7";
            this.btn_7.Size = new System.Drawing.Size(38, 31);
            this.btn_7.TabIndex = 11;
            this.btn_7.UseVisualStyleBackColor = false;
            this.btn_7.Click += new System.EventHandler(this.btn_7_Click);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button16.Image = ((System.Drawing.Image)(resources.GetObject("button16.Image")));
            this.button16.Location = new System.Drawing.Point(188, 183);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(38, 31);
            this.button16.TabIndex = 20;
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button17.Image = ((System.Drawing.Image)(resources.GetObject("button17.Image")));
            this.button17.Location = new System.Drawing.Point(144, 183);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(38, 31);
            this.button17.TabIndex = 19;
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // btn_6
            // 
            this.btn_6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_6.Image = ((System.Drawing.Image)(resources.GetObject("btn_6.Image")));
            this.btn_6.Location = new System.Drawing.Point(100, 183);
            this.btn_6.Name = "btn_6";
            this.btn_6.Size = new System.Drawing.Size(38, 31);
            this.btn_6.TabIndex = 18;
            this.btn_6.UseVisualStyleBackColor = false;
            this.btn_6.Click += new System.EventHandler(this.btn_6_Click);
            // 
            // btn_5
            // 
            this.btn_5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_5.Image = ((System.Drawing.Image)(resources.GetObject("btn_5.Image")));
            this.btn_5.Location = new System.Drawing.Point(56, 183);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(38, 31);
            this.btn_5.TabIndex = 17;
            this.btn_5.UseVisualStyleBackColor = false;
            this.btn_5.Click += new System.EventHandler(this.btn_5_Click);
            // 
            // btn_4
            // 
            this.btn_4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_4.Image = ((System.Drawing.Image)(resources.GetObject("btn_4.Image")));
            this.btn_4.Location = new System.Drawing.Point(12, 183);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(38, 31);
            this.btn_4.TabIndex = 16;
            this.btn_4.UseVisualStyleBackColor = false;
            this.btn_4.Click += new System.EventHandler(this.btn_4_Click);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button21.Image = ((System.Drawing.Image)(resources.GetObject("button21.Image")));
            this.button21.Location = new System.Drawing.Point(144, 220);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(38, 31);
            this.button21.TabIndex = 24;
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // btn_3
            // 
            this.btn_3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_3.Image = ((System.Drawing.Image)(resources.GetObject("btn_3.Image")));
            this.btn_3.Location = new System.Drawing.Point(100, 220);
            this.btn_3.Name = "btn_3";
            this.btn_3.Size = new System.Drawing.Size(38, 31);
            this.btn_3.TabIndex = 23;
            this.btn_3.UseVisualStyleBackColor = false;
            this.btn_3.Click += new System.EventHandler(this.btn_3_Click);
            // 
            // btn_2
            // 
            this.btn_2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_2.Image = ((System.Drawing.Image)(resources.GetObject("btn_2.Image")));
            this.btn_2.Location = new System.Drawing.Point(56, 220);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(38, 31);
            this.btn_2.TabIndex = 22;
            this.btn_2.UseVisualStyleBackColor = false;
            this.btn_2.Click += new System.EventHandler(this.btn_2_Click);
            // 
            // btn_1
            // 
            this.btn_1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_1.Image = ((System.Drawing.Image)(resources.GetObject("btn_1.Image")));
            this.btn_1.Location = new System.Drawing.Point(12, 220);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(38, 31);
            this.btn_1.TabIndex = 21;
            this.btn_1.UseVisualStyleBackColor = false;
            this.btn_1.Click += new System.EventHandler(this.btn_1_Click);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button25.Image = ((System.Drawing.Image)(resources.GetObject("button25.Image")));
            this.button25.Location = new System.Drawing.Point(144, 257);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(38, 31);
            this.button25.TabIndex = 28;
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // btn_dot
            // 
            this.btn_dot.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_dot.Image = ((System.Drawing.Image)(resources.GetObject("btn_dot.Image")));
            this.btn_dot.Location = new System.Drawing.Point(100, 257);
            this.btn_dot.Name = "btn_dot";
            this.btn_dot.Size = new System.Drawing.Size(38, 31);
            this.btn_dot.TabIndex = 27;
            this.btn_dot.UseVisualStyleBackColor = false;
            this.btn_dot.Click += new System.EventHandler(this.btn_dot_Click);
            // 
            // btn_0
            // 
            this.btn_0.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_0.Image = ((System.Drawing.Image)(resources.GetObject("btn_0.Image")));
            this.btn_0.Location = new System.Drawing.Point(12, 257);
            this.btn_0.Name = "btn_0";
            this.btn_0.Size = new System.Drawing.Size(82, 31);
            this.btn_0.TabIndex = 25;
            this.btn_0.UseVisualStyleBackColor = false;
            this.btn_0.Click += new System.EventHandler(this.btn_0_Click);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button29.Image = ((System.Drawing.Image)(resources.GetObject("button29.Image")));
            this.button29.Location = new System.Drawing.Point(188, 220);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(38, 68);
            this.button29.TabIndex = 29;
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // txtbx_output
            // 
            this.txtbx_output.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_output.Location = new System.Drawing.Point(12, 18);
            this.txtbx_output.MaxLength = 16;
            this.txtbx_output.Name = "txtbx_output";
            this.txtbx_output.Size = new System.Drawing.Size(214, 32);
            this.txtbx_output.TabIndex = 30;
            this.txtbx_output.Text = "0";
            this.txtbx_output.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtbx_output.TextChanged += new System.EventHandler(this.txtbx_output_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(244, 296);
            this.Controls.Add(this.txtbx_output);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.btn_dot);
            this.Controls.Add(this.btn_0);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.btn_3);
            this.Controls.Add(this.btn_2);
            this.Controls.Add(this.btn_1);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.btn_6);
            this.Controls.Add(this.btn_5);
            this.Controls.Add(this.btn_4);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.btn_9);
            this.Controls.Add(this.btn_8);
            this.Controls.Add(this.btn_7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button btn_9;
        private System.Windows.Forms.Button btn_8;
        private System.Windows.Forms.Button btn_7;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button btn_6;
        private System.Windows.Forms.Button btn_5;
        private System.Windows.Forms.Button btn_4;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button btn_3;
        private System.Windows.Forms.Button btn_2;
        private System.Windows.Forms.Button btn_1;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button btn_dot;
        private System.Windows.Forms.Button btn_0;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.TextBox txtbx_output;
    }
}

