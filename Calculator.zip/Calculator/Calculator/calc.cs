﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Calculator
{
    class calc
    {
       public double num1;
       public double num2;
       public double num3;
      
        public double firstvalue(double a,double c)
        {
            if (num1 == 0)
            {
                 num1 = a;
                 num2 = 0;
                return num1;
            }
            else
            {
                num2 = c;
                return num2;
            }
        }
        
        public double opr(string b)
        {
            if (b == "+")
            {
                 num3 = num1 + num2;
            }

            if (b == "*")
            {
                num3 = num1 * num2;
            }

            if (b == "-")
            {
                num3 = num1 - num2;
            }
            if (b == "/")
            {
                num3 = num1 / num2;
            }
            return num3;
          
        }
        
    }
}
