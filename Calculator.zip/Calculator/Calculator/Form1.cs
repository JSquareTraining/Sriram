﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string op1;
        string k1;
        string k2;
        string k3;
        calc cc = new calc();
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_1_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text = "1";
            }
            else
            {
                txtbx_output.Text += "1";
            }
        }

        private void btn_2_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text = "2";
            }
            else
            {
                txtbx_output.Text += "2";
            }
        }

        private void btn_3_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text = "3";
            }
            else
            {
                txtbx_output.Text += "3";
            }
        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text = "4";
            }
            else
            {
                txtbx_output.Text += "4";
            }
        }

        private void btn_5_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text = "5";
            }
            else
            {
                txtbx_output.Text += "5";
            }
        }

        private void btn_6_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text = "6";
            }
            else
            {
                txtbx_output.Text += "6";
            }
        }

        private void btn_7_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text = "7";
            }
            else
            {
                txtbx_output.Text += "7";
            }
        }

        private void btn_8_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text = "8";
            }
            else
            {
                txtbx_output.Text += "8";
            }
        }

        private void btn_9_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text = "9";
            }
            else
            {
                txtbx_output.Text += "9";
            }
        }

        private void btn_0_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text = "0";
            }
            else
            {
                txtbx_output.Text += "0";
            }
        }

        private void btn_dot_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text += ".";
            }
            else
            {
                txtbx_output.Text += ".";
            }
        }

        private void button25_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text += "+";
                string[] k = txtbx_output.Text.Split('+');
                k1 = string.Format("{0}", k);
                k2 = "+";
                k3 = "0";
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
                


                
            }
            else
            {
                txtbx_output.Text += "+";
                string[] k = txtbx_output.Text.Split('+');
                k1 = string.Format("{0}", k);         
                k2 = "+";
                k3 = "0";
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;




            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text += "-";
                string[] k = txtbx_output.Text.Split('+');
                k1 = string.Format("{0}", k);
                k2 = "-";
                k3 = "0";
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
            }
            else
            {
                txtbx_output.Text += "-";
               
                string[] k = txtbx_output.Text.Split('-');
                k1 = string.Format("{0}", k);
                k2 = "-";
                k3 = "0";




                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;


            }

        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text += "*";
                string[] k = txtbx_output.Text.Split('+');
                k1 = string.Format("{0}", k);
                k2 = "*";
                k3 = "0";
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
            }
            else
            {
                txtbx_output.Text += "*";
                string[] k = txtbx_output.Text.Split('*');
                k1 = string.Format("{0}", k);
                k2 = "*";
                k3 = "0";




                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (txtbx_output.Text == "0")
            {
                txtbx_output.Text += "/";
                string[] k = txtbx_output.Text.Split('+');
                k1 = string.Format("{0}", k);
                k2 = "/";
                k3 = "0";
                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
            }
            else
            {
                txtbx_output.Text += "/";
                string[] k = txtbx_output.Text.Split('/');
                k1 = string.Format("{0}", k);
                k2 = "/";
                k3 = "0";




                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
            }
        }

        private void button29_Click(object sender, EventArgs e)
        {
            if (k2 == "+")
            {
                string[] k = txtbx_output.Text.Split('+');
                k1 = string.Format("{0}", k);
                k2 = "+";
                k3 = string.Format("{1}",k);

               
                    cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                    cc.opr(k2);
                    op1 = k2;
                    txtbx_output.Text = Convert.ToString(cc.opr(op1));
                    cc.num1 = Convert.ToDouble(txtbx_output.Text);
                
                
            }
            else if (k2 == "*")
            {
                string[] k = txtbx_output.Text.Split('*');
                k1 = string.Format("{0}", k);
                k2 = "*";
                k3 = string.Format("{1}", k);
                if (k3 != "0")
                {
                    cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                    cc.opr(k2);
                    op1 = k2;
                    txtbx_output.Text = Convert.ToString(cc.opr(op1));
                    cc.num1 = Convert.ToDouble(txtbx_output.Text);
                }
                else
                {
                    txtbx_output.Text = "0";
                    cc.num1 = Convert.ToDouble(txtbx_output.Text);
                }

            }
            else if (k2 == "-")
            {
                string[] k = txtbx_output.Text.Split('-');
                k1 = string.Format("{0}", k);
                k2 = "-";
                k3 = string.Format("{1}", k);

                cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                cc.opr(k2);
                op1 = k2;
                txtbx_output.Text = Convert.ToString(cc.opr(op1));
                cc.num1 = Convert.ToDouble(txtbx_output.Text);

            }
            else if (k2 == "/")
            {
                string[] k = txtbx_output.Text.Split('/');
                k1 = string.Format("{0}", k);
                k2 = "/";
                k3 = string.Format("{1}", k);
                if (k1 == "0")
                {
                    txtbx_output.Text = Convert.ToString("Error");
                }
                else if (k3 == "0")
                {
                    txtbx_output.Text = "0";
                    cc.num1 = Convert.ToDouble(txtbx_output.Text);
                }
                else
                {
                    cc.firstvalue(Convert.ToDouble(k1), Convert.ToDouble(k3));
                    cc.opr(k2);
                    op1 = k2;
                    txtbx_output.Text = Convert.ToString(cc.opr(op1));
                    cc.num1 = Convert.ToDouble(txtbx_output.Text);
                }
            }

            
            
        }

        private void txtbx_output_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            txtbx_output.Clear();
            cc.num1 = 0;
            cc.num2 = 0;
            cc.num3 = 0;
        }

       
        
    }
}
