﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Diary
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       
        
        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Parent = pictureBox1;
            label1.BackColor = Color.Transparent;

            grpbx_Decide.Parent = pictureBox1;
            grpbx_Decide.BackColor = Color.Transparent;

            timer1.Interval = 500;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value < 100)
            {
                progressBar1.Value += 10;
            }
            else
            {
                if (rd_Login.Checked == true)
                {
                    timer1.Stop();
                    Form2 frm2 = new Form2();
                    frm2.ShowDialog();
                    this.Hide();
                }
                else
                {
                    timer1.Stop();
                    Form3 frm3 = new Form3();
                    frm3.ShowDialog();
                    this.Hide();
                }
            }
        }
    }
}
