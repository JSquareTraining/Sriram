﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Web_Browser
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                TextReader tr;
                tr = File.OpenText(@"C:\Web Browser\Bookmarks\Bookmark.txt");
                richTextBox1.Text = tr.ReadToEnd();
                tr.Dispose();

            }

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            TextReader tr1;
            tr1 = File.OpenText(@"C:\Web Browser\History\History.txt");
            richTextBox1.Text = tr1.ReadToEnd();
            tr1.Dispose();
        }

    

       
    }
}
