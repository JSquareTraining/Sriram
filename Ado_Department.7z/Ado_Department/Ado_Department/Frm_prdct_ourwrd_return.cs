﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ado_Department
{
    public partial class Frm_prdct_ourwrd_return : Form
    {
        public Frm_prdct_ourwrd_return()
        {
            InitializeComponent();
        }
        Connection sql_connection = new Connection();
        private void Frm_prdct_ourwrd_return_Load(object sender, EventArgs e)
        {
            object sr_id = sql_connection.connect("SELECT COUNT(SR_ID) FROM SALES_RETURN");
            if (Convert.ToInt32(sr_id) <= 0)
            {
                txtbx_prdct_otwrd_rtrn_id.Text = "SR1";
            }
            else
            {
                txtbx_prdct_otwrd_rtrn_id.Text = "SR" + (Convert.ToInt32(sr_id) + 1);
            }

            cmbx_prdct_otwrd_id.DisplayMember = "PO_ID";
            cmbx_prdct_otwrd_id.DataSource = sql_connection.table_data("SELECT PO_ID FROM PRODUCT_OUTWARD");
            dtgv_prdct_otwrd_return.DataSource = sql_connection.table_data("SELECT * FROM SALES_RETURN");
        }

        private void cmbx_prdct_otwrd_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                object p_name = sql_connection.connect("SELECT PNAME FROM PRODUCT_OUTWARD");
                txtbx_prdct_name.Text = sql_connection.connect("SELECT P_NAME FROM PRODUCT WHERE P_ID = '" + p_name + "'").ToString();
                txtbx_prdct_qntity.Text = sql_connection.connect("SELECT QUANTITY FROM PRODUCT_OUTWARD WHERE PO_ID = '" + cmbx_prdct_otwrd_id.Text + "'").ToString();
                txtbx_prchse_date.Text = sql_connection.connect("SELECT DATEE FROM PRODUCT_OUTWARD WHERE PO_ID = '" + cmbx_prdct_otwrd_id.Text + "'").ToString();
                txtbx_rtrn_quantity.Text = "0";
                txtbx_prdct_rtrn_amount.Text = "0";
            }
            catch (NullReferenceException ex)
            {
            }



        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (txtbx_prdct_name.Text == "" || txtbx_prdct_qntity.Text == "" || txtbx_prdct_rtrn_amount.Text == "" || txtbx_reason.Text == "" || txtbx_rtrn_quantity.Text == "")
            {
                MessageBox.Show("Please fill blank field");
            }
            else
            {
                object sr_id = sql_connection.connect("SELECT COUNT(SR_ID) FROM SALES_RETURN");
                if (Convert.ToInt32(sr_id) <= 0)
                {
                    txtbx_prdct_otwrd_rtrn_id.Text = "SR1";
                }
                else
                {
                    txtbx_prdct_otwrd_rtrn_id.Text = "SR" + (Convert.ToInt32(sr_id) + 1);
                }

                if (Convert.ToInt32(txtbx_prdct_qntity.Text) > Convert.ToInt32(txtbx_rtrn_quantity.Text))
                {
                    sql_connection.table_data("INSERT INTO SALES_RETURN VALUES('" + txtbx_prdct_otwrd_rtrn_id.Text + "','" + cmbx_prdct_otwrd_id.Text + "','" + txtbx_prdct_name.Text + "','" + txtbx_prdct_qntity.Text + "','" + txtbx_prchse_date.Text + "','" + txtbx_rtrn_quantity.Text + "','" + txtbx_prdct_rtrn_amount.Text + "','" + txtbx_reason.Text + "')");
                    dtgv_prdct_otwrd_return.DataSource = sql_connection.table_data("SELECT * FROM SALES_RETURN");
                }
                else
                {
                    MessageBox.Show("Please check the return quantity");
                }

                txtbx_prchse_date.Text = "";
                txtbx_prdct_name.Text = "";
                txtbx_prdct_otwrd_rtrn_id.Text = "";
                txtbx_prdct_qntity.Text = "";
                txtbx_prdct_rtrn_amount.Text = "";
                txtbx_reason.Text = "";
                txtbx_rtrn_quantity.Text = "";
            }
        }

        private void txtbx_rtrn_quantity_TextChanged(object sender, EventArgs e)
        {
            if (txtbx_rtrn_quantity.Text == "")
            {
                txtbx_rtrn_quantity.Text = "0";
            }

            object p_price = sql_connection.connect("SELECT SALES_PRICE FROM PRODUCT WHERE P_NAME = '"+txtbx_prdct_name.Text+"'");
            txtbx_prdct_rtrn_amount.Text = (Convert.ToInt32(txtbx_rtrn_quantity.Text) * Convert.ToInt32(p_price)).ToString();
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txtbx_prdct_name.Text == "" || txtbx_prdct_qntity.Text == "" || txtbx_prdct_rtrn_amount.Text == "" || txtbx_reason.Text == "" || txtbx_rtrn_quantity.Text == "")
            {
                MessageBox.Show("Please fill blank field");
            }
            else
            {
                try
                {
                    if (Convert.ToInt32(txtbx_prdct_qntity.Text) > Convert.ToInt32(txtbx_rtrn_quantity.Text))
                    {
                        sql_connection.table_data("UPDATE SALES_RETURN SET PO_ID = '" + cmbx_prdct_otwrd_id.Text + "',P_NAME = '" + txtbx_prdct_name.Text + "',QUANTITY = '" + txtbx_prdct_qntity.Text + "',DATEE = '" + txtbx_prchse_date.Text + "',RETURN_QUANTITY = '" + txtbx_rtrn_quantity.Text + "',AMOUNT = '" + txtbx_prdct_rtrn_amount.Text + "',REASON ='" + txtbx_reason.Text + "' WHERE SR_ID = '"+txtbx_prdct_otwrd_rtrn_id.Text+"'");
                        dtgv_prdct_otwrd_return.DataSource = sql_connection.table_data("SELECT * FROM SALES_RETURN");

                        txtbx_prchse_date.Text = "";
                        txtbx_prdct_name.Text = "";
                        txtbx_prdct_otwrd_rtrn_id.Text = "";
                        txtbx_prdct_qntity.Text = "";
                        txtbx_prdct_rtrn_amount.Text = "";
                        txtbx_reason.Text = "";
                        txtbx_rtrn_quantity.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("Please check the return quantity");
                    }
                }
                catch(NullReferenceException ex)
                {
                }
            }
        }

        private void dtgv_prdct_otwrd_return_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtbx_prdct_otwrd_rtrn_id.Text = sql_connection.connect("SELECT SR_ID FROM SALES_RETURN WHERE SR_ID ='" + dtgv_prdct_otwrd_return.CurrentCell.Value + "'").ToString();
                cmbx_prdct_otwrd_id.Text = sql_connection.connect("SELECT PO_ID FROM SALES_RETURN WHERE SR_ID = '" + dtgv_prdct_otwrd_return.CurrentCell.Value + "'").ToString();
                txtbx_prdct_name.Text = sql_connection.connect("SELECT P_NAME FROM SALES_RETURN WHERE SR_ID = '" + dtgv_prdct_otwrd_return.CurrentCell.Value + "'").ToString();
                txtbx_prdct_qntity.Text = sql_connection.connect("SELECT QUANTITY FROM SALES_RETURN WHERE SR_ID = '" + dtgv_prdct_otwrd_return.CurrentCell.Value + "'").ToString();
                txtbx_prchse_date.Text = sql_connection.connect("SELECT DATEE FROM SALES_RETURN WHERE SR_ID = '" + dtgv_prdct_otwrd_return.CurrentCell.Value + "'").ToString();
                txtbx_rtrn_quantity.Text = sql_connection.connect("SELECT RETURN_QUANTITY FROM SALES_RETURN WHERE SR_ID = '" + dtgv_prdct_otwrd_return.CurrentCell.Value + "'").ToString();
                txtbx_prdct_rtrn_amount.Text = sql_connection.connect("SELECT AMOUNT FROM SALES_RETURN WHERE SR_ID = '" + dtgv_prdct_otwrd_return.CurrentCell.Value + "'").ToString();
                txtbx_reason.Text = sql_connection.connect("SELECT REASON FROM SALES_RETURN WHERE SR_ID = '" + dtgv_prdct_otwrd_return.CurrentCell.Value + "'").ToString();
            }
            catch (NullReferenceException ex)
            {
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                sql_connection.table_data("DELETE SALES_RETURN WHERE SR_ID = '" + txtbx_prdct_otwrd_rtrn_id.Text + "'");
                dtgv_prdct_otwrd_return.DataSource = sql_connection.table_data("SELECT * FROM SALES_RETURN");

                txtbx_prchse_date.Text = "";
                txtbx_prdct_name.Text = "";
                txtbx_prdct_otwrd_rtrn_id.Text = "";
                txtbx_prdct_qntity.Text = "";
                txtbx_prdct_rtrn_amount.Text = "";
                txtbx_reason.Text = "";
                txtbx_rtrn_quantity.Text = "";
            }
            catch (NullReferenceException ex)
            {
            }
        }
    }
}
