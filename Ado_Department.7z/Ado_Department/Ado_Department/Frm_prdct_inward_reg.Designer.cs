﻿namespace Ado_Department
{
    partial class Frm_prdct_inward_reg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_prdct_inward_reg));
            this.pnl_prdct_inward_reg = new System.Windows.Forms.Panel();
            this.dtgv_prdct_inwrd_reg = new System.Windows.Forms.DataGridView();
            this.grpbx_prdct_inward = new System.Windows.Forms.GroupBox();
            this.btn_prdct_inwrd_reg_delete = new System.Windows.Forms.Button();
            this.btn_prdct_inwrd_reg_update = new System.Windows.Forms.Button();
            this.btn_prdct_inwrd_reg_submit = new System.Windows.Forms.Button();
            this.dtp_date_of_reg = new System.Windows.Forms.DateTimePicker();
            this.lbl_date_of_reg = new System.Windows.Forms.Label();
            this.cmbx_emp_name = new System.Windows.Forms.ComboBox();
            this.lbl_emp_name = new System.Windows.Forms.Label();
            this.txtbx_prdct_total_price = new Ado_Department.validate();
            this.lbl_prct_total_price = new System.Windows.Forms.Label();
            this.txtbx_prdct_qnty = new Ado_Department.validate();
            this.lbl_prdct_qnty = new System.Windows.Forms.Label();
            this.cmbx_prdct_name = new System.Windows.Forms.ComboBox();
            this.lbl_prdct_name = new System.Windows.Forms.Label();
            this.txtbx_prdct_inwrd_id = new System.Windows.Forms.TextBox();
            this.lbl_prdct_inwrd_id = new System.Windows.Forms.Label();
            this.lbl_prdct_inward_reg = new System.Windows.Forms.Label();
            this.pnl_prdct_inward_reg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_prdct_inwrd_reg)).BeginInit();
            this.grpbx_prdct_inward.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_prdct_inward_reg
            // 
            this.pnl_prdct_inward_reg.BackColor = System.Drawing.Color.AliceBlue;
            this.pnl_prdct_inward_reg.Controls.Add(this.dtgv_prdct_inwrd_reg);
            this.pnl_prdct_inward_reg.Controls.Add(this.grpbx_prdct_inward);
            this.pnl_prdct_inward_reg.Location = new System.Drawing.Point(12, 14);
            this.pnl_prdct_inward_reg.Name = "pnl_prdct_inward_reg";
            this.pnl_prdct_inward_reg.Size = new System.Drawing.Size(778, 447);
            this.pnl_prdct_inward_reg.TabIndex = 0;
            // 
            // dtgv_prdct_inwrd_reg
            // 
            this.dtgv_prdct_inwrd_reg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_prdct_inwrd_reg.Location = new System.Drawing.Point(14, 251);
            this.dtgv_prdct_inwrd_reg.Name = "dtgv_prdct_inwrd_reg";
            this.dtgv_prdct_inwrd_reg.Size = new System.Drawing.Size(749, 192);
            this.dtgv_prdct_inwrd_reg.TabIndex = 1;
            this.dtgv_prdct_inwrd_reg.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_prdct_inwrd_reg_CellContentClick);
            // 
            // grpbx_prdct_inward
            // 
            this.grpbx_prdct_inward.Controls.Add(this.btn_prdct_inwrd_reg_delete);
            this.grpbx_prdct_inward.Controls.Add(this.btn_prdct_inwrd_reg_update);
            this.grpbx_prdct_inward.Controls.Add(this.btn_prdct_inwrd_reg_submit);
            this.grpbx_prdct_inward.Controls.Add(this.dtp_date_of_reg);
            this.grpbx_prdct_inward.Controls.Add(this.lbl_date_of_reg);
            this.grpbx_prdct_inward.Controls.Add(this.cmbx_emp_name);
            this.grpbx_prdct_inward.Controls.Add(this.lbl_emp_name);
            this.grpbx_prdct_inward.Controls.Add(this.txtbx_prdct_total_price);
            this.grpbx_prdct_inward.Controls.Add(this.lbl_prct_total_price);
            this.grpbx_prdct_inward.Controls.Add(this.txtbx_prdct_qnty);
            this.grpbx_prdct_inward.Controls.Add(this.lbl_prdct_qnty);
            this.grpbx_prdct_inward.Controls.Add(this.cmbx_prdct_name);
            this.grpbx_prdct_inward.Controls.Add(this.lbl_prdct_name);
            this.grpbx_prdct_inward.Controls.Add(this.txtbx_prdct_inwrd_id);
            this.grpbx_prdct_inward.Controls.Add(this.lbl_prdct_inwrd_id);
            this.grpbx_prdct_inward.Controls.Add(this.lbl_prdct_inward_reg);
            this.grpbx_prdct_inward.Location = new System.Drawing.Point(14, 15);
            this.grpbx_prdct_inward.Name = "grpbx_prdct_inward";
            this.grpbx_prdct_inward.Size = new System.Drawing.Size(749, 231);
            this.grpbx_prdct_inward.TabIndex = 0;
            this.grpbx_prdct_inward.TabStop = false;
            // 
            // btn_prdct_inwrd_reg_delete
            // 
            this.btn_prdct_inwrd_reg_delete.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_prdct_inwrd_reg_delete.Image = ((System.Drawing.Image)(resources.GetObject("btn_prdct_inwrd_reg_delete.Image")));
            this.btn_prdct_inwrd_reg_delete.Location = new System.Drawing.Point(657, 188);
            this.btn_prdct_inwrd_reg_delete.Name = "btn_prdct_inwrd_reg_delete";
            this.btn_prdct_inwrd_reg_delete.Size = new System.Drawing.Size(83, 23);
            this.btn_prdct_inwrd_reg_delete.TabIndex = 23;
            this.btn_prdct_inwrd_reg_delete.Text = "Delete";
            this.btn_prdct_inwrd_reg_delete.UseVisualStyleBackColor = true;
            this.btn_prdct_inwrd_reg_delete.Click += new System.EventHandler(this.btn_prdct_inwrd_reg_delete_Click);
            // 
            // btn_prdct_inwrd_reg_update
            // 
            this.btn_prdct_inwrd_reg_update.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_prdct_inwrd_reg_update.Image = ((System.Drawing.Image)(resources.GetObject("btn_prdct_inwrd_reg_update.Image")));
            this.btn_prdct_inwrd_reg_update.Location = new System.Drawing.Point(492, 188);
            this.btn_prdct_inwrd_reg_update.Name = "btn_prdct_inwrd_reg_update";
            this.btn_prdct_inwrd_reg_update.Size = new System.Drawing.Size(83, 23);
            this.btn_prdct_inwrd_reg_update.TabIndex = 22;
            this.btn_prdct_inwrd_reg_update.Text = "Update";
            this.btn_prdct_inwrd_reg_update.UseVisualStyleBackColor = true;
            this.btn_prdct_inwrd_reg_update.Click += new System.EventHandler(this.btn_prdct_inwrd_reg_update_Click);
            // 
            // btn_prdct_inwrd_reg_submit
            // 
            this.btn_prdct_inwrd_reg_submit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_prdct_inwrd_reg_submit.Image = ((System.Drawing.Image)(resources.GetObject("btn_prdct_inwrd_reg_submit.Image")));
            this.btn_prdct_inwrd_reg_submit.Location = new System.Drawing.Point(575, 157);
            this.btn_prdct_inwrd_reg_submit.Name = "btn_prdct_inwrd_reg_submit";
            this.btn_prdct_inwrd_reg_submit.Size = new System.Drawing.Size(83, 23);
            this.btn_prdct_inwrd_reg_submit.TabIndex = 21;
            this.btn_prdct_inwrd_reg_submit.Text = "Submit";
            this.btn_prdct_inwrd_reg_submit.UseVisualStyleBackColor = true;
            this.btn_prdct_inwrd_reg_submit.Click += new System.EventHandler(this.btn_prdct_inwrd_reg_submit_Click);
            // 
            // dtp_date_of_reg
            // 
            this.dtp_date_of_reg.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_date_of_reg.Location = new System.Drawing.Point(540, 122);
            this.dtp_date_of_reg.Name = "dtp_date_of_reg";
            this.dtp_date_of_reg.Size = new System.Drawing.Size(200, 22);
            this.dtp_date_of_reg.TabIndex = 12;
            // 
            // lbl_date_of_reg
            // 
            this.lbl_date_of_reg.AutoSize = true;
            this.lbl_date_of_reg.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date_of_reg.Location = new System.Drawing.Point(396, 128);
            this.lbl_date_of_reg.Name = "lbl_date_of_reg";
            this.lbl_date_of_reg.Size = new System.Drawing.Size(136, 15);
            this.lbl_date_of_reg.TabIndex = 11;
            this.lbl_date_of_reg.Text = "Date of Registration";
            // 
            // cmbx_emp_name
            // 
            this.cmbx_emp_name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_emp_name.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_emp_name.FormattingEnabled = true;
            this.cmbx_emp_name.Location = new System.Drawing.Point(540, 78);
            this.cmbx_emp_name.Name = "cmbx_emp_name";
            this.cmbx_emp_name.Size = new System.Drawing.Size(203, 23);
            this.cmbx_emp_name.TabIndex = 10;
            // 
            // lbl_emp_name
            // 
            this.lbl_emp_name.AutoSize = true;
            this.lbl_emp_name.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_emp_name.Location = new System.Drawing.Point(418, 86);
            this.lbl_emp_name.Name = "lbl_emp_name";
            this.lbl_emp_name.Size = new System.Drawing.Size(112, 15);
            this.lbl_emp_name.TabIndex = 9;
            this.lbl_emp_name.Text = "Employee Name";
            // 
            // txtbx_prdct_total_price
            // 
            this.txtbx_prdct_total_price.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_total_price.Location = new System.Drawing.Point(162, 189);
            this.txtbx_prdct_total_price.Name = "txtbx_prdct_total_price";
            this.txtbx_prdct_total_price.ReadOnly = true;
            this.txtbx_prdct_total_price.Size = new System.Drawing.Size(222, 22);
            this.txtbx_prdct_total_price.TabIndex = 8;
            // 
            // lbl_prct_total_price
            // 
            this.lbl_prct_total_price.AutoSize = true;
            this.lbl_prct_total_price.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prct_total_price.Location = new System.Drawing.Point(69, 195);
            this.lbl_prct_total_price.Name = "lbl_prct_total_price";
            this.lbl_prct_total_price.Size = new System.Drawing.Size(78, 15);
            this.lbl_prct_total_price.TabIndex = 7;
            this.lbl_prct_total_price.Text = "Total Price";
            // 
            // txtbx_prdct_qnty
            // 
            this.txtbx_prdct_qnty.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_qnty.Location = new System.Drawing.Point(162, 147);
            this.txtbx_prdct_qnty.Name = "txtbx_prdct_qnty";
            this.txtbx_prdct_qnty.Size = new System.Drawing.Size(222, 22);
            this.txtbx_prdct_qnty.TabIndex = 6;
            this.txtbx_prdct_qnty.TextChanged += new System.EventHandler(this.txtbx_prdct_qnty_TextChanged);
            // 
            // lbl_prdct_qnty
            // 
            this.lbl_prdct_qnty.AutoSize = true;
            this.lbl_prdct_qnty.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prdct_qnty.Location = new System.Drawing.Point(85, 153);
            this.lbl_prdct_qnty.Name = "lbl_prdct_qnty";
            this.lbl_prdct_qnty.Size = new System.Drawing.Size(62, 15);
            this.lbl_prdct_qnty.TabIndex = 5;
            this.lbl_prdct_qnty.Text = "Quantity";
            // 
            // cmbx_prdct_name
            // 
            this.cmbx_prdct_name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_prdct_name.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_prdct_name.FormattingEnabled = true;
            this.cmbx_prdct_name.Location = new System.Drawing.Point(162, 103);
            this.cmbx_prdct_name.Name = "cmbx_prdct_name";
            this.cmbx_prdct_name.Size = new System.Drawing.Size(222, 23);
            this.cmbx_prdct_name.TabIndex = 4;
            this.cmbx_prdct_name.SelectedIndexChanged += new System.EventHandler(this.cmbx_prdct_name_SelectedIndexChanged);
            // 
            // lbl_prdct_name
            // 
            this.lbl_prdct_name.AutoSize = true;
            this.lbl_prdct_name.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prdct_name.Location = new System.Drawing.Point(47, 108);
            this.lbl_prdct_name.Name = "lbl_prdct_name";
            this.lbl_prdct_name.Size = new System.Drawing.Size(100, 15);
            this.lbl_prdct_name.TabIndex = 3;
            this.lbl_prdct_name.Text = "Product Name";
            // 
            // txtbx_prdct_inwrd_id
            // 
            this.txtbx_prdct_inwrd_id.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_inwrd_id.Location = new System.Drawing.Point(162, 59);
            this.txtbx_prdct_inwrd_id.Name = "txtbx_prdct_inwrd_id";
            this.txtbx_prdct_inwrd_id.ReadOnly = true;
            this.txtbx_prdct_inwrd_id.Size = new System.Drawing.Size(222, 22);
            this.txtbx_prdct_inwrd_id.TabIndex = 2;
            // 
            // lbl_prdct_inwrd_id
            // 
            this.lbl_prdct_inwrd_id.AutoSize = true;
            this.lbl_prdct_inwrd_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prdct_inwrd_id.Location = new System.Drawing.Point(25, 62);
            this.lbl_prdct_inwrd_id.Name = "lbl_prdct_inwrd_id";
            this.lbl_prdct_inwrd_id.Size = new System.Drawing.Size(122, 15);
            this.lbl_prdct_inwrd_id.TabIndex = 1;
            this.lbl_prdct_inwrd_id.Text = "Product Inward Id";
            // 
            // lbl_prdct_inward_reg
            // 
            this.lbl_prdct_inward_reg.AutoSize = true;
            this.lbl_prdct_inward_reg.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prdct_inward_reg.Location = new System.Drawing.Point(229, 16);
            this.lbl_prdct_inward_reg.Name = "lbl_prdct_inward_reg";
            this.lbl_prdct_inward_reg.Size = new System.Drawing.Size(268, 22);
            this.lbl_prdct_inward_reg.TabIndex = 0;
            this.lbl_prdct_inward_reg.Text = "Product Inward Registration";
            // 
            // Frm_prdct_inward_reg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(803, 472);
            this.Controls.Add(this.pnl_prdct_inward_reg);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_prdct_inward_reg";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form9";
            this.Load += new System.EventHandler(this.Frm_prdct_inward_reg_Load);
            this.pnl_prdct_inward_reg.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_prdct_inwrd_reg)).EndInit();
            this.grpbx_prdct_inward.ResumeLayout(false);
            this.grpbx_prdct_inward.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_prdct_inward_reg;
        private System.Windows.Forms.GroupBox grpbx_prdct_inward;
        private System.Windows.Forms.Label lbl_prdct_inwrd_id;
        private System.Windows.Forms.Label lbl_prdct_inward_reg;
        private System.Windows.Forms.TextBox txtbx_prdct_inwrd_id;
        private System.Windows.Forms.Label lbl_prdct_name;
        private System.Windows.Forms.Label lbl_prdct_qnty;
        private System.Windows.Forms.ComboBox cmbx_prdct_name;
        private validate txtbx_prdct_total_price;
        private System.Windows.Forms.Label lbl_prct_total_price;
        private validate txtbx_prdct_qnty;
        private System.Windows.Forms.Label lbl_emp_name;
        private System.Windows.Forms.ComboBox cmbx_emp_name;
        private System.Windows.Forms.Label lbl_date_of_reg;
        private System.Windows.Forms.DateTimePicker dtp_date_of_reg;
        private System.Windows.Forms.Button btn_prdct_inwrd_reg_delete;
        private System.Windows.Forms.Button btn_prdct_inwrd_reg_update;
        private System.Windows.Forms.Button btn_prdct_inwrd_reg_submit;
        private System.Windows.Forms.DataGridView dtgv_prdct_inwrd_reg;
    }
}