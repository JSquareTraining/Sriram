﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ado_Department
{
    public partial class Frm_sales_search : Form
    {
        public Frm_sales_search()
        {
            InitializeComponent();
        }
        Connection sql_connection = new Connection();
        private void btn_prdct_outwrd_search_Click(object sender, EventArgs e)
        {
            if (txtbx_prdct_outwrd_search.Text == "")
            {
                MessageBox.Show("Please enter the search field");
            }
            else
            {
                if (rdbtn_prdct_outwrd.Checked == true)
                {
                    dtgv_prdct_outwrd_search.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT_OUTWARD WHERE PO_ID = '" + txtbx_prdct_outwrd_search.Text + "' OR PNAME = '" + txtbx_prdct_outwrd_search.Text + "' OR QUANTITY = '" + txtbx_prdct_outwrd_search.Text + "' OR TOTAL_PRICE = '" + txtbx_prdct_outwrd_search.Text + "' OR E_NAME = '" + txtbx_prdct_outwrd_search.Text + "' OR DATEE = '" + txtbx_prdct_outwrd_search.Text + "'");
                    txtbx_prdct_outwrd_search.Text = "";
                }
                else
                {
                    dtgv_prdct_outwrd_search.DataSource = sql_connection.table_data("SELECT * FROM SALES_RETURN WHERE SR_ID = '"+txtbx_prdct_outwrd_search.Text+"' OR PO_ID = '"+txtbx_prdct_outwrd_search.Text+"' OR P_NAME = '"+txtbx_prdct_outwrd_search.Text+"' OR QUANTITY = '"+txtbx_prdct_outwrd_search.Text+"' OR DATEE = '"+txtbx_prdct_outwrd_search.Text+"' OR RETURN_QUANTITY = '"+txtbx_prdct_outwrd_search.Text+"' OR AMOUNT = '"+txtbx_prdct_outwrd_search.Text+"' OR REASON = '"+txtbx_prdct_outwrd_search.Text+"'");
                    txtbx_prdct_outwrd_search.Text = "";
                }
            }
        }
    }
}
