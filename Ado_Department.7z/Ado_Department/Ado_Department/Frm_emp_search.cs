﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ado_Department
{
    public partial class Frm_emp_search : Form
    {
        public Frm_emp_search()
        {
            InitializeComponent();
        }
        Connection sql_connection = new Connection();
        private void btn_emp_search_Click(object sender, EventArgs e)
        {
            if (txtbx_emp_search.Text == "")
            {
                MessageBox.Show("Please enter E-ID/PHONE NUMBER/E-MAIL");
            }
            else
            {
                dtgv_emp_search.DataSource = sql_connection.table_data("SELECT * FROM EMPLOYEE WHERE E_ID LIKE '" + txtbx_emp_search.Text + "%' OR EMAIL LIKE '" + txtbx_emp_search.Text + "%' OR CONTACTNO LIKE '" + txtbx_emp_search.Text + "%'"); 
                txtbx_emp_search.Text = "";
            }
        }
    }
}
