﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ado_Department
{
    public partial class Frm_prct_search : Form
    {
        public Frm_prct_search()
        {
            InitializeComponent();
        }
        Connection sql_connection = new Connection();
        private void btn_prdct_search_Click(object sender, EventArgs e)
        {
            dtgv_prdct_search.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT WHERE P_ID = '" + txtbx_prdct_search.Text + "' OR P_NAME = '" + txtbx_prdct_search.Text + "' OR PRODUCT_PRICE = '" + txtbx_prdct_search.Text + "' OR SALES_PRICE = '" + txtbx_prdct_search.Text + "' OR DATEE = '" + txtbx_prdct_search.Text + "'");
            txtbx_prdct_search.Text = "";
        }
    }
}
