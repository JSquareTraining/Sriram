﻿namespace Ado_Department
{
    partial class Frm_prct_search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_prct_search));
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtgv_prdct_search = new System.Windows.Forms.DataGridView();
            this.btn_prdct_search = new System.Windows.Forms.Button();
            this.lbl_search = new System.Windows.Forms.Label();
            this.txtbx_prdct_search = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_prdct_search)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.AliceBlue;
            this.panel1.Controls.Add(this.dtgv_prdct_search);
            this.panel1.Controls.Add(this.btn_prdct_search);
            this.panel1.Controls.Add(this.lbl_search);
            this.panel1.Controls.Add(this.txtbx_prdct_search);
            this.panel1.Location = new System.Drawing.Point(13, 14);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(778, 447);
            this.panel1.TabIndex = 0;
            // 
            // dtgv_prdct_search
            // 
            this.dtgv_prdct_search.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_prdct_search.Location = new System.Drawing.Point(14, 118);
            this.dtgv_prdct_search.Name = "dtgv_prdct_search";
            this.dtgv_prdct_search.Size = new System.Drawing.Size(750, 309);
            this.dtgv_prdct_search.TabIndex = 11;
            // 
            // btn_prdct_search
            // 
            this.btn_prdct_search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_prdct_search.Image = ((System.Drawing.Image)(resources.GetObject("btn_prdct_search.Image")));
            this.btn_prdct_search.Location = new System.Drawing.Point(663, 57);
            this.btn_prdct_search.Name = "btn_prdct_search";
            this.btn_prdct_search.Size = new System.Drawing.Size(101, 26);
            this.btn_prdct_search.TabIndex = 10;
            this.btn_prdct_search.Text = "Search";
            this.btn_prdct_search.UseVisualStyleBackColor = true;
            this.btn_prdct_search.Click += new System.EventHandler(this.btn_prdct_search_Click);
            // 
            // lbl_search
            // 
            this.lbl_search.AutoSize = true;
            this.lbl_search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_search.Location = new System.Drawing.Point(339, 19);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(75, 22);
            this.lbl_search.TabIndex = 9;
            this.lbl_search.Text = "Search";
            // 
            // txtbx_prdct_search
            // 
            this.txtbx_prdct_search.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_search.Location = new System.Drawing.Point(14, 57);
            this.txtbx_prdct_search.Name = "txtbx_prdct_search";
            this.txtbx_prdct_search.Size = new System.Drawing.Size(648, 26);
            this.txtbx_prdct_search.TabIndex = 8;
            // 
            // Frm_prct_search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(803, 472);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_prct_search";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_prdct_search)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dtgv_prdct_search;
        private System.Windows.Forms.Button btn_prdct_search;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.TextBox txtbx_prdct_search;
    }
}