﻿namespace Ado_Department
{
    partial class Frm_Prdct_Reg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Prdct_Reg));
            this.pnl_prdct_reg = new System.Windows.Forms.Panel();
            this.dtgv_prdct_reg = new System.Windows.Forms.DataGridView();
            this.grpbx_prdct_reg = new System.Windows.Forms.GroupBox();
            this.btn_prdct_delete = new System.Windows.Forms.Button();
            this.btn_prdct_update = new System.Windows.Forms.Button();
            this.btn_prdct_save = new System.Windows.Forms.Button();
            this.lbl_dte_of_reg = new System.Windows.Forms.Label();
            this.txtbx_sales_price = new Ado_Department.validate();
            this.lbl_sales_price = new System.Windows.Forms.Label();
            this.txtbx_prdct_price = new Ado_Department.validate();
            this.lbl_prdct_price = new System.Windows.Forms.Label();
            this.txtbx_prdct_name = new System.Windows.Forms.TextBox();
            this.lbl_prdct_name = new System.Windows.Forms.Label();
            this.txtbx_prdct_id = new System.Windows.Forms.TextBox();
            this.lbl_prdct_id = new System.Windows.Forms.Label();
            this.lbl_prdct_reg = new System.Windows.Forms.Label();
            this.dtp_dte_of_reg = new System.Windows.Forms.DateTimePicker();
            this.pnl_prdct_reg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_prdct_reg)).BeginInit();
            this.grpbx_prdct_reg.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_prdct_reg
            // 
            this.pnl_prdct_reg.BackColor = System.Drawing.Color.AliceBlue;
            this.pnl_prdct_reg.Controls.Add(this.dtgv_prdct_reg);
            this.pnl_prdct_reg.Controls.Add(this.grpbx_prdct_reg);
            this.pnl_prdct_reg.Location = new System.Drawing.Point(12, 13);
            this.pnl_prdct_reg.Name = "pnl_prdct_reg";
            this.pnl_prdct_reg.Size = new System.Drawing.Size(778, 447);
            this.pnl_prdct_reg.TabIndex = 0;
            // 
            // dtgv_prdct_reg
            // 
            this.dtgv_prdct_reg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_prdct_reg.Location = new System.Drawing.Point(20, 242);
            this.dtgv_prdct_reg.Name = "dtgv_prdct_reg";
            this.dtgv_prdct_reg.Size = new System.Drawing.Size(740, 202);
            this.dtgv_prdct_reg.TabIndex = 1;
            this.dtgv_prdct_reg.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_prdct_reg_CellContentClick);
            // 
            // grpbx_prdct_reg
            // 
            this.grpbx_prdct_reg.Controls.Add(this.dtp_dte_of_reg);
            this.grpbx_prdct_reg.Controls.Add(this.btn_prdct_delete);
            this.grpbx_prdct_reg.Controls.Add(this.btn_prdct_update);
            this.grpbx_prdct_reg.Controls.Add(this.btn_prdct_save);
            this.grpbx_prdct_reg.Controls.Add(this.lbl_dte_of_reg);
            this.grpbx_prdct_reg.Controls.Add(this.txtbx_sales_price);
            this.grpbx_prdct_reg.Controls.Add(this.lbl_sales_price);
            this.grpbx_prdct_reg.Controls.Add(this.txtbx_prdct_price);
            this.grpbx_prdct_reg.Controls.Add(this.lbl_prdct_price);
            this.grpbx_prdct_reg.Controls.Add(this.txtbx_prdct_name);
            this.grpbx_prdct_reg.Controls.Add(this.lbl_prdct_name);
            this.grpbx_prdct_reg.Controls.Add(this.txtbx_prdct_id);
            this.grpbx_prdct_reg.Controls.Add(this.lbl_prdct_id);
            this.grpbx_prdct_reg.Controls.Add(this.lbl_prdct_reg);
            this.grpbx_prdct_reg.Location = new System.Drawing.Point(20, 14);
            this.grpbx_prdct_reg.Name = "grpbx_prdct_reg";
            this.grpbx_prdct_reg.Size = new System.Drawing.Size(740, 222);
            this.grpbx_prdct_reg.TabIndex = 0;
            this.grpbx_prdct_reg.TabStop = false;
            // 
            // btn_prdct_delete
            // 
            this.btn_prdct_delete.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_prdct_delete.Image = ((System.Drawing.Image)(resources.GetObject("btn_prdct_delete.Image")));
            this.btn_prdct_delete.Location = new System.Drawing.Point(476, 189);
            this.btn_prdct_delete.Name = "btn_prdct_delete";
            this.btn_prdct_delete.Size = new System.Drawing.Size(101, 27);
            this.btn_prdct_delete.TabIndex = 13;
            this.btn_prdct_delete.Text = "Delete";
            this.btn_prdct_delete.UseVisualStyleBackColor = true;
            this.btn_prdct_delete.Click += new System.EventHandler(this.btn_prdct_delete_Click);
            // 
            // btn_prdct_update
            // 
            this.btn_prdct_update.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_prdct_update.Image = ((System.Drawing.Image)(resources.GetObject("btn_prdct_update.Image")));
            this.btn_prdct_update.Location = new System.Drawing.Point(334, 189);
            this.btn_prdct_update.Name = "btn_prdct_update";
            this.btn_prdct_update.Size = new System.Drawing.Size(101, 27);
            this.btn_prdct_update.TabIndex = 12;
            this.btn_prdct_update.Text = "Update";
            this.btn_prdct_update.UseVisualStyleBackColor = true;
            this.btn_prdct_update.Click += new System.EventHandler(this.btn_prdct_update_Click);
            // 
            // btn_prdct_save
            // 
            this.btn_prdct_save.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_prdct_save.Image = ((System.Drawing.Image)(resources.GetObject("btn_prdct_save.Image")));
            this.btn_prdct_save.Location = new System.Drawing.Point(189, 189);
            this.btn_prdct_save.Name = "btn_prdct_save";
            this.btn_prdct_save.Size = new System.Drawing.Size(101, 27);
            this.btn_prdct_save.TabIndex = 11;
            this.btn_prdct_save.Text = "Save";
            this.btn_prdct_save.UseVisualStyleBackColor = true;
            this.btn_prdct_save.Click += new System.EventHandler(this.btn_prdct_save_Click);
            // 
            // lbl_dte_of_reg
            // 
            this.lbl_dte_of_reg.AutoSize = true;
            this.lbl_dte_of_reg.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dte_of_reg.Location = new System.Drawing.Point(189, 154);
            this.lbl_dte_of_reg.Name = "lbl_dte_of_reg";
            this.lbl_dte_of_reg.Size = new System.Drawing.Size(136, 15);
            this.lbl_dte_of_reg.TabIndex = 9;
            this.lbl_dte_of_reg.Text = "Date of Registration";
            // 
            // txtbx_sales_price
            // 
            this.txtbx_sales_price.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_sales_price.Location = new System.Drawing.Point(504, 106);
            this.txtbx_sales_price.Name = "txtbx_sales_price";
            this.txtbx_sales_price.Size = new System.Drawing.Size(222, 22);
            this.txtbx_sales_price.TabIndex = 8;
            // 
            // lbl_sales_price
            // 
            this.lbl_sales_price.AutoSize = true;
            this.lbl_sales_price.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sales_price.Location = new System.Drawing.Point(400, 109);
            this.lbl_sales_price.Name = "lbl_sales_price";
            this.lbl_sales_price.Size = new System.Drawing.Size(81, 15);
            this.lbl_sales_price.TabIndex = 7;
            this.lbl_sales_price.Text = "Sales Price";
            // 
            // txtbx_prdct_price
            // 
            this.txtbx_prdct_price.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_price.Location = new System.Drawing.Point(504, 59);
            this.txtbx_prdct_price.Name = "txtbx_prdct_price";
            this.txtbx_prdct_price.Size = new System.Drawing.Size(222, 22);
            this.txtbx_prdct_price.TabIndex = 6;
            // 
            // lbl_prdct_price
            // 
            this.lbl_prdct_price.AutoSize = true;
            this.lbl_prdct_price.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prdct_price.Location = new System.Drawing.Point(384, 62);
            this.lbl_prdct_price.Name = "lbl_prdct_price";
            this.lbl_prdct_price.Size = new System.Drawing.Size(97, 15);
            this.lbl_prdct_price.TabIndex = 5;
            this.lbl_prdct_price.Text = "Product Price";
            // 
            // txtbx_prdct_name
            // 
            this.txtbx_prdct_name.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_name.Location = new System.Drawing.Point(129, 106);
            this.txtbx_prdct_name.Name = "txtbx_prdct_name";
            this.txtbx_prdct_name.Size = new System.Drawing.Size(222, 22);
            this.txtbx_prdct_name.TabIndex = 4;
            // 
            // lbl_prdct_name
            // 
            this.lbl_prdct_name.AutoSize = true;
            this.lbl_prdct_name.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prdct_name.Location = new System.Drawing.Point(10, 113);
            this.lbl_prdct_name.Name = "lbl_prdct_name";
            this.lbl_prdct_name.Size = new System.Drawing.Size(100, 15);
            this.lbl_prdct_name.TabIndex = 3;
            this.lbl_prdct_name.Text = "Product Name";
            // 
            // txtbx_prdct_id
            // 
            this.txtbx_prdct_id.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_id.Location = new System.Drawing.Point(129, 59);
            this.txtbx_prdct_id.Name = "txtbx_prdct_id";
            this.txtbx_prdct_id.ReadOnly = true;
            this.txtbx_prdct_id.Size = new System.Drawing.Size(222, 22);
            this.txtbx_prdct_id.TabIndex = 2;
            // 
            // lbl_prdct_id
            // 
            this.lbl_prdct_id.AutoSize = true;
            this.lbl_prdct_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prdct_id.Location = new System.Drawing.Point(36, 62);
            this.lbl_prdct_id.Name = "lbl_prdct_id";
            this.lbl_prdct_id.Size = new System.Drawing.Size(74, 15);
            this.lbl_prdct_id.TabIndex = 1;
            this.lbl_prdct_id.Text = "Product Id";
            // 
            // lbl_prdct_reg
            // 
            this.lbl_prdct_reg.AutoSize = true;
            this.lbl_prdct_reg.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prdct_reg.Location = new System.Drawing.Point(274, 16);
            this.lbl_prdct_reg.Name = "lbl_prdct_reg";
            this.lbl_prdct_reg.Size = new System.Drawing.Size(200, 22);
            this.lbl_prdct_reg.TabIndex = 0;
            this.lbl_prdct_reg.Text = "Product Registration";
            // 
            // dtp_dte_of_reg
            // 
            this.dtp_dte_of_reg.CalendarFont = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_dte_of_reg.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_dte_of_reg.Location = new System.Drawing.Point(347, 150);
            this.dtp_dte_of_reg.Name = "dtp_dte_of_reg";
            this.dtp_dte_of_reg.Size = new System.Drawing.Size(230, 22);
            this.dtp_dte_of_reg.TabIndex = 14;
            // 
            // Frm_Prdct_Reg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(803, 472);
            this.Controls.Add(this.pnl_prdct_reg);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_Prdct_Reg";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Frm_Prdct_Reg_Load);
            this.pnl_prdct_reg.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_prdct_reg)).EndInit();
            this.grpbx_prdct_reg.ResumeLayout(false);
            this.grpbx_prdct_reg.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_prdct_reg;
        private System.Windows.Forms.GroupBox grpbx_prdct_reg;
        private System.Windows.Forms.DataGridView dtgv_prdct_reg;
        private System.Windows.Forms.Label lbl_prdct_reg;
        private System.Windows.Forms.Label lbl_prdct_id;
        private System.Windows.Forms.TextBox txtbx_prdct_name;
        private System.Windows.Forms.Label lbl_prdct_name;
        private System.Windows.Forms.TextBox txtbx_prdct_id;
        private System.Windows.Forms.Label lbl_prdct_price;
        private System.Windows.Forms.Label lbl_sales_price;
        private validate txtbx_prdct_price;
        private validate txtbx_sales_price;
        private System.Windows.Forms.Label lbl_dte_of_reg;
        private System.Windows.Forms.Button btn_prdct_save;
        private System.Windows.Forms.Button btn_prdct_update;
        private System.Windows.Forms.Button btn_prdct_delete;
        private System.Windows.Forms.DateTimePicker dtp_dte_of_reg;
    }
}