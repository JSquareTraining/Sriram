﻿namespace Ado_Department
{
    partial class Frm_dept_search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_dept_search));
            this.pnl_dept_search = new System.Windows.Forms.Panel();
            this.dtgv_dept_search = new System.Windows.Forms.DataGridView();
            this.btn_dept_search = new System.Windows.Forms.Button();
            this.lbl_search = new System.Windows.Forms.Label();
            this.txtbx_dept_search = new System.Windows.Forms.TextBox();
            this.pnl_dept_search.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_dept_search)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_dept_search
            // 
            this.pnl_dept_search.BackColor = System.Drawing.Color.AliceBlue;
            this.pnl_dept_search.Controls.Add(this.dtgv_dept_search);
            this.pnl_dept_search.Controls.Add(this.btn_dept_search);
            this.pnl_dept_search.Controls.Add(this.lbl_search);
            this.pnl_dept_search.Controls.Add(this.txtbx_dept_search);
            this.pnl_dept_search.Location = new System.Drawing.Point(12, 13);
            this.pnl_dept_search.Name = "pnl_dept_search";
            this.pnl_dept_search.Size = new System.Drawing.Size(778, 447);
            this.pnl_dept_search.TabIndex = 0;
            // 
            // dtgv_dept_search
            // 
            this.dtgv_dept_search.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_dept_search.Location = new System.Drawing.Point(18, 112);
            this.dtgv_dept_search.Name = "dtgv_dept_search";
            this.dtgv_dept_search.Size = new System.Drawing.Size(739, 309);
            this.dtgv_dept_search.TabIndex = 3;
            // 
            // btn_dept_search
            // 
            this.btn_dept_search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_dept_search.Image = ((System.Drawing.Image)(resources.GetObject("btn_dept_search.Image")));
            this.btn_dept_search.Location = new System.Drawing.Point(667, 51);
            this.btn_dept_search.Name = "btn_dept_search";
            this.btn_dept_search.Size = new System.Drawing.Size(101, 26);
            this.btn_dept_search.TabIndex = 2;
            this.btn_dept_search.Text = "Search";
            this.btn_dept_search.UseVisualStyleBackColor = true;
            this.btn_dept_search.Click += new System.EventHandler(this.btn_dept_search_Click);
            // 
            // lbl_search
            // 
            this.lbl_search.AutoSize = true;
            this.lbl_search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_search.Location = new System.Drawing.Point(322, 14);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(75, 22);
            this.lbl_search.TabIndex = 1;
            this.lbl_search.Text = "Search";
            // 
            // txtbx_dept_search
            // 
            this.txtbx_dept_search.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_dept_search.Location = new System.Drawing.Point(18, 51);
            this.txtbx_dept_search.Name = "txtbx_dept_search";
            this.txtbx_dept_search.Size = new System.Drawing.Size(648, 26);
            this.txtbx_dept_search.TabIndex = 0;
            // 
            // Frm_dept_search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(803, 472);
            this.Controls.Add(this.pnl_dept_search);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_dept_search";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search";
            this.pnl_dept_search.ResumeLayout(false);
            this.pnl_dept_search.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_dept_search)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_dept_search;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.TextBox txtbx_dept_search;
        private System.Windows.Forms.Button btn_dept_search;
        private System.Windows.Forms.DataGridView dtgv_dept_search;
    }
}