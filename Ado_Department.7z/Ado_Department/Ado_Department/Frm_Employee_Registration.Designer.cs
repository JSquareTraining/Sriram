﻿namespace Ado_Department
{
    partial class Frm_Employee_Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Employee_Registration));
            this.pnl_employee_registration = new System.Windows.Forms.Panel();
            this.dtgv_emp_reg = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_emp_reg_delete = new System.Windows.Forms.Button();
            this.btn_emp_reg_update = new System.Windows.Forms.Button();
            this.btn_emp_reg_submit = new System.Windows.Forms.Button();
            this.lbl_dept_name = new System.Windows.Forms.Label();
            this.cmbx_dept_name = new System.Windows.Forms.ComboBox();
            this.txtbx_email_id = new System.Windows.Forms.TextBox();
            this.lbl_emil_id = new System.Windows.Forms.Label();
            this.lbl_phn_nmbr = new System.Windows.Forms.Label();
            this.lbl_city = new System.Windows.Forms.Label();
            this.txtbx_emp_address = new System.Windows.Forms.TextBox();
            this.lbl_address = new System.Windows.Forms.Label();
            this.rdbtn_female = new System.Windows.Forms.RadioButton();
            this.rdbtn_male = new System.Windows.Forms.RadioButton();
            this.lbl_gender = new System.Windows.Forms.Label();
            this.lbl_emp_name = new System.Windows.Forms.Label();
            this.txtbx_emp_id = new System.Windows.Forms.TextBox();
            this.lbl_emp_id = new System.Windows.Forms.Label();
            this.lbl_employee_registration = new System.Windows.Forms.Label();
            this.txtbx_city = new Ado_Department.validate_text();
            this.txtbx_emp_name = new Ado_Department.validate_text();
            this.txtbx_phn_nmbr = new Ado_Department.validate();
            this.pnl_employee_registration.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_emp_reg)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_employee_registration
            // 
            this.pnl_employee_registration.BackColor = System.Drawing.Color.AliceBlue;
            this.pnl_employee_registration.Controls.Add(this.dtgv_emp_reg);
            this.pnl_employee_registration.Controls.Add(this.groupBox1);
            this.pnl_employee_registration.Location = new System.Drawing.Point(11, 14);
            this.pnl_employee_registration.Name = "pnl_employee_registration";
            this.pnl_employee_registration.Size = new System.Drawing.Size(778, 447);
            this.pnl_employee_registration.TabIndex = 0;
            // 
            // dtgv_emp_reg
            // 
            this.dtgv_emp_reg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_emp_reg.Location = new System.Drawing.Point(21, 305);
            this.dtgv_emp_reg.Name = "dtgv_emp_reg";
            this.dtgv_emp_reg.Size = new System.Drawing.Size(738, 139);
            this.dtgv_emp_reg.TabIndex = 1;
            this.dtgv_emp_reg.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_emp_reg_CellContentClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtbx_city);
            this.groupBox1.Controls.Add(this.txtbx_emp_name);
            this.groupBox1.Controls.Add(this.txtbx_phn_nmbr);
            this.groupBox1.Controls.Add(this.btn_emp_reg_delete);
            this.groupBox1.Controls.Add(this.btn_emp_reg_update);
            this.groupBox1.Controls.Add(this.btn_emp_reg_submit);
            this.groupBox1.Controls.Add(this.lbl_dept_name);
            this.groupBox1.Controls.Add(this.cmbx_dept_name);
            this.groupBox1.Controls.Add(this.txtbx_email_id);
            this.groupBox1.Controls.Add(this.lbl_emil_id);
            this.groupBox1.Controls.Add(this.lbl_phn_nmbr);
            this.groupBox1.Controls.Add(this.lbl_city);
            this.groupBox1.Controls.Add(this.txtbx_emp_address);
            this.groupBox1.Controls.Add(this.lbl_address);
            this.groupBox1.Controls.Add(this.rdbtn_female);
            this.groupBox1.Controls.Add(this.rdbtn_male);
            this.groupBox1.Controls.Add(this.lbl_gender);
            this.groupBox1.Controls.Add(this.lbl_emp_name);
            this.groupBox1.Controls.Add(this.txtbx_emp_id);
            this.groupBox1.Controls.Add(this.lbl_emp_id);
            this.groupBox1.Controls.Add(this.lbl_employee_registration);
            this.groupBox1.Location = new System.Drawing.Point(21, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(738, 295);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // btn_emp_reg_delete
            // 
            this.btn_emp_reg_delete.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_emp_reg_delete.Image = ((System.Drawing.Image)(resources.GetObject("btn_emp_reg_delete.Image")));
            this.btn_emp_reg_delete.Location = new System.Drawing.Point(562, 266);
            this.btn_emp_reg_delete.Name = "btn_emp_reg_delete";
            this.btn_emp_reg_delete.Size = new System.Drawing.Size(83, 23);
            this.btn_emp_reg_delete.TabIndex = 20;
            this.btn_emp_reg_delete.Text = "Delete";
            this.btn_emp_reg_delete.UseVisualStyleBackColor = true;
            this.btn_emp_reg_delete.Click += new System.EventHandler(this.btn_emp_reg_delete_Click);
            // 
            // btn_emp_reg_update
            // 
            this.btn_emp_reg_update.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_emp_reg_update.Image = ((System.Drawing.Image)(resources.GetObject("btn_emp_reg_update.Image")));
            this.btn_emp_reg_update.Location = new System.Drawing.Point(614, 231);
            this.btn_emp_reg_update.Name = "btn_emp_reg_update";
            this.btn_emp_reg_update.Size = new System.Drawing.Size(83, 23);
            this.btn_emp_reg_update.TabIndex = 19;
            this.btn_emp_reg_update.Text = "Update";
            this.btn_emp_reg_update.UseVisualStyleBackColor = true;
            this.btn_emp_reg_update.Click += new System.EventHandler(this.btn_emp_reg_update_Click);
            // 
            // btn_emp_reg_submit
            // 
            this.btn_emp_reg_submit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_emp_reg_submit.Image = ((System.Drawing.Image)(resources.GetObject("btn_emp_reg_submit.Image")));
            this.btn_emp_reg_submit.Location = new System.Drawing.Point(510, 231);
            this.btn_emp_reg_submit.Name = "btn_emp_reg_submit";
            this.btn_emp_reg_submit.Size = new System.Drawing.Size(83, 23);
            this.btn_emp_reg_submit.TabIndex = 18;
            this.btn_emp_reg_submit.Text = "Submit";
            this.btn_emp_reg_submit.UseVisualStyleBackColor = true;
            this.btn_emp_reg_submit.Click += new System.EventHandler(this.btn_emp_reg_submit_Click);
            // 
            // lbl_dept_name
            // 
            this.lbl_dept_name.AutoSize = true;
            this.lbl_dept_name.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dept_name.Location = new System.Drawing.Point(350, 200);
            this.lbl_dept_name.Name = "lbl_dept_name";
            this.lbl_dept_name.Size = new System.Drawing.Size(126, 15);
            this.lbl_dept_name.TabIndex = 17;
            this.lbl_dept_name.Text = "Department Name";
            // 
            // cmbx_dept_name
            // 
            this.cmbx_dept_name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_dept_name.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_dept_name.FormattingEnabled = true;
            this.cmbx_dept_name.Location = new System.Drawing.Point(498, 192);
            this.cmbx_dept_name.Name = "cmbx_dept_name";
            this.cmbx_dept_name.Size = new System.Drawing.Size(225, 23);
            this.cmbx_dept_name.TabIndex = 16;
            // 
            // txtbx_email_id
            // 
            this.txtbx_email_id.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_email_id.Location = new System.Drawing.Point(498, 150);
            this.txtbx_email_id.Name = "txtbx_email_id";
            this.txtbx_email_id.Size = new System.Drawing.Size(225, 22);
            this.txtbx_email_id.TabIndex = 15;
            // 
            // lbl_emil_id
            // 
            this.lbl_emil_id.AutoSize = true;
            this.lbl_emil_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_emil_id.Location = new System.Drawing.Point(417, 154);
            this.lbl_emil_id.Name = "lbl_emil_id";
            this.lbl_emil_id.Size = new System.Drawing.Size(59, 15);
            this.lbl_emil_id.TabIndex = 14;
            this.lbl_emil_id.Text = "Email Id";
            // 
            // lbl_phn_nmbr
            // 
            this.lbl_phn_nmbr.AutoSize = true;
            this.lbl_phn_nmbr.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_phn_nmbr.Location = new System.Drawing.Point(373, 106);
            this.lbl_phn_nmbr.Name = "lbl_phn_nmbr";
            this.lbl_phn_nmbr.Size = new System.Drawing.Size(103, 15);
            this.lbl_phn_nmbr.TabIndex = 12;
            this.lbl_phn_nmbr.Text = "Phone Number";
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_city.Location = new System.Drawing.Point(443, 58);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(33, 15);
            this.lbl_city.TabIndex = 10;
            this.lbl_city.Text = "City";
            // 
            // txtbx_emp_address
            // 
            this.txtbx_emp_address.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_emp_address.Location = new System.Drawing.Point(140, 192);
            this.txtbx_emp_address.Multiline = true;
            this.txtbx_emp_address.Name = "txtbx_emp_address";
            this.txtbx_emp_address.Size = new System.Drawing.Size(203, 97);
            this.txtbx_emp_address.TabIndex = 9;
            // 
            // lbl_address
            // 
            this.lbl_address.AutoSize = true;
            this.lbl_address.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_address.Location = new System.Drawing.Point(61, 195);
            this.lbl_address.Name = "lbl_address";
            this.lbl_address.Size = new System.Drawing.Size(60, 15);
            this.lbl_address.TabIndex = 8;
            this.lbl_address.Text = "Address";
            // 
            // rdbtn_female
            // 
            this.rdbtn_female.AutoSize = true;
            this.rdbtn_female.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_female.Location = new System.Drawing.Point(220, 150);
            this.rdbtn_female.Name = "rdbtn_female";
            this.rdbtn_female.Size = new System.Drawing.Size(62, 19);
            this.rdbtn_female.TabIndex = 7;
            this.rdbtn_female.Text = "Female";
            this.rdbtn_female.UseVisualStyleBackColor = true;
            // 
            // rdbtn_male
            // 
            this.rdbtn_male.AutoSize = true;
            this.rdbtn_male.Checked = true;
            this.rdbtn_male.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_male.Location = new System.Drawing.Point(140, 150);
            this.rdbtn_male.Name = "rdbtn_male";
            this.rdbtn_male.Size = new System.Drawing.Size(52, 19);
            this.rdbtn_male.TabIndex = 6;
            this.rdbtn_male.TabStop = true;
            this.rdbtn_male.Text = "Male";
            this.rdbtn_male.UseVisualStyleBackColor = true;
            // 
            // lbl_gender
            // 
            this.lbl_gender.AutoSize = true;
            this.lbl_gender.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gender.Location = new System.Drawing.Point(66, 154);
            this.lbl_gender.Name = "lbl_gender";
            this.lbl_gender.Size = new System.Drawing.Size(55, 15);
            this.lbl_gender.TabIndex = 5;
            this.lbl_gender.Text = "Gender";
            // 
            // lbl_emp_name
            // 
            this.lbl_emp_name.AutoSize = true;
            this.lbl_emp_name.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_emp_name.Location = new System.Drawing.Point(9, 110);
            this.lbl_emp_name.Name = "lbl_emp_name";
            this.lbl_emp_name.Size = new System.Drawing.Size(112, 15);
            this.lbl_emp_name.TabIndex = 3;
            this.lbl_emp_name.Text = "Employee Name";
            // 
            // txtbx_emp_id
            // 
            this.txtbx_emp_id.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_emp_id.Location = new System.Drawing.Point(140, 55);
            this.txtbx_emp_id.Name = "txtbx_emp_id";
            this.txtbx_emp_id.ReadOnly = true;
            this.txtbx_emp_id.Size = new System.Drawing.Size(203, 22);
            this.txtbx_emp_id.TabIndex = 2;
            // 
            // lbl_emp_id
            // 
            this.lbl_emp_id.AutoSize = true;
            this.lbl_emp_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_emp_id.Location = new System.Drawing.Point(35, 58);
            this.lbl_emp_id.Name = "lbl_emp_id";
            this.lbl_emp_id.Size = new System.Drawing.Size(86, 15);
            this.lbl_emp_id.TabIndex = 1;
            this.lbl_emp_id.Text = "Employee Id";
            // 
            // lbl_employee_registration
            // 
            this.lbl_employee_registration.AutoSize = true;
            this.lbl_employee_registration.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employee_registration.Location = new System.Drawing.Point(259, 16);
            this.lbl_employee_registration.Name = "lbl_employee_registration";
            this.lbl_employee_registration.Size = new System.Drawing.Size(228, 22);
            this.lbl_employee_registration.TabIndex = 0;
            this.lbl_employee_registration.Text = "Employee Registeration";
            // 
            // txtbx_city
            // 
            this.txtbx_city.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_city.Location = new System.Drawing.Point(498, 55);
            this.txtbx_city.Name = "txtbx_city";
            this.txtbx_city.ReadOnly = true;
            this.txtbx_city.Size = new System.Drawing.Size(225, 22);
            this.txtbx_city.TabIndex = 23;
            // 
            // txtbx_emp_name
            // 
            this.txtbx_emp_name.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_emp_name.Location = new System.Drawing.Point(140, 105);
            this.txtbx_emp_name.Name = "txtbx_emp_name";
            this.txtbx_emp_name.Size = new System.Drawing.Size(203, 22);
            this.txtbx_emp_name.TabIndex = 22;
            // 
            // txtbx_phn_nmbr
            // 
            this.txtbx_phn_nmbr.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_phn_nmbr.Location = new System.Drawing.Point(498, 103);
            this.txtbx_phn_nmbr.MaxLength = 10;
            this.txtbx_phn_nmbr.Name = "txtbx_phn_nmbr";
            this.txtbx_phn_nmbr.Size = new System.Drawing.Size(225, 22);
            this.txtbx_phn_nmbr.TabIndex = 21;
            // 
            // Frm_Employee_Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(803, 472);
            this.Controls.Add(this.pnl_employee_registration);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_Employee_Registration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Frm_Employee_Registration_Load);
            this.pnl_employee_registration.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_emp_reg)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_employee_registration;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbl_employee_registration;
        private System.Windows.Forms.Label lbl_emp_id;
        private System.Windows.Forms.Label lbl_emp_name;
        private System.Windows.Forms.TextBox txtbx_emp_id;
        private System.Windows.Forms.Label lbl_gender;
        private System.Windows.Forms.RadioButton rdbtn_male;
        private System.Windows.Forms.RadioButton rdbtn_female;
        private System.Windows.Forms.Label lbl_address;
        private System.Windows.Forms.TextBox txtbx_emp_address;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.Label lbl_phn_nmbr;
        private System.Windows.Forms.Label lbl_emil_id;
        private System.Windows.Forms.Label lbl_dept_name;
        private System.Windows.Forms.ComboBox cmbx_dept_name;
        private System.Windows.Forms.TextBox txtbx_email_id;
        private System.Windows.Forms.DataGridView dtgv_emp_reg;
        private System.Windows.Forms.Button btn_emp_reg_submit;
        private System.Windows.Forms.Button btn_emp_reg_update;
        private System.Windows.Forms.Button btn_emp_reg_delete;
        private validate txtbx_phn_nmbr;
        private validate_text txtbx_emp_name;
        private validate_text txtbx_city;
    }
}