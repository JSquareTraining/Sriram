﻿namespace Ado_Department
{
    partial class Frm_prdct_otwrd_regstn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_prdct_otwrd_regstn));
            this.pnl_prdct_otwrd_reg = new System.Windows.Forms.Panel();
            this.dtgv = new System.Windows.Forms.DataGridView();
            this.grbx_prdct_outwrd_reg = new System.Windows.Forms.GroupBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.txtbx_date = new System.Windows.Forms.TextBox();
            this.btn_update = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_save = new System.Windows.Forms.Button();
            this.cmbx_emp_name = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtbx_total_price = new Ado_Department.validate();
            this.label5 = new System.Windows.Forms.Label();
            this.txtbx_prdct_qnty = new Ado_Department.validate();
            this.cmbx_prdct_name = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtbx_prdct_outwrd_id = new Ado_Department.validate();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_prdct_otwrd_reg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv)).BeginInit();
            this.grbx_prdct_outwrd_reg.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_prdct_otwrd_reg
            // 
            this.pnl_prdct_otwrd_reg.BackColor = System.Drawing.Color.AliceBlue;
            this.pnl_prdct_otwrd_reg.Controls.Add(this.dtgv);
            this.pnl_prdct_otwrd_reg.Controls.Add(this.grbx_prdct_outwrd_reg);
            this.pnl_prdct_otwrd_reg.Location = new System.Drawing.Point(13, 11);
            this.pnl_prdct_otwrd_reg.Name = "pnl_prdct_otwrd_reg";
            this.pnl_prdct_otwrd_reg.Size = new System.Drawing.Size(778, 447);
            this.pnl_prdct_otwrd_reg.TabIndex = 0;
            // 
            // dtgv
            // 
            this.dtgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv.Location = new System.Drawing.Point(16, 224);
            this.dtgv.Name = "dtgv";
            this.dtgv.Size = new System.Drawing.Size(747, 220);
            this.dtgv.TabIndex = 1;
            this.dtgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_CellContentClick);
            // 
            // grbx_prdct_outwrd_reg
            // 
            this.grbx_prdct_outwrd_reg.Controls.Add(this.btn_delete);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.txtbx_date);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.btn_update);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.label7);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.btn_save);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.cmbx_emp_name);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.label6);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.txtbx_total_price);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.label5);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.txtbx_prdct_qnty);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.cmbx_prdct_name);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.label4);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.label3);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.txtbx_prdct_outwrd_id);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.label2);
            this.grbx_prdct_outwrd_reg.Controls.Add(this.label1);
            this.grbx_prdct_outwrd_reg.Location = new System.Drawing.Point(16, 9);
            this.grbx_prdct_outwrd_reg.Name = "grbx_prdct_outwrd_reg";
            this.grbx_prdct_outwrd_reg.Size = new System.Drawing.Size(747, 208);
            this.grbx_prdct_outwrd_reg.TabIndex = 0;
            this.grbx_prdct_outwrd_reg.TabStop = false;
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Image = ((System.Drawing.Image)(resources.GetObject("btn_delete.Image")));
            this.btn_delete.Location = new System.Drawing.Point(645, 170);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(96, 25);
            this.btn_delete.TabIndex = 24;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // txtbx_date
            // 
            this.txtbx_date.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_date.Location = new System.Drawing.Point(504, 112);
            this.txtbx_date.Name = "txtbx_date";
            this.txtbx_date.ReadOnly = true;
            this.txtbx_date.Size = new System.Drawing.Size(210, 22);
            this.txtbx_date.TabIndex = 13;
            // 
            // btn_update
            // 
            this.btn_update.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Image = ((System.Drawing.Image)(resources.GetObject("btn_update.Image")));
            this.btn_update.Location = new System.Drawing.Point(477, 172);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(97, 25);
            this.btn_update.TabIndex = 23;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(459, 118);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 15);
            this.label7.TabIndex = 12;
            this.label7.Text = "Date";
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.Image = ((System.Drawing.Image)(resources.GetObject("btn_save.Image")));
            this.btn_save.Location = new System.Drawing.Point(558, 140);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(98, 25);
            this.btn_save.TabIndex = 22;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // cmbx_emp_name
            // 
            this.cmbx_emp_name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_emp_name.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_emp_name.FormattingEnabled = true;
            this.cmbx_emp_name.Location = new System.Drawing.Point(503, 67);
            this.cmbx_emp_name.Name = "cmbx_emp_name";
            this.cmbx_emp_name.Size = new System.Drawing.Size(211, 23);
            this.cmbx_emp_name.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(385, 73);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "Employee Name";
            // 
            // txtbx_total_price
            // 
            this.txtbx_total_price.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_total_price.Location = new System.Drawing.Point(151, 170);
            this.txtbx_total_price.Name = "txtbx_total_price";
            this.txtbx_total_price.ReadOnly = true;
            this.txtbx_total_price.Size = new System.Drawing.Size(208, 22);
            this.txtbx_total_price.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(61, 173);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "Total Price";
            // 
            // txtbx_prdct_qnty
            // 
            this.txtbx_prdct_qnty.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_qnty.Location = new System.Drawing.Point(151, 130);
            this.txtbx_prdct_qnty.Name = "txtbx_prdct_qnty";
            this.txtbx_prdct_qnty.Size = new System.Drawing.Size(208, 22);
            this.txtbx_prdct_qnty.TabIndex = 7;
            this.txtbx_prdct_qnty.TextChanged += new System.EventHandler(this.txtbx_prdct_qnty_TextChanged);
            // 
            // cmbx_prdct_name
            // 
            this.cmbx_prdct_name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_prdct_name.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_prdct_name.FormattingEnabled = true;
            this.cmbx_prdct_name.Location = new System.Drawing.Point(151, 88);
            this.cmbx_prdct_name.Name = "cmbx_prdct_name";
            this.cmbx_prdct_name.Size = new System.Drawing.Size(208, 23);
            this.cmbx_prdct_name.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(22, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 15);
            this.label4.TabIndex = 5;
            this.label4.Text = "Product Quantity";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(39, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Product Name";
            // 
            // txtbx_prdct_outwrd_id
            // 
            this.txtbx_prdct_outwrd_id.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_outwrd_id.Location = new System.Drawing.Point(151, 48);
            this.txtbx_prdct_outwrd_id.Name = "txtbx_prdct_outwrd_id";
            this.txtbx_prdct_outwrd_id.ReadOnly = true;
            this.txtbx_prdct_outwrd_id.Size = new System.Drawing.Size(208, 22);
            this.txtbx_prdct_outwrd_id.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Product Outward Id";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(198, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(284, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product Outward Registration";
            // 
            // Frm_prdct_otwrd_regstn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(803, 472);
            this.Controls.Add(this.pnl_prdct_otwrd_reg);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_prdct_otwrd_regstn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Frm_prdct_otwrd_regstn_Load);
            this.pnl_prdct_otwrd_reg.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv)).EndInit();
            this.grbx_prdct_outwrd_reg.ResumeLayout(false);
            this.grbx_prdct_outwrd_reg.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_prdct_otwrd_reg;
        private System.Windows.Forms.GroupBox grbx_prdct_outwrd_reg;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private validate txtbx_prdct_outwrd_id;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbx_prdct_name;
        private System.Windows.Forms.Label label4;
        private validate txtbx_prdct_qnty;
        private System.Windows.Forms.Label label5;
        private validate txtbx_total_price;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbx_emp_name;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtbx_date;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.DataGridView dtgv;
    }
}