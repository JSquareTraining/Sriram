﻿namespace Ado_Department
{
    partial class Frm_sales_search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_sales_search));
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbtn_sales_return = new System.Windows.Forms.RadioButton();
            this.rdbtn_prdct_outwrd = new System.Windows.Forms.RadioButton();
            this.lbl_search = new System.Windows.Forms.Label();
            this.dtgv_prdct_outwrd_search = new System.Windows.Forms.DataGridView();
            this.btn_prdct_outwrd_search = new System.Windows.Forms.Button();
            this.txtbx_prdct_outwrd_search = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_prdct_outwrd_search)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.AliceBlue;
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.lbl_search);
            this.panel1.Controls.Add(this.dtgv_prdct_outwrd_search);
            this.panel1.Controls.Add(this.btn_prdct_outwrd_search);
            this.panel1.Controls.Add(this.txtbx_prdct_outwrd_search);
            this.panel1.Location = new System.Drawing.Point(11, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(778, 447);
            this.panel1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbtn_sales_return);
            this.groupBox1.Controls.Add(this.rdbtn_prdct_outwrd);
            this.groupBox1.Location = new System.Drawing.Point(240, 79);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(316, 35);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            // 
            // rdbtn_sales_return
            // 
            this.rdbtn_sales_return.AutoSize = true;
            this.rdbtn_sales_return.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_sales_return.Location = new System.Drawing.Point(171, 12);
            this.rdbtn_sales_return.Name = "rdbtn_sales_return";
            this.rdbtn_sales_return.Size = new System.Drawing.Size(108, 19);
            this.rdbtn_sales_return.TabIndex = 1;
            this.rdbtn_sales_return.Text = "Sales Return";
            this.rdbtn_sales_return.UseVisualStyleBackColor = true;
            // 
            // rdbtn_prdct_outwrd
            // 
            this.rdbtn_prdct_outwrd.AutoSize = true;
            this.rdbtn_prdct_outwrd.Checked = true;
            this.rdbtn_prdct_outwrd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_prdct_outwrd.Location = new System.Drawing.Point(17, 12);
            this.rdbtn_prdct_outwrd.Name = "rdbtn_prdct_outwrd";
            this.rdbtn_prdct_outwrd.Size = new System.Drawing.Size(136, 19);
            this.rdbtn_prdct_outwrd.TabIndex = 0;
            this.rdbtn_prdct_outwrd.TabStop = true;
            this.rdbtn_prdct_outwrd.Text = "Product Outward";
            this.rdbtn_prdct_outwrd.UseVisualStyleBackColor = true;
            // 
            // lbl_search
            // 
            this.lbl_search.AutoSize = true;
            this.lbl_search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_search.Location = new System.Drawing.Point(339, 15);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(75, 22);
            this.lbl_search.TabIndex = 18;
            this.lbl_search.Text = "Search";
            // 
            // dtgv_prdct_outwrd_search
            // 
            this.dtgv_prdct_outwrd_search.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_prdct_outwrd_search.Location = new System.Drawing.Point(14, 118);
            this.dtgv_prdct_outwrd_search.Name = "dtgv_prdct_outwrd_search";
            this.dtgv_prdct_outwrd_search.Size = new System.Drawing.Size(750, 314);
            this.dtgv_prdct_outwrd_search.TabIndex = 20;
            // 
            // btn_prdct_outwrd_search
            // 
            this.btn_prdct_outwrd_search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_prdct_outwrd_search.Image = ((System.Drawing.Image)(resources.GetObject("btn_prdct_outwrd_search.Image")));
            this.btn_prdct_outwrd_search.Location = new System.Drawing.Point(663, 53);
            this.btn_prdct_outwrd_search.Name = "btn_prdct_outwrd_search";
            this.btn_prdct_outwrd_search.Size = new System.Drawing.Size(101, 26);
            this.btn_prdct_outwrd_search.TabIndex = 19;
            this.btn_prdct_outwrd_search.Text = "Search";
            this.btn_prdct_outwrd_search.UseVisualStyleBackColor = true;
            this.btn_prdct_outwrd_search.Click += new System.EventHandler(this.btn_prdct_outwrd_search_Click);
            // 
            // txtbx_prdct_outwrd_search
            // 
            this.txtbx_prdct_outwrd_search.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_outwrd_search.Location = new System.Drawing.Point(14, 53);
            this.txtbx_prdct_outwrd_search.Name = "txtbx_prdct_outwrd_search";
            this.txtbx_prdct_outwrd_search.Size = new System.Drawing.Size(648, 26);
            this.txtbx_prdct_outwrd_search.TabIndex = 17;
            // 
            // Frm_sales_search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(803, 472);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_sales_search";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_prdct_outwrd_search)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbtn_sales_return;
        private System.Windows.Forms.RadioButton rdbtn_prdct_outwrd;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.DataGridView dtgv_prdct_outwrd_search;
        private System.Windows.Forms.Button btn_prdct_outwrd_search;
        private System.Windows.Forms.TextBox txtbx_prdct_outwrd_search;
    }
}