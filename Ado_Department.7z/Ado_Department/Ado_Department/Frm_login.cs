﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ado_Department
{
    public partial class Frm_login : Form
    {
        public Frm_login()
        {
            InitializeComponent();
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_lgn_Click(object sender, EventArgs e)
        {
            SqlConnection s_connection = new SqlConnection(@"Data Source=IMRANA\SQLExpress;Initial Catalog=DEPARTMENT_STORE;Integrated Security=True");
            s_connection.Open();
            string login_check = "SELECT * FROM ADMIN_LOGIN";
            SqlCommand s_command = new SqlCommand(login_check,s_connection);          
            object checking = s_command.ExecuteScalar();
            s_connection.Close();
            if (txtbx_usrnme.Text == "" || txtbx_pswd.Text == "")
            {
                MessageBox.Show("Please enter the username/password");
            }
            else if (txtbx_usrnme.Text == checking.ToString() && txtbx_pswd.Text == checking.ToString())
            {
                Frm_Main frm_main = new Frm_Main();
                this.Hide();
                frm_main.Show();
            }
            else
            {
                MessageBox.Show("Please check username/password");
            }
        }
    }
}
