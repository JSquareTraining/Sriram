﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ado_Department
{
    public partial class Frm_Main : Form
    {
        public Frm_Main()
        {
            InitializeComponent();
        }

        private void tmi_regstn_Click(object sender, EventArgs e)
        {
            Frm_Dept_Reg frm_dept_reg = new Frm_Dept_Reg();
            frm_dept_reg.MdiParent = this;
            frm_dept_reg.Show();
        }

        private void tmi_search_Click(object sender, EventArgs e)
        {
            Frm_dept_search frm_dept_search = new Frm_dept_search();
            frm_dept_search.MdiParent = this;
            frm_dept_search.Show();
        }

        private void tmi_emp_regstrtn_Click(object sender, EventArgs e)
        {
            Frm_Employee_Registration frm_emp_reg = new Frm_Employee_Registration();
            frm_emp_reg.MdiParent = this;
            frm_emp_reg.Show();
        }

        private void tmi_emp_search_Click(object sender, EventArgs e)
        {
            Frm_emp_search frm_emp_search = new Frm_emp_search();
            frm_emp_search.MdiParent = this;
            frm_emp_search.Show();
        }

        private void tmi_prdct_regstn_Click(object sender, EventArgs e)
        {
            Frm_Prdct_Reg frm_prdct_reg = new Frm_Prdct_Reg();
            frm_prdct_reg.MdiParent = this;
            frm_prdct_reg.Show();
        }

        private void tmi_prdct_srch_Click(object sender, EventArgs e)
        {
            Frm_prct_search frm_prct_search = new Frm_prct_search();
            frm_prct_search.MdiParent = this;
            frm_prct_search.Show();
        }

        private void tmi_purcse_inward_Click(object sender, EventArgs e)
        {
            Frm_prdct_inward_reg frm_prdct_inward_reg = new Frm_prdct_inward_reg();
            frm_prdct_inward_reg.MdiParent = this;
            frm_prdct_inward_reg.Show();
        }

        private void tsm_purchase_Click(object sender, EventArgs e)
        {

        }

        private void tmi_prchse_search_Click(object sender, EventArgs e)
        {
            Frm_Prdct_Inwrd_Search frm_prdct_inwrd_search = new Frm_Prdct_Inwrd_Search();
            frm_prdct_inwrd_search.MdiParent = this;
            frm_prdct_inwrd_search.Show();
        }

        private void tmi_prchse_rtrn_Click(object sender, EventArgs e)
        {
            Frm_prdct_inwrd_return frm_prdct_inwrd_return = new Frm_prdct_inwrd_return();
            frm_prdct_inwrd_return.MdiParent = this;
            frm_prdct_inwrd_return.Show();
        }

        private void tmi_sales_outward_Click(object sender, EventArgs e)
        {
            Frm_prdct_otwrd_regstn frm_prdct_outwrd_regtrn = new Frm_prdct_otwrd_regstn();
            frm_prdct_outwrd_regtrn.MdiParent = this;
            frm_prdct_outwrd_regtrn.Show();
        }

        private void tmi_sales_return_Click(object sender, EventArgs e)
        {
            Frm_prdct_ourwrd_return frm_prdct_outwrd_return = new Frm_prdct_ourwrd_return();
            frm_prdct_outwrd_return.MdiParent = this;
            frm_prdct_outwrd_return.Show();
        }

        private void tmi_sales_search_Click(object sender, EventArgs e)
        {
            Frm_sales_search frm_sales_search = new Frm_sales_search();
            frm_sales_search.MdiParent = this;
            frm_sales_search.Show();
        }

        private void Frm_Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
