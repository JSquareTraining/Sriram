﻿namespace Ado_Department
{
    partial class Frm_emp_search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_emp_search));
            this.pnl_emp_search = new System.Windows.Forms.Panel();
            this.dtgv_emp_search = new System.Windows.Forms.DataGridView();
            this.btn_emp_search = new System.Windows.Forms.Button();
            this.lbl_search = new System.Windows.Forms.Label();
            this.txtbx_emp_search = new System.Windows.Forms.TextBox();
            this.pnl_emp_search.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_emp_search)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_emp_search
            // 
            this.pnl_emp_search.BackColor = System.Drawing.Color.AliceBlue;
            this.pnl_emp_search.Controls.Add(this.dtgv_emp_search);
            this.pnl_emp_search.Controls.Add(this.btn_emp_search);
            this.pnl_emp_search.Controls.Add(this.lbl_search);
            this.pnl_emp_search.Controls.Add(this.txtbx_emp_search);
            this.pnl_emp_search.Location = new System.Drawing.Point(12, 13);
            this.pnl_emp_search.Name = "pnl_emp_search";
            this.pnl_emp_search.Size = new System.Drawing.Size(778, 447);
            this.pnl_emp_search.TabIndex = 0;
            // 
            // dtgv_emp_search
            // 
            this.dtgv_emp_search.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_emp_search.Location = new System.Drawing.Point(14, 118);
            this.dtgv_emp_search.Name = "dtgv_emp_search";
            this.dtgv_emp_search.Size = new System.Drawing.Size(750, 309);
            this.dtgv_emp_search.TabIndex = 7;
            // 
            // btn_emp_search
            // 
            this.btn_emp_search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_emp_search.Image = ((System.Drawing.Image)(resources.GetObject("btn_emp_search.Image")));
            this.btn_emp_search.Location = new System.Drawing.Point(663, 57);
            this.btn_emp_search.Name = "btn_emp_search";
            this.btn_emp_search.Size = new System.Drawing.Size(101, 26);
            this.btn_emp_search.TabIndex = 6;
            this.btn_emp_search.Text = "Search";
            this.btn_emp_search.UseVisualStyleBackColor = true;
            this.btn_emp_search.Click += new System.EventHandler(this.btn_emp_search_Click);
            // 
            // lbl_search
            // 
            this.lbl_search.AutoSize = true;
            this.lbl_search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_search.Location = new System.Drawing.Point(339, 19);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(75, 22);
            this.lbl_search.TabIndex = 5;
            this.lbl_search.Text = "Search";
            // 
            // txtbx_emp_search
            // 
            this.txtbx_emp_search.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_emp_search.Location = new System.Drawing.Point(14, 57);
            this.txtbx_emp_search.Name = "txtbx_emp_search";
            this.txtbx_emp_search.Size = new System.Drawing.Size(648, 26);
            this.txtbx_emp_search.TabIndex = 4;
            // 
            // Frm_emp_search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(803, 472);
            this.Controls.Add(this.pnl_emp_search);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_emp_search";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.pnl_emp_search.ResumeLayout(false);
            this.pnl_emp_search.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_emp_search)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_emp_search;
        private System.Windows.Forms.DataGridView dtgv_emp_search;
        private System.Windows.Forms.Button btn_emp_search;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.TextBox txtbx_emp_search;
    }
}