﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ado_Department
{
    public partial class Frm_Dept_Reg : Form
    {
        public Frm_Dept_Reg()
        {
            InitializeComponent();
        }
        Connection sql_connection = new Connection();
        private void Frm_Dept_Reg_Load(object sender, EventArgs e)
        {           
            object check_dept = sql_connection.connect("SELECT COUNT(D_ID) FROM DEPARTMENT GROUP BY D_ID HAVING D_ID = 'D1'");
            if (check_dept == null)
            {
                txtbx_dept_id.Text = "D1";
            }
            else
            {
                txtbx_dept_id.Text = "D2";
            }
            dtgv_dept_reg.DataSource = sql_connection.table_data("SELECT * FROM DEPARTMENT");
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (cmbx_dept_name.Text == "")
            {
                MessageBox.Show("Please Select the Department");
            }
            else if (cmbx_dept_name.Text == "Purchase")
            {
                object saving_data = sql_connection.connect("SELECT COUNT(D_NAME) FROM DEPARTMENT GROUP BY D_NAME HAVING D_NAME = 'Purchase'");
              
                if (Convert.ToInt32(saving_data) < 1)
                {
                    sql_connection.connect("INSERT INTO DEPARTMENT VALUES('" + txtbx_dept_id.Text + "','" + cmbx_dept_name.Text + "')");

                    dtgv_dept_reg.DataSource = sql_connection.table_data("SELECT * FROM DEPARTMENT");

                    if (txtbx_dept_id.Text == "D1")
                    {
                        txtbx_dept_id.Text = "D2";
                    }
                    else
                    {
                        txtbx_dept_id.Text = "D2";
                    }
                }
                else
                {
                    MessageBox.Show("Already has been registered");
                }
            }
            else
            {
                object saving_data = sql_connection.connect("SELECT COUNT(D_NAME) FROM DEPARTMENT GROUP BY D_NAME HAVING D_NAME = 'Sales'");
                if (Convert.ToInt32(saving_data) < 1)
                {
                    sql_connection.connect("INSERT INTO DEPARTMENT VALUES('" + txtbx_dept_id.Text + "','" + cmbx_dept_name.Text + "')");
                    dtgv_dept_reg.DataSource = sql_connection.table_data("SELECT * FROM DEPARTMENT");
                    if (txtbx_dept_id.Text == "D1")
                    {
                        txtbx_dept_id.Text = "D2";
                    }
                    else
                    {
                        txtbx_dept_id.Text = "D2";
                    }
                }
                else
                {
                    MessageBox.Show("Already has been registered");
                }
            }
        }
        private void btn_update_Click(object sender, EventArgs e)
        {
            sql_connection.table_data("UPDATE DEPARTMENT SET D_NAME = '" + cmbx_dept_name.Text + "' WHERE D_ID = '" + txtbx_dept_id.Text + "'");
            dtgv_dept_reg.DataSource = sql_connection.table_data("SELECT * FROM DEPARTMENT");
        }

        private void dtgv_dept_reg_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dtgv_dept_reg.DataSource = sql_connection.table_data("SELECT * FROM DEPARTMENT WHERE D_ID = '" + dtgv_dept_reg.CurrentCell.Value + "' OR D_NAME = '" + dtgv_dept_reg.CurrentCell.Value + "'");
            txtbx_dept_id.Text = sql_connection.connect("SELECT D_ID FROM DEPARTMENT WHERE D_ID = '" + dtgv_dept_reg.CurrentCell.Value + "' OR D_NAME = '" + dtgv_dept_reg.CurrentCell.Value + "'").ToString();
        }
        private void btn_delete_Click(object sender, EventArgs e)
        {
            sql_connection.table_data("DELETE DEPARTMENT WHERE D_ID = '" + txtbx_dept_id.Text + "'");
            dtgv_dept_reg.DataSource = sql_connection.table_data("SELECT * FROM DEPARTMENT");
        }
    }
}
