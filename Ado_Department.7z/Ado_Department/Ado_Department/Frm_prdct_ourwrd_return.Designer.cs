﻿namespace Ado_Department
{
    partial class Frm_prdct_ourwrd_return
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_prdct_ourwrd_return));
            this.pnl_prct_otwrd_rtrn = new System.Windows.Forms.Panel();
            this.dtgv_prdct_otwrd_return = new System.Windows.Forms.DataGridView();
            this.grpbx_prdct_otwrd_rtrn = new System.Windows.Forms.GroupBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.txtbx_reason = new System.Windows.Forms.TextBox();
            this.lbl_reason = new System.Windows.Forms.Label();
            this.lbl_rtrn_amount = new System.Windows.Forms.Label();
            this.lbl_rtrn_quntity = new System.Windows.Forms.Label();
            this.lbl_prchse_dte = new System.Windows.Forms.Label();
            this.lbl_prchse_quntity = new System.Windows.Forms.Label();
            this.txtbx_prdct_name = new System.Windows.Forms.TextBox();
            this.lbl_prdct_name = new System.Windows.Forms.Label();
            this.cmbx_prdct_otwrd_id = new System.Windows.Forms.ComboBox();
            this.lbl_prdct_otwrd_id = new System.Windows.Forms.Label();
            this.lbl_prdct_otwrd_rtrn_id = new System.Windows.Forms.Label();
            this.lbl_prdct_outwrd_reg = new System.Windows.Forms.Label();
            this.txtbx_prdct_rtrn_amount = new Ado_Department.validate();
            this.txtbx_rtrn_quantity = new Ado_Department.validate();
            this.txtbx_prchse_date = new Ado_Department.validate();
            this.txtbx_prdct_qntity = new Ado_Department.validate();
            this.txtbx_prdct_otwrd_rtrn_id = new Ado_Department.validate();
            this.pnl_prct_otwrd_rtrn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_prdct_otwrd_return)).BeginInit();
            this.grpbx_prdct_otwrd_rtrn.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_prct_otwrd_rtrn
            // 
            this.pnl_prct_otwrd_rtrn.BackColor = System.Drawing.Color.AliceBlue;
            this.pnl_prct_otwrd_rtrn.Controls.Add(this.dtgv_prdct_otwrd_return);
            this.pnl_prct_otwrd_rtrn.Controls.Add(this.grpbx_prdct_otwrd_rtrn);
            this.pnl_prct_otwrd_rtrn.Location = new System.Drawing.Point(12, 13);
            this.pnl_prct_otwrd_rtrn.Name = "pnl_prct_otwrd_rtrn";
            this.pnl_prct_otwrd_rtrn.Size = new System.Drawing.Size(778, 447);
            this.pnl_prct_otwrd_rtrn.TabIndex = 0;
            // 
            // dtgv_prdct_otwrd_return
            // 
            this.dtgv_prdct_otwrd_return.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_prdct_otwrd_return.Location = new System.Drawing.Point(18, 276);
            this.dtgv_prdct_otwrd_return.Name = "dtgv_prdct_otwrd_return";
            this.dtgv_prdct_otwrd_return.Size = new System.Drawing.Size(745, 168);
            this.dtgv_prdct_otwrd_return.TabIndex = 1;
            this.dtgv_prdct_otwrd_return.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgv_prdct_otwrd_return_CellContentClick);
            // 
            // grpbx_prdct_otwrd_rtrn
            // 
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.btn_delete);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.btn_update);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.btn_save);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.txtbx_reason);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.lbl_reason);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.txtbx_prdct_rtrn_amount);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.lbl_rtrn_amount);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.txtbx_rtrn_quantity);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.lbl_rtrn_quntity);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.txtbx_prchse_date);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.lbl_prchse_dte);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.txtbx_prdct_qntity);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.lbl_prchse_quntity);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.txtbx_prdct_name);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.lbl_prdct_name);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.cmbx_prdct_otwrd_id);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.lbl_prdct_otwrd_id);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.txtbx_prdct_otwrd_rtrn_id);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.lbl_prdct_otwrd_rtrn_id);
            this.grpbx_prdct_otwrd_rtrn.Controls.Add(this.lbl_prdct_outwrd_reg);
            this.grpbx_prdct_otwrd_rtrn.Location = new System.Drawing.Point(18, 6);
            this.grpbx_prdct_otwrd_rtrn.Name = "grpbx_prdct_otwrd_rtrn";
            this.grpbx_prdct_otwrd_rtrn.Size = new System.Drawing.Size(745, 264);
            this.grpbx_prdct_otwrd_rtrn.TabIndex = 0;
            this.grpbx_prdct_otwrd_rtrn.TabStop = false;
            // 
            // btn_delete
            // 
            this.btn_delete.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_delete.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Image = ((System.Drawing.Image)(resources.GetObject("btn_delete.Image")));
            this.btn_delete.Location = new System.Drawing.Point(367, 231);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(96, 25);
            this.btn_delete.TabIndex = 24;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_update
            // 
            this.btn_update.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_update.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Image = ((System.Drawing.Image)(resources.GetObject("btn_update.Image")));
            this.btn_update.Location = new System.Drawing.Point(166, 233);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(97, 25);
            this.btn_update.TabIndex = 23;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_save
            // 
            this.btn_save.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_save.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.Image = ((System.Drawing.Image)(resources.GetObject("btn_save.Image")));
            this.btn_save.Location = new System.Drawing.Point(262, 200);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(98, 25);
            this.btn_save.TabIndex = 22;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // txtbx_reason
            // 
            this.txtbx_reason.Location = new System.Drawing.Point(533, 159);
            this.txtbx_reason.Multiline = true;
            this.txtbx_reason.Name = "txtbx_reason";
            this.txtbx_reason.Size = new System.Drawing.Size(193, 66);
            this.txtbx_reason.TabIndex = 17;
            // 
            // lbl_reason
            // 
            this.lbl_reason.AutoSize = true;
            this.lbl_reason.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_reason.Location = new System.Drawing.Point(467, 163);
            this.lbl_reason.Name = "lbl_reason";
            this.lbl_reason.Size = new System.Drawing.Size(55, 15);
            this.lbl_reason.TabIndex = 16;
            this.lbl_reason.Text = "Reason";
            // 
            // lbl_rtrn_amount
            // 
            this.lbl_rtrn_amount.AutoSize = true;
            this.lbl_rtrn_amount.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_rtrn_amount.Location = new System.Drawing.Point(418, 127);
            this.lbl_rtrn_amount.Name = "lbl_rtrn_amount";
            this.lbl_rtrn_amount.Size = new System.Drawing.Size(104, 15);
            this.lbl_rtrn_amount.TabIndex = 14;
            this.lbl_rtrn_amount.Text = "Return Amount";
            // 
            // lbl_rtrn_quntity
            // 
            this.lbl_rtrn_quntity.AutoSize = true;
            this.lbl_rtrn_quntity.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_rtrn_quntity.Location = new System.Drawing.Point(413, 89);
            this.lbl_rtrn_quntity.Name = "lbl_rtrn_quntity";
            this.lbl_rtrn_quntity.Size = new System.Drawing.Size(109, 15);
            this.lbl_rtrn_quntity.TabIndex = 12;
            this.lbl_rtrn_quntity.Text = "Return Quantity";
            // 
            // lbl_prchse_dte
            // 
            this.lbl_prchse_dte.AutoSize = true;
            this.lbl_prchse_dte.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prchse_dte.Location = new System.Drawing.Point(418, 51);
            this.lbl_prchse_dte.Name = "lbl_prchse_dte";
            this.lbl_prchse_dte.Size = new System.Drawing.Size(103, 15);
            this.lbl_prchse_dte.TabIndex = 10;
            this.lbl_prchse_dte.Text = "Purchase Date";
            // 
            // lbl_prchse_quntity
            // 
            this.lbl_prchse_quntity.AutoSize = true;
            this.lbl_prchse_quntity.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prchse_quntity.Location = new System.Drawing.Point(60, 171);
            this.lbl_prchse_quntity.Name = "lbl_prchse_quntity";
            this.lbl_prchse_quntity.Size = new System.Drawing.Size(127, 15);
            this.lbl_prchse_quntity.TabIndex = 8;
            this.lbl_prchse_quntity.Text = "Purchase Quantity";
            // 
            // txtbx_prdct_name
            // 
            this.txtbx_prdct_name.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_name.Location = new System.Drawing.Point(207, 124);
            this.txtbx_prdct_name.Name = "txtbx_prdct_name";
            this.txtbx_prdct_name.ReadOnly = true;
            this.txtbx_prdct_name.Size = new System.Drawing.Size(195, 22);
            this.txtbx_prdct_name.TabIndex = 7;
            // 
            // lbl_prdct_name
            // 
            this.lbl_prdct_name.AutoSize = true;
            this.lbl_prdct_name.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prdct_name.Location = new System.Drawing.Point(87, 129);
            this.lbl_prdct_name.Name = "lbl_prdct_name";
            this.lbl_prdct_name.Size = new System.Drawing.Size(100, 15);
            this.lbl_prdct_name.TabIndex = 6;
            this.lbl_prdct_name.Text = "Product Name";
            // 
            // cmbx_prdct_otwrd_id
            // 
            this.cmbx_prdct_otwrd_id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_prdct_otwrd_id.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_prdct_otwrd_id.FormattingEnabled = true;
            this.cmbx_prdct_otwrd_id.Location = new System.Drawing.Point(207, 85);
            this.cmbx_prdct_otwrd_id.Name = "cmbx_prdct_otwrd_id";
            this.cmbx_prdct_otwrd_id.Size = new System.Drawing.Size(195, 23);
            this.cmbx_prdct_otwrd_id.TabIndex = 5;
            this.cmbx_prdct_otwrd_id.SelectedIndexChanged += new System.EventHandler(this.cmbx_prdct_otwrd_id_SelectedIndexChanged);
            // 
            // lbl_prdct_otwrd_id
            // 
            this.lbl_prdct_otwrd_id.AutoSize = true;
            this.lbl_prdct_otwrd_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prdct_otwrd_id.Location = new System.Drawing.Point(54, 92);
            this.lbl_prdct_otwrd_id.Name = "lbl_prdct_otwrd_id";
            this.lbl_prdct_otwrd_id.Size = new System.Drawing.Size(133, 15);
            this.lbl_prdct_otwrd_id.TabIndex = 4;
            this.lbl_prdct_otwrd_id.Text = "Product Outward Id";
            // 
            // lbl_prdct_otwrd_rtrn_id
            // 
            this.lbl_prdct_otwrd_rtrn_id.AutoSize = true;
            this.lbl_prdct_otwrd_rtrn_id.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prdct_otwrd_rtrn_id.Location = new System.Drawing.Point(7, 51);
            this.lbl_prdct_otwrd_rtrn_id.Name = "lbl_prdct_otwrd_rtrn_id";
            this.lbl_prdct_otwrd_rtrn_id.Size = new System.Drawing.Size(180, 15);
            this.lbl_prdct_otwrd_rtrn_id.TabIndex = 2;
            this.lbl_prdct_otwrd_rtrn_id.Text = "Product Outward Return Id";
            // 
            // lbl_prdct_outwrd_reg
            // 
            this.lbl_prdct_outwrd_reg.AutoSize = true;
            this.lbl_prdct_outwrd_reg.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prdct_outwrd_reg.Location = new System.Drawing.Point(242, 11);
            this.lbl_prdct_outwrd_reg.Name = "lbl_prdct_outwrd_reg";
            this.lbl_prdct_outwrd_reg.Size = new System.Drawing.Size(234, 22);
            this.lbl_prdct_outwrd_reg.TabIndex = 1;
            this.lbl_prdct_outwrd_reg.Text = "Product Outward Return";
            // 
            // txtbx_prdct_rtrn_amount
            // 
            this.txtbx_prdct_rtrn_amount.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_rtrn_amount.Location = new System.Drawing.Point(533, 121);
            this.txtbx_prdct_rtrn_amount.Name = "txtbx_prdct_rtrn_amount";
            this.txtbx_prdct_rtrn_amount.ReadOnly = true;
            this.txtbx_prdct_rtrn_amount.Size = new System.Drawing.Size(193, 22);
            this.txtbx_prdct_rtrn_amount.TabIndex = 15;
            // 
            // txtbx_rtrn_quantity
            // 
            this.txtbx_rtrn_quantity.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_rtrn_quantity.Location = new System.Drawing.Point(533, 82);
            this.txtbx_rtrn_quantity.Name = "txtbx_rtrn_quantity";
            this.txtbx_rtrn_quantity.Size = new System.Drawing.Size(193, 22);
            this.txtbx_rtrn_quantity.TabIndex = 13;
            this.txtbx_rtrn_quantity.TextChanged += new System.EventHandler(this.txtbx_rtrn_quantity_TextChanged);
            // 
            // txtbx_prchse_date
            // 
            this.txtbx_prchse_date.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prchse_date.Location = new System.Drawing.Point(533, 44);
            this.txtbx_prchse_date.Name = "txtbx_prchse_date";
            this.txtbx_prchse_date.ReadOnly = true;
            this.txtbx_prchse_date.Size = new System.Drawing.Size(193, 22);
            this.txtbx_prchse_date.TabIndex = 11;
            // 
            // txtbx_prdct_qntity
            // 
            this.txtbx_prdct_qntity.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_qntity.Location = new System.Drawing.Point(207, 164);
            this.txtbx_prdct_qntity.Name = "txtbx_prdct_qntity";
            this.txtbx_prdct_qntity.ReadOnly = true;
            this.txtbx_prdct_qntity.Size = new System.Drawing.Size(195, 22);
            this.txtbx_prdct_qntity.TabIndex = 9;
            // 
            // txtbx_prdct_otwrd_rtrn_id
            // 
            this.txtbx_prdct_otwrd_rtrn_id.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_otwrd_rtrn_id.Location = new System.Drawing.Point(207, 45);
            this.txtbx_prdct_otwrd_rtrn_id.Name = "txtbx_prdct_otwrd_rtrn_id";
            this.txtbx_prdct_otwrd_rtrn_id.ReadOnly = true;
            this.txtbx_prdct_otwrd_rtrn_id.Size = new System.Drawing.Size(195, 22);
            this.txtbx_prdct_otwrd_rtrn_id.TabIndex = 3;
            // 
            // Frm_prdct_ourwrd_return
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(803, 472);
            this.Controls.Add(this.pnl_prct_otwrd_rtrn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_prdct_ourwrd_return";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Frm_prdct_ourwrd_return_Load);
            this.pnl_prct_otwrd_rtrn.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_prdct_otwrd_return)).EndInit();
            this.grpbx_prdct_otwrd_rtrn.ResumeLayout(false);
            this.grpbx_prdct_otwrd_rtrn.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_prct_otwrd_rtrn;
        private System.Windows.Forms.DataGridView dtgv_prdct_otwrd_return;
        private System.Windows.Forms.GroupBox grpbx_prdct_otwrd_rtrn;
        private System.Windows.Forms.Label lbl_prdct_outwrd_reg;
        private System.Windows.Forms.Label lbl_prdct_otwrd_rtrn_id;
        private validate txtbx_prdct_otwrd_rtrn_id;
        private System.Windows.Forms.Label lbl_prdct_otwrd_id;
        private System.Windows.Forms.ComboBox cmbx_prdct_otwrd_id;
        private System.Windows.Forms.Label lbl_prdct_name;
        private System.Windows.Forms.TextBox txtbx_prdct_name;
        private System.Windows.Forms.Label lbl_prchse_quntity;
        private validate txtbx_prdct_qntity;
        private System.Windows.Forms.Label lbl_prchse_dte;
        private System.Windows.Forms.Label lbl_rtrn_quntity;
        private validate txtbx_prchse_date;
        private System.Windows.Forms.Label lbl_rtrn_amount;
        private validate txtbx_rtrn_quantity;
        private validate txtbx_prdct_rtrn_amount;
        private System.Windows.Forms.Label lbl_reason;
        private System.Windows.Forms.TextBox txtbx_reason;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_save;
    }
}