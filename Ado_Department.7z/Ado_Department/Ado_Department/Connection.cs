﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace Ado_Department
{
    class Connection
    {
        object checking_data;
        public object connect(string query)
        {
            try
            {
                SqlConnection s_connection = new SqlConnection(@"Data Source=IMRANA\SQLExpress;Initial Catalog=DEPARTMENT_STORE;Integrated Security=True");
                s_connection.Open();
                SqlCommand s_command = new SqlCommand(query, s_connection);
                checking_data = s_command.ExecuteScalar();
                s_connection.Close();
            }
            catch (SqlException ex)
            {
                
            }
            catch (NullReferenceException ex)
            {
             
            }
            return checking_data;
        }

        public DataTable table_data(string query)
        {
            DataTable Data_table = new DataTable();
            try
            {
                SqlConnection s_connection = new SqlConnection(@"Data Source=IMRANA\SQLExpress;Initial Catalog=DEPARTMENT_STORE;Integrated Security=True");
                s_connection.Open();
                SqlCommand s_command = new SqlCommand(query, s_connection);
                SqlDataAdapter sda = new SqlDataAdapter(s_command);
                sda.Fill(Data_table);
                s_connection.Close();
            }
            catch (SqlException ex)
            {
             
            }
            catch (NullReferenceException ex)
            {
               
            }
            return Data_table;  
                    
        }
    }
}
