﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ado_Department
{
    class validate:TextBox
    {

        protected override void InitLayout()
        {
            base.InitLayout();
        }
        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == ',' || e.KeyChar == '<' || e.KeyChar == '.' || e.KeyChar == '>' || e.KeyChar == '/' || e.KeyChar == '?' || e.KeyChar == ';' || e.KeyChar == ':' || e.KeyChar == '"' || e.KeyChar == '{' || e.KeyChar == '}' || e.KeyChar == '[' || e.KeyChar == ']' || e.KeyChar == '|' || e.KeyChar == '!' || e.KeyChar == '@' || e.KeyChar == '#' || e.KeyChar == '$' || e.KeyChar == '%' || e.KeyChar == '^' || e.KeyChar == '&' || e.KeyChar == '*' || e.KeyChar == '(' || e.KeyChar == ')' || e.KeyChar == '-' || e.KeyChar == '_' || e.KeyChar == '+' || e.KeyChar == '=' || e.KeyChar == '`' || e.KeyChar == '~' || e.KeyChar == '\'' || e.KeyChar == '\\')
            {
                e.Handled = true;
            }
            base.OnKeyPress(e);
        }
    }
}
