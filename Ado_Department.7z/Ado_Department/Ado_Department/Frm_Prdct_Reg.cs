﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ado_Department
{
    public partial class Frm_Prdct_Reg : Form
    {
        public Frm_Prdct_Reg()
        {
            InitializeComponent();
        }
        Connection sql_connection = new Connection();
        private void btn_prdct_save_Click(object sender, EventArgs e)
        {
            if (txtbx_prdct_name.Text == "" || txtbx_prdct_price.Text == "" || txtbx_sales_price.Text == "")
            {
                MessageBox.Show("Please enter the blank field");
            }
            else
            {
                sql_connection.table_data("INSERT INTO PRODUCT VALUES('" + txtbx_prdct_id.Text + "','" + txtbx_prdct_name.Text + "','" + txtbx_prdct_price.Text + "','" + txtbx_sales_price.Text + "','"+dtp_dte_of_reg.Value.ToShortDateString()+"')");
                dtgv_prdct_reg.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT");
                object prdct_id_count = sql_connection.connect("SELECT COUNT(P_ID) FROM PRODUCT");
                if (Convert.ToInt32(prdct_id_count) < 0)
                {
                    txtbx_prdct_id.Text = "P1";
                }
                else
                {
                    txtbx_prdct_id.Text = "P" + (Convert.ToInt32(prdct_id_count) + 1).ToString();
                }

                txtbx_prdct_id.Text = "";
                txtbx_prdct_name.Text = "";
                txtbx_prdct_price.Text = "";
                txtbx_sales_price.Text = "";
            }
        }
        private void Frm_Prdct_Reg_Load(object sender, EventArgs e)
        {
            dtgv_prdct_reg.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT");
            object prdct_id_count = sql_connection.connect("SELECT COUNT(P_ID) FROM PRODUCT");
            if (Convert.ToInt32(prdct_id_count) < 0)
            {
                txtbx_prdct_id.Text = "P1";
            }
            else
            {
                txtbx_prdct_id.Text = "P"+(Convert.ToInt32(prdct_id_count) + 1).ToString();
            }
        }
        private void dtgv_prdct_reg_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtbx_prdct_id.Text = sql_connection.connect("SELECT P_ID FROM PRODUCT WHERE P_ID = '" + dtgv_prdct_reg.CurrentCell.Value + "'").ToString();
                txtbx_prdct_name.Text = sql_connection.connect("SELECT P_NAME FROM PRODUCT WHERE P_ID = '" + dtgv_prdct_reg.CurrentCell.Value + "'").ToString();
                txtbx_prdct_price.Text = sql_connection.connect("SELECT PRODUCT_PRICE FROM PRODUCT WHERE P_ID = '" + dtgv_prdct_reg.CurrentCell.Value + "'").ToString();
                txtbx_sales_price.Text = sql_connection.connect("SELECT SALES_PRICE FROM PRODUCT WHERE P_ID = '" + dtgv_prdct_reg.CurrentCell.Value + "'").ToString();
                dtp_dte_of_reg.Value = Convert.ToDateTime(Convert.ToDateTime(sql_connection.connect("SELECT DATEE FROM PRODUCT WHERE P_ID = '" + dtgv_prdct_reg.CurrentCell.Value + "'")).ToShortDateString());
            }
            catch(NullReferenceException ex)
            {
                
            }
        }

        private void btn_prdct_update_Click(object sender, EventArgs e)
        {
            try
            {
                sql_connection.table_data("UPDATE PRODUCT SET P_NAME = '" + txtbx_prdct_name.Text + "',PRODUCT_PRICE = '" + txtbx_prdct_price.Text + "',SALES_PRICE = '" + txtbx_sales_price.Text + "' WHERE P_ID = '" + txtbx_prdct_id.Text + "'");
                dtgv_prdct_reg.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT");
                txtbx_prdct_id.Text = "";
                txtbx_prdct_name.Text = "";
                txtbx_prdct_price.Text = "";
                txtbx_sales_price.Text = "";
            }
            catch (NullReferenceException ex)
            {
            }
        }

        private void btn_prdct_delete_Click(object sender, EventArgs e)
        {
            try
            {
                sql_connection.table_data("DELETE PRODUCT WHERE P_ID = '" + txtbx_prdct_id.Text + "'");
                dtgv_prdct_reg.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT");
                txtbx_prdct_id.Text = "";
                txtbx_prdct_name.Text = "";
                txtbx_prdct_price.Text = "";
                txtbx_sales_price.Text = "";
            }
            catch(NullReferenceException ex)
            {
            }
        }   
    }
}
