﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ado_Department
{
    public partial class Frm_Employee_Registration : Form
    {
        public Frm_Employee_Registration()
        {
            InitializeComponent();
        }
        Connection sql_connection = new Connection();
        
        private void btn_emp_reg_submit_Click(object sender, EventArgs e)
        {
            if (txtbx_emp_id.Text == "" || txtbx_emp_name.Text == "" || txtbx_emp_address.Text == "" || txtbx_email_id.Text == "" || txtbx_phn_nmbr.Text == "" || cmbx_dept_name.Text == "")
            {
                MessageBox.Show("Please fill the blank field");
            }
            else if (txtbx_email_id.Text.Contains("@") == false)
            {
                MessageBox.Show("Please enter the valid email-id");
            }
            else
            {
                string gender;
                if(rdbtn_male.Checked == true)
                {
                    gender = "Male";
                }
                else
                {
                    gender = "Female";
                }
                object entering_data = sql_connection.connect("SELECT COUNT(D_ID) FROM EMPLOYEE GROUP BY D_ID HAVING D_ID = 'D1'");
                object entering_data1 = sql_connection.connect("SELECT COUNT(D_ID) FROM EMPLOYEE GROUP BY D_ID HAVING D_ID = 'D2'");
                if (cmbx_dept_name.Text == "Purchase")
                {
                    if (Convert.ToInt32(entering_data) < 25)
                    {
                        object check_dept = sql_connection.connect("SELECT D_ID FROM DEPARTMENT WHERE D_NAME = '" + cmbx_dept_name.Text + "'");
                        sql_connection.table_data("INSERT INTO EMPLOYEE VALUES('" + txtbx_emp_id.Text + "','" + txtbx_emp_name.Text + "','" + gender + "','" + txtbx_emp_address.Text + "',DEFAULT,'" + txtbx_email_id.Text + "','" + txtbx_phn_nmbr.Text + "','" + check_dept.ToString() + "')");
                        dtgv_emp_reg.DataSource = sql_connection.table_data("SELECT * FROM EMPLOYEE");
                        object e_id = sql_connection.connect("SELECT COUNT(E_ID) FROM EMPLOYEE");
                        if (Convert.ToInt32(e_id) == 0)
                        {
                            txtbx_emp_id.Text = "E1";
                        }
                        else
                        {
                            txtbx_emp_id.Text = "E" + (Convert.ToInt32(e_id) + 1).ToString();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Sorry this department is Full");
                    }
                    txtbx_emp_name.Text = "";
                    txtbx_emp_address.Text = "";
                    txtbx_phn_nmbr.Text = "";
                    txtbx_email_id.Text = "";
                }
                else
                {
                    if (Convert.ToInt32(entering_data1) < 25)
                    {
                        object check_dept = sql_connection.connect("SELECT D_ID FROM DEPARTMENT WHERE D_NAME = '" + cmbx_dept_name.Text + "'");
                        sql_connection.table_data("INSERT INTO EMPLOYEE VALUES('" + txtbx_emp_id.Text + "','" + txtbx_emp_name.Text + "','" + gender + "','" + txtbx_emp_address.Text + "',DEFAULT,'" + txtbx_email_id.Text + "','" + txtbx_phn_nmbr.Text + "','" + check_dept.ToString() + "')");
                        dtgv_emp_reg.DataSource = sql_connection.table_data("SELECT * FROM EMPLOYEE");
                        object e_id = sql_connection.connect("SELECT COUNT(E_ID) FROM EMPLOYEE");
                        if (Convert.ToInt32(e_id) == 0)
                        {
                            txtbx_emp_id.Text = "E1";
                        }
                        else
                        {
                            txtbx_emp_id.Text = "E" + (Convert.ToInt32(e_id) + 1).ToString();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Sorry this department is Full");
                    }

                    txtbx_emp_name.Text = "";
                    txtbx_emp_address.Text = "";
                    txtbx_phn_nmbr.Text = "";
                    txtbx_email_id.Text = "";

                }
            }
        }
        private void Frm_Employee_Registration_Load(object sender, EventArgs e)
        {
            object e_id = sql_connection.connect("SELECT COUNT(E_ID) FROM EMPLOYEE");
            if (Convert.ToInt32(e_id) == 0)
            {
                txtbx_emp_id.Text = "E1";
            }
            else
            {
                txtbx_emp_id.Text = "E" + (Convert.ToInt32(e_id) + 1).ToString();
            }
            cmbx_dept_name.DisplayMember = "D_NAME";
            cmbx_dept_name.DataSource = sql_connection.table_data("SELECT D_NAME FROM DEPARTMENT");
            dtgv_emp_reg.DataSource = sql_connection.table_data("SELECT * FROM EMPLOYEE");

        }
        string gender;
        private void dtgv_emp_reg_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {         
            try
            {
                txtbx_emp_id.Text = sql_connection.connect("SELECT E_ID FROM EMPLOYEE WHERE E_ID ='" + dtgv_emp_reg.CurrentCell.Value + "' OR CONTACTNO ='" + dtgv_emp_reg.CurrentCell.Value + "' OR EMAIL = '" + dtgv_emp_reg.CurrentCell.Value + "'").ToString();
                txtbx_emp_name.Text = sql_connection.connect("SELECT E_NAME FROM EMPLOYEE WHERE E_ID ='" + dtgv_emp_reg.CurrentCell.Value + "' OR CONTACTNO ='" + dtgv_emp_reg.CurrentCell.Value + "' OR EMAIL = '" + dtgv_emp_reg.CurrentCell.Value + "'").ToString();
                gender = sql_connection.connect("SELECT GENDER FROM EMPLOYEE WHERE E_ID ='" + dtgv_emp_reg.CurrentCell.Value + "' OR CONTACTNO ='" + dtgv_emp_reg.CurrentCell.Value + "' OR EMAIL = '" + dtgv_emp_reg.CurrentCell.Value + "'").ToString();
            }
            catch (NullReferenceException ex)
            {
                MessageBox.Show("Please check the data");
            }
            
            if (gender == "Male")
            {
                rdbtn_male.Checked = true;
            }
            else
            {
                rdbtn_female.Checked = true;
            }
            try
            {
                txtbx_emp_address.Text = sql_connection.connect("SELECT EMP_ADDRESS FROM EMPLOYEE WHERE E_ID ='" + dtgv_emp_reg.CurrentCell.Value + "' OR CONTACTNO ='" + dtgv_emp_reg.CurrentCell.Value + "' OR EMAIL = '" + dtgv_emp_reg.CurrentCell.Value + "'").ToString();
                txtbx_city.Text = sql_connection.connect("SELECT CITY FROM EMPLOYEE WHERE E_ID ='" + dtgv_emp_reg.CurrentCell.Value + "' OR CONTACTNO ='" + dtgv_emp_reg.CurrentCell.Value + "' OR EMAIL = '" + dtgv_emp_reg.CurrentCell.Value + "'").ToString();
                txtbx_email_id.Text = sql_connection.connect("SELECT EMAIL FROM EMPLOYEE WHERE E_ID ='" + dtgv_emp_reg.CurrentCell.Value + "' OR CONTACTNO ='" + dtgv_emp_reg.CurrentCell.Value + "' OR EMAIL = '" + dtgv_emp_reg.CurrentCell.Value + "'").ToString();
                txtbx_phn_nmbr.Text = sql_connection.connect("SELECT CONTACTNO FROM EMPLOYEE WHERE E_ID ='" + dtgv_emp_reg.CurrentCell.Value + "' OR CONTACTNO ='" + dtgv_emp_reg.CurrentCell.Value + "' OR EMAIL = '" + dtgv_emp_reg.CurrentCell.Value + "'").ToString();
                cmbx_dept_name.Text = sql_connection.connect("SELECT D_ID FROM EMPLOYEE WHERE E_ID ='" + dtgv_emp_reg.CurrentCell.Value + "' OR CONTACTNO ='" + dtgv_emp_reg.CurrentCell.Value + "' OR EMAIL = '" + dtgv_emp_reg.CurrentCell.Value + "'").ToString();
            }
            catch(NullReferenceException ex)
            {
                MessageBox.Show("Please check the data");
            }
        }
        private void btn_emp_reg_update_Click(object sender, EventArgs e)
        {
            if (txtbx_emp_id.Text == "" || txtbx_emp_name.Text == "" || txtbx_emp_address.Text == "" || txtbx_email_id.Text == "" || txtbx_phn_nmbr.Text == "" || cmbx_dept_name.Text == "")
            {
                MessageBox.Show("Please fill the blank field");
            }
            else if (txtbx_email_id.Text.Contains("@") == false)
            {
                MessageBox.Show("Please enter the valid email-id");
            }
            else
            {
                string gender;
                if (rdbtn_male.Checked == true)
                {
                    gender = "Male";
                }
                else
                {
                    gender = "Female";
                }
                object check_dept = sql_connection.connect("SELECT D_ID FROM DEPARTMENT WHERE D_NAME = '" + cmbx_dept_name.Text + "'");
                sql_connection.table_data("UPDATE EMPLOYEE SET E_NAME = '" + txtbx_emp_name.Text + "', GENDER = '" + gender + "',EMP_ADDRESS = '" + txtbx_emp_address.Text + "',CITY = '" + txtbx_city.Text + "',EMAIL = '" + txtbx_email_id.Text + "',CONTACTNO = '" + txtbx_phn_nmbr.Text + "',D_ID = '" + check_dept.ToString() + "' WHERE E_ID = '" + txtbx_emp_id.Text + "'");
                dtgv_emp_reg.DataSource = sql_connection.table_data("SELECT * FROM EMPLOYEE");
                txtbx_emp_name.Text = "";
                txtbx_emp_address.Text = "";
                txtbx_phn_nmbr.Text = "";
                txtbx_email_id.Text = "";
            }

        }
        private void btn_emp_reg_delete_Click(object sender, EventArgs e)
        {
            try
            {
                sql_connection.table_data("DELETE EMPLOYEE WHERE E_ID = '" + txtbx_emp_id.Text + "'");
                dtgv_emp_reg.DataSource = sql_connection.table_data("SELECT * FROM EMPLOYEE");
                txtbx_emp_name.Text = "";
                txtbx_emp_address.Text = "";
                txtbx_phn_nmbr.Text = "";
                txtbx_email_id.Text = "";
            }
            catch (NullReferenceException ex)
            {

            }
        }      
    }
}
