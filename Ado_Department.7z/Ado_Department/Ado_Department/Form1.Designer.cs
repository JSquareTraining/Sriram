﻿namespace Ado_Department
{
    partial class Frm_login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_login));
            this.grpbx_login = new System.Windows.Forms.GroupBox();
            this.btn_close = new System.Windows.Forms.Button();
            this.txtbx_pswd = new System.Windows.Forms.TextBox();
            this.txtbx_usrnme = new System.Windows.Forms.TextBox();
            this.btn_lgn = new System.Windows.Forms.Button();
            this.lbl_pswd = new System.Windows.Forms.Label();
            this.lbl_usrnme = new System.Windows.Forms.Label();
            this.grpbx_login.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpbx_login
            // 
            this.grpbx_login.BackColor = System.Drawing.Color.Transparent;
            this.grpbx_login.Controls.Add(this.btn_close);
            this.grpbx_login.Controls.Add(this.txtbx_pswd);
            this.grpbx_login.Controls.Add(this.txtbx_usrnme);
            this.grpbx_login.Controls.Add(this.btn_lgn);
            this.grpbx_login.Controls.Add(this.lbl_pswd);
            this.grpbx_login.Controls.Add(this.lbl_usrnme);
            this.grpbx_login.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbx_login.ForeColor = System.Drawing.Color.OldLace;
            this.grpbx_login.Location = new System.Drawing.Point(93, 34);
            this.grpbx_login.Name = "grpbx_login";
            this.grpbx_login.Size = new System.Drawing.Size(361, 173);
            this.grpbx_login.TabIndex = 0;
            this.grpbx_login.TabStop = false;
            this.grpbx_login.Text = "Login";
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Honeydew;
            this.btn_close.ForeColor = System.Drawing.Color.SlateBlue;
            this.btn_close.Location = new System.Drawing.Point(234, 124);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(95, 29);
            this.btn_close.TabIndex = 5;
            this.btn_close.Text = "Close";
            this.btn_close.UseVisualStyleBackColor = false;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // txtbx_pswd
            // 
            this.txtbx_pswd.Location = new System.Drawing.Point(124, 84);
            this.txtbx_pswd.Name = "txtbx_pswd";
            this.txtbx_pswd.PasswordChar = '*';
            this.txtbx_pswd.Size = new System.Drawing.Size(217, 26);
            this.txtbx_pswd.TabIndex = 4;
            // 
            // txtbx_usrnme
            // 
            this.txtbx_usrnme.Location = new System.Drawing.Point(124, 42);
            this.txtbx_usrnme.Name = "txtbx_usrnme";
            this.txtbx_usrnme.Size = new System.Drawing.Size(217, 26);
            this.txtbx_usrnme.TabIndex = 3;
            // 
            // btn_lgn
            // 
            this.btn_lgn.BackColor = System.Drawing.Color.Honeydew;
            this.btn_lgn.ForeColor = System.Drawing.Color.SlateBlue;
            this.btn_lgn.Location = new System.Drawing.Point(124, 124);
            this.btn_lgn.Name = "btn_lgn";
            this.btn_lgn.Size = new System.Drawing.Size(95, 29);
            this.btn_lgn.TabIndex = 2;
            this.btn_lgn.Text = "Login";
            this.btn_lgn.UseVisualStyleBackColor = false;
            this.btn_lgn.Click += new System.EventHandler(this.btn_lgn_Click);
            // 
            // lbl_pswd
            // 
            this.lbl_pswd.AutoSize = true;
            this.lbl_pswd.ForeColor = System.Drawing.Color.SteelBlue;
            this.lbl_pswd.Location = new System.Drawing.Point(7, 92);
            this.lbl_pswd.Name = "lbl_pswd";
            this.lbl_pswd.Size = new System.Drawing.Size(87, 18);
            this.lbl_pswd.TabIndex = 1;
            this.lbl_pswd.Text = "Password";
            // 
            // lbl_usrnme
            // 
            this.lbl_usrnme.AutoSize = true;
            this.lbl_usrnme.ForeColor = System.Drawing.Color.SteelBlue;
            this.lbl_usrnme.Location = new System.Drawing.Point(7, 50);
            this.lbl_usrnme.Name = "lbl_usrnme";
            this.lbl_usrnme.Size = new System.Drawing.Size(90, 18);
            this.lbl_usrnme.TabIndex = 0;
            this.lbl_usrnme.Text = "Username";
            // 
            // Frm_login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(541, 243);
            this.Controls.Add(this.grpbx_login);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.grpbx_login.ResumeLayout(false);
            this.grpbx_login.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpbx_login;
        private System.Windows.Forms.Label lbl_usrnme;
        private System.Windows.Forms.Label lbl_pswd;
        private System.Windows.Forms.Button btn_lgn;
        private System.Windows.Forms.TextBox txtbx_pswd;
        private System.Windows.Forms.TextBox txtbx_usrnme;
        private System.Windows.Forms.Button btn_close;
    }
}

