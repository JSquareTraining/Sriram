﻿namespace Ado_Department
{
    partial class Frm_Prdct_Inwrd_Search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Prdct_Inwrd_Search));
            this.pnl_prdct_inwrd_search = new System.Windows.Forms.Panel();
            this.dtgv_prdct_inwrd_search = new System.Windows.Forms.DataGridView();
            this.btn_prdct_inwrd_search = new System.Windows.Forms.Button();
            this.lbl_search = new System.Windows.Forms.Label();
            this.txtbx_prdct_inwrd_search = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbtn_prdct_inwrd = new System.Windows.Forms.RadioButton();
            this.rdbtn_prdct_return = new System.Windows.Forms.RadioButton();
            this.pnl_prdct_inwrd_search.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_prdct_inwrd_search)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_prdct_inwrd_search
            // 
            this.pnl_prdct_inwrd_search.BackColor = System.Drawing.Color.AliceBlue;
            this.pnl_prdct_inwrd_search.Controls.Add(this.groupBox1);
            this.pnl_prdct_inwrd_search.Controls.Add(this.dtgv_prdct_inwrd_search);
            this.pnl_prdct_inwrd_search.Controls.Add(this.btn_prdct_inwrd_search);
            this.pnl_prdct_inwrd_search.Controls.Add(this.lbl_search);
            this.pnl_prdct_inwrd_search.Controls.Add(this.txtbx_prdct_inwrd_search);
            this.pnl_prdct_inwrd_search.Location = new System.Drawing.Point(13, 13);
            this.pnl_prdct_inwrd_search.Name = "pnl_prdct_inwrd_search";
            this.pnl_prdct_inwrd_search.Size = new System.Drawing.Size(778, 447);
            this.pnl_prdct_inwrd_search.TabIndex = 0;
           // this.pnl_prdct_inwrd_search.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_prdct_inwrd_search_Paint);
            // 
            // dtgv_prdct_inwrd_search
            // 
            this.dtgv_prdct_inwrd_search.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgv_prdct_inwrd_search.Location = new System.Drawing.Point(14, 122);
            this.dtgv_prdct_inwrd_search.Name = "dtgv_prdct_inwrd_search";
            this.dtgv_prdct_inwrd_search.Size = new System.Drawing.Size(750, 314);
            this.dtgv_prdct_inwrd_search.TabIndex = 15;
            // 
            // btn_prdct_inwrd_search
            // 
            this.btn_prdct_inwrd_search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_prdct_inwrd_search.Image = ((System.Drawing.Image)(resources.GetObject("btn_prdct_inwrd_search.Image")));
            this.btn_prdct_inwrd_search.Location = new System.Drawing.Point(663, 57);
            this.btn_prdct_inwrd_search.Name = "btn_prdct_inwrd_search";
            this.btn_prdct_inwrd_search.Size = new System.Drawing.Size(101, 26);
            this.btn_prdct_inwrd_search.TabIndex = 14;
            this.btn_prdct_inwrd_search.Text = "Search";
            this.btn_prdct_inwrd_search.UseVisualStyleBackColor = true;
            this.btn_prdct_inwrd_search.Click += new System.EventHandler(this.btn_prdct_inwrd_search_Click);
            // 
            // lbl_search
            // 
            this.lbl_search.AutoSize = true;
            this.lbl_search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_search.Location = new System.Drawing.Point(339, 19);
            this.lbl_search.Name = "lbl_search";
            this.lbl_search.Size = new System.Drawing.Size(75, 22);
            this.lbl_search.TabIndex = 13;
            this.lbl_search.Text = "Search";
            // 
            // txtbx_prdct_inwrd_search
            // 
            this.txtbx_prdct_inwrd_search.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_prdct_inwrd_search.Location = new System.Drawing.Point(14, 57);
            this.txtbx_prdct_inwrd_search.Name = "txtbx_prdct_inwrd_search";
            this.txtbx_prdct_inwrd_search.Size = new System.Drawing.Size(648, 26);
            this.txtbx_prdct_inwrd_search.TabIndex = 12;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbtn_prdct_return);
            this.groupBox1.Controls.Add(this.rdbtn_prdct_inwrd);
            this.groupBox1.Location = new System.Drawing.Point(240, 83);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(316, 35);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            // 
            // rdbtn_prdct_inwrd
            // 
            this.rdbtn_prdct_inwrd.AutoSize = true;
            this.rdbtn_prdct_inwrd.Checked = true;
            this.rdbtn_prdct_inwrd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_prdct_inwrd.Location = new System.Drawing.Point(17, 12);
            this.rdbtn_prdct_inwrd.Name = "rdbtn_prdct_inwrd";
            this.rdbtn_prdct_inwrd.Size = new System.Drawing.Size(125, 19);
            this.rdbtn_prdct_inwrd.TabIndex = 0;
            this.rdbtn_prdct_inwrd.TabStop = true;
            this.rdbtn_prdct_inwrd.Text = "Product Inward";
            this.rdbtn_prdct_inwrd.UseVisualStyleBackColor = true;
            // 
            // rdbtn_prdct_return
            // 
            this.rdbtn_prdct_return.AutoSize = true;
            this.rdbtn_prdct_return.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbtn_prdct_return.Location = new System.Drawing.Point(168, 12);
            this.rdbtn_prdct_return.Name = "rdbtn_prdct_return";
            this.rdbtn_prdct_return.Size = new System.Drawing.Size(124, 19);
            this.rdbtn_prdct_return.TabIndex = 1;
            this.rdbtn_prdct_return.Text = "Product Return";
            this.rdbtn_prdct_return.UseVisualStyleBackColor = true;
           // this.rdbtn_prdct_return.CheckedChanged += new System.EventHandler(this.rdbtn_prdct_return_CheckedChanged);
            // 
            // Frm_Prdct_Inwrd_Search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(803, 472);
            this.Controls.Add(this.pnl_prdct_inwrd_search);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Frm_Prdct_Inwrd_Search";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.pnl_prdct_inwrd_search.ResumeLayout(false);
            this.pnl_prdct_inwrd_search.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgv_prdct_inwrd_search)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_prdct_inwrd_search;
        private System.Windows.Forms.DataGridView dtgv_prdct_inwrd_search;
        private System.Windows.Forms.Button btn_prdct_inwrd_search;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.TextBox txtbx_prdct_inwrd_search;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbtn_prdct_inwrd;
        private System.Windows.Forms.RadioButton rdbtn_prdct_return;
    }
}