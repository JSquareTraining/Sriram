﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ado_Department
{
    public partial class Frm_dept_search : Form
    {
        public Frm_dept_search()
        {
            InitializeComponent();
        }
        Connection sql_connection = new Connection();
        private void btn_dept_search_Click(object sender, EventArgs e)
        {
            if (txtbx_dept_search.Text == "")
            {
                MessageBox.Show("Please enter search field");
            }
            else
            {
                dtgv_dept_search.DataSource = sql_connection.table_data("SELECT * FROM DEPARTMENT WHERE D_ID = '" + txtbx_dept_search.Text + "' OR D_NAME = '" + txtbx_dept_search.Text + "'");
                txtbx_dept_search.Text = "";
            }
        }
    }
}
