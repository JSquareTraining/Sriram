﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ado_Department
{
    public partial class Frm_Prdct_Inwrd_Search : Form
    {
        public Frm_Prdct_Inwrd_Search()
        {
            InitializeComponent();
        }

        Connection sql_connection = new Connection();
        //private void pnl_prdct_inwrd_search_Paint(object sender, PaintEventArgs e)
        //{

        //}

        private void btn_prdct_inwrd_search_Click(object sender, EventArgs e)
        {
            if (txtbx_prdct_inwrd_search.Text == "")
            {
                MessageBox.Show("Please enter Blank field");
            }
            else if (rdbtn_prdct_inwrd.Checked == true)
            {
                dtgv_prdct_inwrd_search.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT_INWARD WHERE PI_ID LIKE '" + txtbx_prdct_inwrd_search.Text + "%' OR P_ID LIKE '" + txtbx_prdct_inwrd_search.Text + "%' OR E_ID LIKE '" + txtbx_prdct_inwrd_search.Text + "%' OR DATEE LIKE '" + txtbx_prdct_inwrd_search.Text + "%'");
                txtbx_prdct_inwrd_search.Text = "";
            }
            else
            {
                dtgv_prdct_inwrd_search.DataSource = sql_connection.table_data("SELECT * FROM PURCHASE_RETURN WHERE PR_ID LIKE '" + txtbx_prdct_inwrd_search.Text + "%' OR PI_ID LIKE '" + txtbx_prdct_inwrd_search.Text + "%' OR DATEE LIKE '" + txtbx_prdct_inwrd_search.Text + "%'");
                txtbx_prdct_inwrd_search.Text = "";
            }
        }      
    }
}
