﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ado_Department
{
    public partial class Frm_prdct_inward_reg : Form
    {
        public Frm_prdct_inward_reg()
        {
            InitializeComponent();
        }
        Connection sql_connection = new Connection();
        private void Frm_prdct_inward_reg_Load(object sender, EventArgs e)
        {
            object piid_count = sql_connection.connect("SELECT COUNT(PI_ID) FROM PRODUCT_INWARD");
            if (Convert.ToInt32(piid_count) < 0)
            {
                txtbx_prdct_inwrd_id.Text = "PI1";
            }
            else
            {
                txtbx_prdct_inwrd_id.Text = "PI" + (Convert.ToInt32(piid_count) + 1).ToString();
            }
            dtgv_prdct_inwrd_reg.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT_INWARD");

            cmbx_prdct_name.DisplayMember = "P_NAME";
            cmbx_prdct_name.DataSource = sql_connection.table_data("SELECT P_NAME FROM PRODUCT");

            cmbx_emp_name.DisplayMember = "E_NAME";
            cmbx_emp_name.DataSource = sql_connection.table_data("SELECT E_NAME FROM EMPLOYEE");
        }

        private void txtbx_prdct_qnty_TextChanged(object sender, EventArgs e)
        {
            object prdct_price = sql_connection.connect("SELECT PRODUCT_PRICE FROM PRODUCT WHERE P_NAME = '" + cmbx_prdct_name.Text + "'");
            if(txtbx_prdct_qnty.Text == "")
            {
                txtbx_prdct_qnty.Text = "0";
            }

            txtbx_prdct_total_price.Text = (Convert.ToInt32(txtbx_prdct_qnty.Text) * Convert.ToInt32(prdct_price)).ToString();
        }

        private void btn_prdct_inwrd_reg_submit_Click(object sender, EventArgs e)
        {
            if (txtbx_prdct_qnty.Text == "" || txtbx_prdct_total_price.Text == "")
            {
                MessageBox.Show("Please fill the blank field");
            }
            else
            {
                object piid_count = sql_connection.connect("SELECT COUNT(PI_ID) FROM PRODUCT_INWARD");
                if (Convert.ToInt32(piid_count) < 0)
                {
                    txtbx_prdct_inwrd_id.Text = "PI1";
                }
                else
                {
                    txtbx_prdct_inwrd_id.Text = "PI" + (Convert.ToInt32(piid_count) + 1).ToString();
                }
                object prdct_id = sql_connection.connect("SELECT P_ID FROM PRODUCT WHERE P_NAME = '"+cmbx_prdct_name.Text+"'");
                object emp_id = sql_connection.connect("SELECT E_ID FROM EMPLOYEE WHERE E_NAME = '"+cmbx_emp_name.Text+"'");
                sql_connection.table_data("INSERT INTO PRODUCT_INWARD VALUES('" + txtbx_prdct_inwrd_id.Text + "','" + prdct_id.ToString() + "','" + txtbx_prdct_qnty.Text + "','" + txtbx_prdct_total_price.Text + "','" + emp_id + "','" + dtp_date_of_reg.Value.ToShortDateString() + "')");
                dtgv_prdct_inwrd_reg.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT_INWARD");

                txtbx_prdct_inwrd_id.Text = "";
                txtbx_prdct_qnty.Text = "";
                txtbx_prdct_total_price.Text = "";

            }
        }

        private void cmbx_prdct_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtbx_prdct_qnty.Text = "0";
            txtbx_prdct_total_price.Text = "0";
        }

        private void dtgv_prdct_inwrd_reg_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            object prdct_name = sql_connection.connect("SELECT P_ID FROM PRODUCT_INWARD WHERE PI_ID = '" + dtgv_prdct_inwrd_reg.CurrentCell.Value + "'");
            object emp_name = sql_connection.connect("SELECT E_ID FROM PRODUCT_INWARD WHERE PI_ID = '" + dtgv_prdct_inwrd_reg.CurrentCell.Value + "'");
            try
            {
                txtbx_prdct_inwrd_id.Text = sql_connection.connect("SELECT PI_ID FROM PRODUCT_INWARD WHERE PI_ID = '" + dtgv_prdct_inwrd_reg.CurrentCell.Value + "'").ToString();
                cmbx_prdct_name.Text = sql_connection.connect("SELECT P_NAME FROM PRODUCT WHERE P_ID = '" + prdct_name.ToString() + "'").ToString();
                txtbx_prdct_qnty.Text = sql_connection.connect("SELECT QUANTITY FROM PRODUCT_INWARD WHERE PI_ID = '" + dtgv_prdct_inwrd_reg.CurrentCell.Value + "'").ToString();
                txtbx_prdct_total_price.Text = sql_connection.connect("SELECT TOTAL_PRICE FROM PRODUCT_INWARD WHERE PI_ID = '" + dtgv_prdct_inwrd_reg.CurrentCell.Value + "'").ToString();
                cmbx_emp_name.Text = sql_connection.connect("SELECT E_NAME FROM EMPLOYEE WHERE E_ID = '" + emp_name + "'").ToString();
                dtp_date_of_reg.Value = Convert.ToDateTime(Convert.ToDateTime(sql_connection.connect("SELECT DATEE FROM PRODUCT_INWARD WHERE PI_ID = '" + dtgv_prdct_inwrd_reg.CurrentCell.Value + "'")).ToShortDateString());
            }
            catch(NullReferenceException ex)
            {
            }
        }

        private void btn_prdct_inwrd_reg_update_Click(object sender, EventArgs e)
        {
            object prdct_name = sql_connection.connect("SELECT P_ID FROM PRODUCT WHERE P_NAME = '"+cmbx_prdct_name.Text+"'");
            object emp_name = sql_connection.connect("SELECT E_ID FROM EMPLOYEE WHERE E_NAME = '" + cmbx_emp_name.Text + "'");

            if (txtbx_prdct_qnty.Text == "" || txtbx_prdct_total_price.Text == "")
            {
                MessageBox.Show("Please fill the blank field");
            }
            else
            {
                try
                {
                    sql_connection.table_data("UPDATE PRODUCT_INWARD SET P_ID = '" + prdct_name + "',QUANTITY = '" + txtbx_prdct_qnty.Text + "',TOTAL_PRICE = '" + txtbx_prdct_total_price.Text + "',E_ID ='" + emp_name + "',DATEE ='" + dtp_date_of_reg.Value.ToShortDateString() + "' WHERE PI_ID = '" + txtbx_prdct_inwrd_id.Text + "'");
                    dtgv_prdct_inwrd_reg.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT_INWARD");
                    txtbx_prdct_inwrd_id.Text = "";
                    txtbx_prdct_qnty.Text = "";
                    txtbx_prdct_total_price.Text = "";
                }
                catch (NullReferenceException ex)
                {
                }
            }
        }

        private void btn_prdct_inwrd_reg_delete_Click(object sender, EventArgs e)
        {
            try
            {
                sql_connection.table_data("DELETE PRODUCT_INWARD WHERE PI_ID = '" + txtbx_prdct_inwrd_id.Text + "'");
                dtgv_prdct_inwrd_reg.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT_INWARD");
                txtbx_prdct_inwrd_id.Text = "";
                txtbx_prdct_qnty.Text = "";
                txtbx_prdct_total_price.Text = "";
            }
            catch(NullReferenceException ex)
            {
            }
        }
    }
}
