﻿namespace Ado_Department
{
    partial class Frm_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tsm_dept = new System.Windows.Forms.ToolStripMenuItem();
            this.tmi_regstn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
            this.tmi_search = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsm_employee = new System.Windows.Forms.ToolStripMenuItem();
            this.tmi_emp_regstrtn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripSeparator();
            this.tmi_emp_search = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsm_product = new System.Windows.Forms.ToolStripMenuItem();
            this.tmi_prdct_regstn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripSeparator();
            this.tmi_prdct_srch = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsm_purchase = new System.Windows.Forms.ToolStripMenuItem();
            this.tmi_purcse_inward = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripSeparator();
            this.tmi_prchse_search = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripSeparator();
            this.tmi_prchse_rtrn = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsm_sales = new System.Windows.Forms.ToolStripMenuItem();
            this.tmi_sales_outward = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripSeparator();
            this.tmi_sales_search = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripSeparator();
            this.tmi_sales_return = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.profitLossToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dateWiseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yearWiseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productWiseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inwardWiseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outwardWiseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.menuStrip1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsm_dept,
            this.toolStripMenuItem1,
            this.tsm_employee,
            this.toolStripMenuItem2,
            this.tsm_product,
            this.toolStripMenuItem3,
            this.tsm_purchase,
            this.toolStripMenuItem4,
            this.tsm_sales,
            this.toolStripMenuItem5,
            this.profitLossToolStripMenuItem,
            this.toolStripMenuItem6,
            this.reportsToolStripMenuItem,
            this.toolStripMenuItem7});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1364, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tsm_dept
            // 
            this.tsm_dept.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tmi_regstn,
            this.toolStripMenuItem8,
            this.tmi_search});
            this.tsm_dept.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsm_dept.Name = "tsm_dept";
            this.tsm_dept.Size = new System.Drawing.Size(115, 24);
            this.tsm_dept.Text = "Department";
            // 
            // tmi_regstn
            // 
            this.tmi_regstn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tmi_regstn.Name = "tmi_regstn";
            this.tmi_regstn.Size = new System.Drawing.Size(155, 22);
            this.tmi_regstn.Text = "Registration";
            this.tmi_regstn.Click += new System.EventHandler(this.tmi_regstn_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(152, 6);
            // 
            // tmi_search
            // 
            this.tmi_search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tmi_search.Name = "tmi_search";
            this.tmi_search.Size = new System.Drawing.Size(155, 22);
            this.tmi_search.Text = "Search";
            this.tmi_search.Click += new System.EventHandler(this.tmi_search_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(26, 24);
            this.toolStripMenuItem1.Text = "|";
            // 
            // tsm_employee
            // 
            this.tsm_employee.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tmi_emp_regstrtn,
            this.toolStripMenuItem9,
            this.tmi_emp_search});
            this.tsm_employee.Name = "tsm_employee";
            this.tsm_employee.Size = new System.Drawing.Size(102, 24);
            this.tsm_employee.Text = "Employee";
            // 
            // tmi_emp_regstrtn
            // 
            this.tmi_emp_regstrtn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tmi_emp_regstrtn.Name = "tmi_emp_regstrtn";
            this.tmi_emp_regstrtn.Size = new System.Drawing.Size(156, 22);
            this.tmi_emp_regstrtn.Text = "Registration";
            this.tmi_emp_regstrtn.Click += new System.EventHandler(this.tmi_emp_regstrtn_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(153, 6);
            // 
            // tmi_emp_search
            // 
            this.tmi_emp_search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tmi_emp_search.Name = "tmi_emp_search";
            this.tmi_emp_search.Size = new System.Drawing.Size(156, 22);
            this.tmi_emp_search.Text = "Search";
            this.tmi_emp_search.Click += new System.EventHandler(this.tmi_emp_search_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(26, 24);
            this.toolStripMenuItem2.Text = "|";
            // 
            // tsm_product
            // 
            this.tsm_product.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tmi_prdct_regstn,
            this.toolStripMenuItem10,
            this.tmi_prdct_srch});
            this.tsm_product.Name = "tsm_product";
            this.tsm_product.Size = new System.Drawing.Size(86, 24);
            this.tsm_product.Text = "Product";
            // 
            // tmi_prdct_regstn
            // 
            this.tmi_prdct_regstn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tmi_prdct_regstn.Name = "tmi_prdct_regstn";
            this.tmi_prdct_regstn.Size = new System.Drawing.Size(156, 22);
            this.tmi_prdct_regstn.Text = "Registration";
            this.tmi_prdct_regstn.Click += new System.EventHandler(this.tmi_prdct_regstn_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(153, 6);
            // 
            // tmi_prdct_srch
            // 
            this.tmi_prdct_srch.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tmi_prdct_srch.Name = "tmi_prdct_srch";
            this.tmi_prdct_srch.Size = new System.Drawing.Size(156, 22);
            this.tmi_prdct_srch.Text = "Search";
            this.tmi_prdct_srch.Click += new System.EventHandler(this.tmi_prdct_srch_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(26, 24);
            this.toolStripMenuItem3.Text = "|";
            // 
            // tsm_purchase
            // 
            this.tsm_purchase.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tmi_purcse_inward,
            this.toolStripMenuItem11,
            this.tmi_prchse_search,
            this.toolStripMenuItem12,
            this.tmi_prchse_rtrn});
            this.tsm_purchase.Name = "tsm_purchase";
            this.tsm_purchase.Size = new System.Drawing.Size(98, 24);
            this.tsm_purchase.Text = "Purchase";
            this.tsm_purchase.Click += new System.EventHandler(this.tsm_purchase_Click);
            // 
            // tmi_purcse_inward
            // 
            this.tmi_purcse_inward.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tmi_purcse_inward.Name = "tmi_purcse_inward";
            this.tmi_purcse_inward.Size = new System.Drawing.Size(123, 22);
            this.tmi_purcse_inward.Text = "Inward";
            this.tmi_purcse_inward.Click += new System.EventHandler(this.tmi_purcse_inward_Click);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(120, 6);
            // 
            // tmi_prchse_search
            // 
            this.tmi_prchse_search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tmi_prchse_search.Name = "tmi_prchse_search";
            this.tmi_prchse_search.Size = new System.Drawing.Size(123, 22);
            this.tmi_prchse_search.Text = "Search";
            this.tmi_prchse_search.Click += new System.EventHandler(this.tmi_prchse_search_Click);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(120, 6);
            // 
            // tmi_prchse_rtrn
            // 
            this.tmi_prchse_rtrn.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tmi_prchse_rtrn.Name = "tmi_prchse_rtrn";
            this.tmi_prchse_rtrn.Size = new System.Drawing.Size(123, 22);
            this.tmi_prchse_rtrn.Text = "Return";
            this.tmi_prchse_rtrn.Click += new System.EventHandler(this.tmi_prchse_rtrn_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(26, 24);
            this.toolStripMenuItem4.Text = "|";
            // 
            // tsm_sales
            // 
            this.tsm_sales.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tmi_sales_outward,
            this.toolStripMenuItem13,
            this.tmi_sales_search,
            this.toolStripMenuItem15,
            this.tmi_sales_return});
            this.tsm_sales.Name = "tsm_sales";
            this.tsm_sales.Size = new System.Drawing.Size(66, 24);
            this.tsm_sales.Text = "Sales";
            // 
            // tmi_sales_outward
            // 
            this.tmi_sales_outward.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tmi_sales_outward.Name = "tmi_sales_outward";
            this.tmi_sales_outward.Size = new System.Drawing.Size(132, 22);
            this.tmi_sales_outward.Text = "Outward";
            this.tmi_sales_outward.Click += new System.EventHandler(this.tmi_sales_outward_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(129, 6);
            // 
            // tmi_sales_search
            // 
            this.tmi_sales_search.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tmi_sales_search.Name = "tmi_sales_search";
            this.tmi_sales_search.Size = new System.Drawing.Size(132, 22);
            this.tmi_sales_search.Text = "Search";
            this.tmi_sales_search.Click += new System.EventHandler(this.tmi_sales_search_Click);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(129, 6);
            // 
            // tmi_sales_return
            // 
            this.tmi_sales_return.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tmi_sales_return.Name = "tmi_sales_return";
            this.tmi_sales_return.Size = new System.Drawing.Size(132, 22);
            this.tmi_sales_return.Text = "Return";
            this.tmi_sales_return.Click += new System.EventHandler(this.tmi_sales_return_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(26, 24);
            this.toolStripMenuItem5.Text = "|";
            // 
            // profitLossToolStripMenuItem
            // 
            this.profitLossToolStripMenuItem.Name = "profitLossToolStripMenuItem";
            this.profitLossToolStripMenuItem.Size = new System.Drawing.Size(109, 24);
            this.profitLossToolStripMenuItem.Text = "Profit/Loss";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(26, 24);
            this.toolStripMenuItem6.Text = "|";
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dateWiseToolStripMenuItem,
            this.yearWiseToolStripMenuItem,
            this.productWiseToolStripMenuItem,
            this.inwardWiseToolStripMenuItem,
            this.outwardWiseToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(86, 24);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // dateWiseToolStripMenuItem
            // 
            this.dateWiseToolStripMenuItem.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateWiseToolStripMenuItem.Name = "dateWiseToolStripMenuItem";
            this.dateWiseToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.dateWiseToolStripMenuItem.Text = "Date Wise";
            // 
            // yearWiseToolStripMenuItem
            // 
            this.yearWiseToolStripMenuItem.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearWiseToolStripMenuItem.Name = "yearWiseToolStripMenuItem";
            this.yearWiseToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.yearWiseToolStripMenuItem.Text = "Year Wise";
            // 
            // productWiseToolStripMenuItem
            // 
            this.productWiseToolStripMenuItem.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productWiseToolStripMenuItem.Name = "productWiseToolStripMenuItem";
            this.productWiseToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.productWiseToolStripMenuItem.Text = "Product Wise";
            // 
            // inwardWiseToolStripMenuItem
            // 
            this.inwardWiseToolStripMenuItem.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inwardWiseToolStripMenuItem.Name = "inwardWiseToolStripMenuItem";
            this.inwardWiseToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.inwardWiseToolStripMenuItem.Text = "Inward Return";
            // 
            // outwardWiseToolStripMenuItem
            // 
            this.outwardWiseToolStripMenuItem.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outwardWiseToolStripMenuItem.Name = "outwardWiseToolStripMenuItem";
            this.outwardWiseToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.outwardWiseToolStripMenuItem.Text = "Outward Return";
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(26, 24);
            this.toolStripMenuItem7.Text = "|";
            // 
            // Frm_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(1364, 743);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Frm_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Frm_Main_FormClosed);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsm_dept;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tsm_employee;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem tsm_product;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem tsm_purchase;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem tsm_sales;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem profitLossToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem tmi_regstn;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem tmi_search;
        private System.Windows.Forms.ToolStripMenuItem tmi_emp_regstrtn;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem tmi_emp_search;
        private System.Windows.Forms.ToolStripMenuItem tmi_prdct_regstn;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem tmi_prdct_srch;
        private System.Windows.Forms.ToolStripMenuItem tmi_purcse_inward;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem tmi_prchse_search;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem tmi_prchse_rtrn;
        private System.Windows.Forms.ToolStripMenuItem tmi_sales_outward;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem tmi_sales_search;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem tmi_sales_return;
        private System.Windows.Forms.ToolStripMenuItem dateWiseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yearWiseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productWiseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inwardWiseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outwardWiseToolStripMenuItem;
    }
}