﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ado_Department
{
    public partial class Frm_prdct_inwrd_return : Form
    {
        public Frm_prdct_inwrd_return()
        {
            InitializeComponent();
        }
        Connection sql_connection = new Connection();
        private void Frm_prdct_inwrd_return_Load(object sender, EventArgs e)
        {
            dtgv_prdct_inwrd_return.DataSource = sql_connection.table_data("SELECT * FROM PURCHASE_RETURN");
            object pr_id = sql_connection.connect("SELECT COUNT(PR_ID) FROM PURCHASE_RETURN");
            if (Convert.ToInt32(pr_id) == 0)
            {
                txtbx_prdct_inwrd_return_id.Text = "PR1";
            }
            else
            {
                txtbx_prdct_inwrd_return_id.Text = "PR" + (Convert.ToInt32(pr_id) + 1);
            }

            cmbx_inwrd_id.DisplayMember = "PI_ID";
            cmbx_inwrd_id.DataSource = sql_connection.table_data("SELECT PI_ID FROM PRODUCT_INWARD");

        }

        private void cmbx_inwrd_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            object p_id = sql_connection.connect("SELECT P_ID FROM PRODUCT_INWARD WHERE PI_ID = '" + cmbx_inwrd_id.Text + "'");
            object p_name = sql_connection.connect("SELECT P_NAME FROM PRODUCT WHERE P_ID ='" + p_id + "'");
            txtbx_prdct_name.Text = p_name.ToString();
            txtbx_prdct_quantity.Text = sql_connection.connect("SELECT SUM(CAST(QUANTITY AS INT)) FROM PRODUCT_INWARD GROUP BY P_ID HAVING P_ID = '"+p_id+"'").ToString();
            txtbx_purchase_date.Text = sql_connection.connect("SELECT DATEE FROM PRODUCT_INWARD WHERE PI_ID = '" + cmbx_inwrd_id.Text + "'").ToString();
            if (txtbx_return_qnty.Text == "")
            {
                txtbx_return_qnty.Text = "0";
            }
        }

        private void txtbx_return_qnty_TextChanged(object sender, EventArgs e)
        {
            object p_id = sql_connection.connect("SELECT P_ID FROM PRODUCT_INWARD WHERE PI_ID = '" + cmbx_inwrd_id.Text + "'");
            object prdct_price = sql_connection.connect("SELECT PRODUCT_PRICE FROM PRODUCT WHERE P_ID = '" + p_id + "'").ToString();
            
            if (txtbx_return_qnty.Text == "")
            {
                txtbx_return_qnty.Text = "0";
            }
            txtbx_return_amount.Text = (Convert.ToInt32(txtbx_return_qnty.Text) * Convert.ToInt32(prdct_price)).ToString();         
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (txtbx_prdct_name.Text == "" || txtbx_prdct_quantity.Text == "" || txtbx_purchase_date.Text == "" || txtbx_return_qnty.Text == "" || txtbx_return_amount.Text == "" || txtbx_reason.Text == "")
            {
                MessageBox.Show("Please fill the blank field");
            }
            else
            {
                if (Convert.ToInt32(txtbx_prdct_quantity.Text) > Convert.ToInt32(txtbx_return_qnty.Text))
                {
                    sql_connection.table_data("INSERT INTO PURCHASE_RETURN VALUES('" + txtbx_prdct_inwrd_return_id.Text + "','" + cmbx_inwrd_id.Text + "','" + txtbx_prdct_name.Text + "','" + txtbx_prdct_quantity.Text + "','" + txtbx_purchase_date.Text + "','" + txtbx_return_qnty.Text + "','" + txtbx_return_amount.Text + "','" + txtbx_reason.Text + "')");
                    dtgv_prdct_inwrd_return.DataSource = sql_connection.table_data("SELECT * FROM PURCHASE_RETURN");
                    object pr_id = sql_connection.connect("SELECT COUNT(PR_ID) FROM PURCHASE_RETURN");
                    if (Convert.ToInt32(pr_id) == 0)
                    {
                        txtbx_prdct_inwrd_return_id.Text = "PR1";
                    }
                    else
                    {
                        txtbx_prdct_inwrd_return_id.Text = "PR" + (Convert.ToInt32(pr_id) + 1);
                    }

                    txtbx_prdct_name.Text = "";
                    txtbx_prdct_quantity.Text = "";
                    txtbx_purchase_date.Text = "";
                    txtbx_reason.Text = "";
                    txtbx_return_amount.Text = "";
                    txtbx_return_qnty.Text = "";
                }
                else
                {
                    MessageBox.Show("Stock not Available");
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txtbx_prdct_name.Text == "" || txtbx_prdct_quantity.Text == "" || txtbx_purchase_date.Text == "" || txtbx_return_qnty.Text == "" || txtbx_return_amount.Text == "" || txtbx_reason.Text == "")
            {
                MessageBox.Show("Please fill the blank field");
            }
            else
            {
                if (Convert.ToInt32(txtbx_prdct_quantity.Text) > Convert.ToInt32(txtbx_return_qnty.Text))
                {
                    sql_connection.table_data("UPDATE PURCHASE_RETURN SET PI_ID = '" + cmbx_inwrd_id.Text + "',P_NAME = '" + txtbx_prdct_name.Text + "',QUANTITY = '" + txtbx_prdct_quantity.Text + "',DATEE = '" + txtbx_purchase_date.Text + "',RETURN_QUANTITY = '" + txtbx_return_qnty.Text + "',RETURN_AMOUNT = '" + txtbx_return_amount.Text + "',REASON ='" + txtbx_reason.Text + "' WHERE PR_ID = '" + txtbx_prdct_inwrd_return_id.Text + "'");
                    dtgv_prdct_inwrd_return.DataSource = sql_connection.table_data("SELECT * FROM PURCHASE_RETURN");
                    txtbx_prdct_name.Text = "";
                    txtbx_prdct_quantity.Text = "";
                    txtbx_purchase_date.Text = "";
                    txtbx_reason.Text = "";
                    txtbx_return_amount.Text = "";
                    txtbx_return_qnty.Text = "";
                }
                else
                {
                    MessageBox.Show("Stock not Available");
                }
            }
        }

        private void dtgv_prdct_inwrd_return_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtbx_prdct_inwrd_return_id.Text = sql_connection.connect("SELECT PR_ID FROM PURCHASE_RETURN WHERE PR_ID = '" + dtgv_prdct_inwrd_return.CurrentCell.Value + "'").ToString();
                cmbx_inwrd_id.Text = sql_connection.connect("SELECT PI_ID FROM PURCHASE_RETURN WHERE PR_ID = '" + dtgv_prdct_inwrd_return.CurrentCell.Value + "'").ToString();
                txtbx_prdct_name.Text = sql_connection.connect("SELECT P_NAME FROM PURCHASE_RETURN WHERE PR_ID = '" + dtgv_prdct_inwrd_return.CurrentCell.Value + "'").ToString();
                txtbx_prdct_quantity.Text = sql_connection.connect("SELECT QUANTITY FROM PURCHASE_RETURN WHERE PR_ID = '" + dtgv_prdct_inwrd_return.CurrentCell.Value + "'").ToString();
                txtbx_purchase_date.Text = sql_connection.connect("SELECT DATEE FROM PURCHASE_RETURN WHERE PR_ID = '" + dtgv_prdct_inwrd_return.CurrentCell.Value + "'").ToString();
                txtbx_return_qnty.Text = sql_connection.connect("SELECT RETURN_QUANTITY FROM PURCHASE_RETURN WHERE PR_ID = '" + dtgv_prdct_inwrd_return.CurrentCell.Value + "'").ToString();
                txtbx_return_amount.Text = sql_connection.connect("SELECT RETURN_AMOUNT FROM PURCHASE_RETURN WHERE PR_ID = '" + dtgv_prdct_inwrd_return.CurrentCell.Value + "'").ToString();
                txtbx_reason.Text = sql_connection.connect("SELECT REASON FROM PURCHASE_RETURN WHERE PR_ID = '" + dtgv_prdct_inwrd_return.CurrentCell.Value + "'").ToString();
            }
            catch (NullReferenceException ex)
            {
                MessageBox.Show("Please click the product inward purchase return id");
            }
        
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                sql_connection.table_data("DELETE PURCHASE_RETURN WHERE PR_ID = '" + txtbx_prdct_inwrd_return_id.Text + "'");
                dtgv_prdct_inwrd_return.DataSource = sql_connection.table_data("SELECT * FROM PURCHASE_RETURN");
                txtbx_prdct_name.Text = "";
                txtbx_prdct_quantity.Text = "";
                txtbx_purchase_date.Text = "";
                txtbx_reason.Text = "";
                txtbx_return_amount.Text = "";
                txtbx_return_qnty.Text = "";
            }
            catch (NullReferenceException ex)
            {
                MessageBox.Show("Please select the record to be deleted");
            }
        }
    }
}
