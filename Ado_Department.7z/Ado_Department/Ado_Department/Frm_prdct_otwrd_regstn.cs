﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ado_Department
{
    public partial class Frm_prdct_otwrd_regstn : Form
    {
        public Frm_prdct_otwrd_regstn()
        {
            InitializeComponent();
        }
        Connection sql_connection = new Connection();
        private void Frm_prdct_otwrd_regstn_Load(object sender, EventArgs e)
        {
            object prdct_otwrd_id = sql_connection.connect("SELECT COUNT(PO_ID) FROM PRODUCT_OUTWARD");
            if (Convert.ToInt32(prdct_otwrd_id) <= 0)
            {
                txtbx_prdct_outwrd_id.Text = "PO1";
            }
            else
            {
                txtbx_prdct_outwrd_id.Text = "PO" + (Convert.ToInt32(prdct_otwrd_id) + 1);
            }
            
            dtgv.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT_OUTWARD");

            cmbx_prdct_name.DisplayMember = "P_NAME";
            cmbx_prdct_name.ValueMember = "P_ID";
            cmbx_prdct_name.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT");
            
           
            cmbx_emp_name.DisplayMember = "E_NAME";
            cmbx_emp_name.ValueMember = "E_ID";
            cmbx_emp_name.DataSource = sql_connection.table_data("SELECT * FROM EMPLOYEE");

            txtbx_date.Text = DateTime.Now.ToShortDateString();
       }

        private void txtbx_prdct_qnty_TextChanged(object sender, EventArgs e)
        {
            object sales_price = sql_connection.connect("SELECT SALES_PRICE FROM PRODUCT WHERE P_NAME = '"+cmbx_prdct_name.Text+"'");
            if (txtbx_prdct_qnty.Text == "")
            {
                txtbx_prdct_qnty.Text = "0";
            }

            txtbx_total_price.Text = (Convert.ToInt32(txtbx_prdct_qnty.Text) * Convert.ToInt32(sales_price)).ToString();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            object quantity = sql_connection.connect("SELECT SUM(CAST(QUANTITY AS INT)) FROM PRODUCT_INWARD GROUP BY P_ID HAVING P_ID = '" + cmbx_prdct_name.SelectedValue.ToString()+ "'");


            if (txtbx_prdct_qnty.Text == "" || txtbx_total_price.Text == "")
            {
                MessageBox.Show("Please enter the valid fields");
            }
            else if (Convert.ToInt32(txtbx_prdct_qnty.Text) > Convert.ToInt32(quantity))
            {
                MessageBox.Show("Stock not available");
            }
            else
            {
                sql_connection.table_data("INSERT INTO PRODUCT_OUTWARD VALUES('"+txtbx_prdct_outwrd_id.Text+"','"+cmbx_prdct_name.SelectedValue+"','"+txtbx_prdct_qnty.Text+"','"+txtbx_total_price.Text+"','"+cmbx_emp_name.SelectedValue+"','"+txtbx_date.Text+"')");
                object prdct_otwrd_id = sql_connection.connect("SELECT COUNT(PO_ID) FROM PRODUCT_OUTWARD");
              
                if (Convert.ToInt32(prdct_otwrd_id) <= 0)
                {
                    txtbx_prdct_outwrd_id.Text = "PO1";
                }
                else
                {
                    txtbx_prdct_outwrd_id.Text = "PO" + (Convert.ToInt32(prdct_otwrd_id) + 1);
                }

                txtbx_date.Text = "";
                txtbx_prdct_outwrd_id.Text = "";
                txtbx_prdct_qnty.Text = "";
                txtbx_total_price.Text = "";
                dtgv.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT_OUTWARD");
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (txtbx_prdct_outwrd_id.Text == "" || txtbx_prdct_qnty.Text == "" || txtbx_total_price.Text == "" || txtbx_date.Text == "")
            {
                MessageBox.Show("Please enter the blank field");
            }
            else
            {
                try
                {
                    sql_connection.table_data("UPDATE PRODUCT_OUTWARD SET PNAME = '" + cmbx_prdct_name.SelectedValue.ToString() + "',QUANTITY = '" + txtbx_prdct_qnty.Text + "',TOTAL_PRICE ='" + txtbx_total_price.Text + "',E_NAME = '" + cmbx_emp_name.SelectedValue.ToString() + "',DATEE = '" + txtbx_date.Text + "' WHERE PO_ID = '" + txtbx_prdct_outwrd_id.Text + "'");
                    dtgv.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT_OUTWARD");
                    txtbx_date.Text = "";
                    txtbx_prdct_outwrd_id.Text = "";
                    txtbx_prdct_qnty.Text = "";
                    txtbx_total_price.Text = "";
                }
                catch(NullReferenceException ex)
                {

                }
            }
        }

        private void dtgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtbx_prdct_outwrd_id.Text = sql_connection.connect("SELECT PO_ID FROM PRODUCT_OUTWARD WHERE PO_ID = '" + dtgv.CurrentCell.Value + "'").ToString();
                object p_id = sql_connection.connect("SELECT PNAME FROM PRODUCT_OUTWARD WHERE PO_ID = '" + dtgv.CurrentCell.Value + "'").ToString();
                cmbx_prdct_name.Text = sql_connection.connect("SELECT P_NAME FROM PRODUCT WHERE P_ID = '" + p_id + "'").ToString();
                txtbx_prdct_qnty.Text = sql_connection.connect("SELECT QUANTITY FROM PRODUCT_OUTWARD WHERE PO_ID = '" + dtgv.CurrentCell.Value + "'").ToString();
                txtbx_total_price.Text = sql_connection.connect("SELECT TOTAL_PRICE FROM PRODUCT_OUTWARD WHERE PO_ID = '" + dtgv.CurrentCell.Value + "'").ToString();
                object e_name = sql_connection.connect("SELECT E_NAME FROM PRODUCT_OUTWARD WHERE PO_ID = '" + dtgv.CurrentCell.Value + "'");
                cmbx_emp_name.Text = sql_connection.connect("SELECT E_NAME FROM EMPLOYEE WHERE E_ID = '" + e_name + "'").ToString();
                txtbx_date.Text = sql_connection.connect("SELECT DATEE FROM PRODUCT_OUTWARD WHERE PO_ID = '" + dtgv.CurrentCell.Value + "'").ToString();

            }
            catch(NullReferenceException ex)
            {
                MessageBox.Show("Please select the correct data");
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                sql_connection.table_data("DELETE PRODUCT_OUTWARD WHERE PO_ID = '" + txtbx_prdct_outwrd_id.Text + "'");
                dtgv.DataSource = sql_connection.table_data("SELECT * FROM PRODUCT_OUTWARD");
                txtbx_date.Text = "";
                txtbx_prdct_outwrd_id.Text = "";
                txtbx_prdct_qnty.Text = "";
                txtbx_total_price.Text = "";
            }
            catch (NullReferenceException ex)
            {
            }
        }
    }
}
