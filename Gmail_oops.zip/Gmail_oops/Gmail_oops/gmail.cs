﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Gmail_oops
{
    class gmail
    {
        public string s;
        public string s2;
        public string z;
        public string m;
        public string lognchck(string a,string b)
        {
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + a + @"\" + a + ".txt");
            tr.ReadLine();
            tr.ReadLine();
            s = tr.ReadLine();
            string[] s1 = s.Split('@');
             s2 = string.Format("{0}", s1);
            

            if (a == s2 && b == tr.ReadLine())
            {
                string k = "Success";
                m = "Inbox";
                return k;

            }
            else
            {
                string k = "Failed";
                return k;
            }
        }

        public DirectoryInfo info(string l)
        {
            DirectoryInfo di = new DirectoryInfo(@"C:\Gmail\" + s2 + @"\" + l + @"\");
            return di;
        }


        public string lognchck(string m)
        {
            return m;
        }

        public string delete(string y,string q)
        {

            File.Move(@"C:\Gmail\" + s2 + @"\" + q + @"\" + y, @"C:\Gmail\" + s2 + @"\Trash\" + y);
            return "0";
        }

        public string trash_delete(string y)
        {
            File.Delete(@"C:\Gmail\" + s2 + @"\Trash\" + y);
            return "0";
        }
    }
}
