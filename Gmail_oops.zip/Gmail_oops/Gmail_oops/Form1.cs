﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace Gmail_oops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        gmail gm = new gmail();
        Compose cmpse = new Compose();
        string btn_name;
        private void Form1_Load(object sender, EventArgs e)
        {
            tabControl1.TabPages.Remove(Register);
            tabControl1.TabPages.Remove(Mail);
            panel5.Hide();
        }       
        private void lbl_crtaccnt_Click(object sender, EventArgs e)
        {

            tabControl1.TabPages.Add(Register);
            tabControl1.SelectedTab = tabControl1.TabPages[1];
        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
             if (textBox10.Text == "" || textBox11.Text == "" || textBox11.Text == "First" || textBox10.Text == "Last")
            {
                label20.Text = "You can't leave this empty.";
            }
        }
        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                label4.Text = "You can't leave this empty.";
            }
        }
        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                label7.Text = "You can't leave this empty.";
            }
        }
        private void comboBox1_Click(object sender, EventArgs e)
        {
            if (textBox6.Text == "")
            {
                label9.Text = "You can't leave this empty.";

            }
            comboBox1.ForeColor = Color.Black;
        }
        private void comboBox2_Click(object sender, EventArgs e)
        {
            if (textBox6.Text == "")
            {
                label9.Text = "You can't leave this empty.";

            }
            comboBox2.ForeColor = Color.Black;
        }       
        private void comboBox3_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "" || comboBox1.Text == "Month" || comboBox2.Text == "" || comboBox2.Text == "Date" || textBox7.Text == "" || textBox7.Text == "Year")
            {
                label11.Text = "You can't leave this empty.";
            }
            comboBox3.ForeColor = Color.Black;
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            if (comboBox3.Text == "I am a" || comboBox3.Text == "")
            {
                label13.Text = "You can't leave this empty.";
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox11.Text == "" || textBox10.Text == "" || textBox11.Text == "First" || textBox10.Text == "Last" || textBox3.Text == "" || textBox5.Text == "" || textBox6.Text == "" || comboBox1.Text == "" || comboBox1.Text == "Month" || comboBox2.Text == "" || comboBox2.Text == "Date" || textBox7.Text == "" || textBox7.Text == "Year" || comboBox3.Text == "I am a" || comboBox3.Text == "")
            {
                MessageBox.Show("Please Fill the Blank Field", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (checkBox1.Checked == true)
                {
                    if (textBox5.Text == textBox6.Text)
                    {
                        if (Directory.Exists(@"C:\Gmail\" + textBox3.Text) == false)
                        {
                            Directory.CreateDirectory(@"C:\Gmail\" + textBox3.Text);
                            Directory.CreateDirectory(@"C:\Gmail\" + textBox3.Text + @"\Inbox");
                            Directory.CreateDirectory(@"C:\Gmail\" + textBox3.Text + @"\Sent");
                            Directory.CreateDirectory(@"C:\Gmail\" + textBox3.Text + @"\Trash");
                            Directory.CreateDirectory(@"C:\Gmail\" + textBox3.Text + @"\Contacts");
                            TextWriter tw;
                            tw = File.CreateText(@"C:\Gmail\" + textBox3.Text + @"\" + textBox3.Text + ".txt");
                            tw.WriteLine(textBox11.Text);
                            tw.WriteLine(textBox10.Text);
                            tw.WriteLine(textBox3.Text + "@gmail.com");
                            tw.WriteLine(textBox5.Text);
                            tw.WriteLine(textBox6.Text);
                            tw.WriteLine(comboBox1.Text + comboBox2.Text + textBox7.Text);
                            tw.WriteLine(comboBox3.Text);
                            tw.WriteLine(textBox8.Text + textBox9.Text);
                            tw.Dispose();
                            DialogResult dr = new DialogResult();
                            dr = MessageBox.Show("Gooogle Account has been created Successfully", "Gmail", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            if (dr == DialogResult.OK)
                            {
                                tabControl1.TabPages.Remove(Register);
                                tabControl1.SelectedTab = tabControl1.TabPages[0];
                            }

                        }
                        else
                        {
                            label5.Text = "User id is not available";
                            label5.ForeColor = Color.Green;
                        }
                    }
                    else
                    {
                        label7.Text = "Password Mismatch.";
                        label7.ForeColor = Color.Green;
                        label9.Text = "Password Mismatch.";
                        label9.ForeColor = Color.Green;
                    }

                }
                else
                {
                    MessageBox.Show("Please agree the terms and conditions", "Gmail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                label3.ForeColor = Color.Maroon;
                label3.Text = "Please enter the valid Email-id/Password";
            }
            else
            {
                if (File.Exists(@"C:\Gmail\" + textBox1.Text + @"\" + textBox1.Text + ".txt") == true)
                {
                    string j = gm.lognchck(textBox1.Text,textBox2.Text);

                    if (j == "Success")
                    {
                        tabControl1.TabPages.Add(Mail);
                        tabControl1.SelectedTab = tabControl1.TabPages[1];
                        lbl_usrname.Text = gm.s;

                    }
                    else
                    {
                        label3.Text = "Please enter the valid Email-id/Password";
                    }
                }
                else
                {
                    label3.Text = "Please enter the valid Email-id/Password";
                }
            }
        }
        private void textBox7_Click(object sender, EventArgs e)
        {
            textBox7.Text = "";
            textBox7.ForeColor = Color.Black;
        }
        private void Mail_Enter(object sender, EventArgs e)
        {
            
            if (radioButton1.Checked == true)
            {
                lbl1.Text = ""; lbl2.Text = ""; lbl3.Text = ""; lbl4.Text = ""; lbl5.Text = ""; lbl6.Text = ""; lbl7.Text = ""; lbl8.Text = ""; lbl9.Text = ""; lbl11.Text = ""; lbl12.Text = ""; lbl13.Text = ""; lbl14.Text = ""; lbl15.Text = ""; lbl16.Text = ""; lbl17.Text = ""; lbl18.Text = ""; lbl19.Text = "";
                string[] o = lbl_usrname.Text.Split('@');
                string o1 = string.Format("{0}", o);
                foreach (object o2 in gm.info(radioButton1.Text).GetFiles())
                {
                    if (lbl1.Text == "" || lbl2.Text == "" || lbl3.Text == "" || lbl4.Text == "" || lbl5.Text == "" ||
                            lbl6.Text == "" || lbl7.Text == "" || lbl8.Text == "" || lbl9.Text == "" || lbl11.Text == "" ||
                            lbl12.Text == "" || lbl13.Text == "" || lbl14.Text == "" || lbl15.Text == "" || lbl16.Text == "" ||
                            lbl17.Text == "" || lbl18.Text == "" || lbl19.Text == "")
                    {
                        if (lbl1.Text == "")
                        {
                            lbl1.Text = o2.ToString();
                        }
                        else if (lbl2.Text == "")
                        {
                            lbl2.Text = o2.ToString();
                        }
                        else if (lbl3.Text == "")
                        {
                            lbl3.Text = o2.ToString();
                        }
                        else if (lbl4.Text == "")
                        {
                            lbl4.Text = o2.ToString();
                        }
                        else if (lbl5.Text == "")
                        {
                            lbl5.Text = o2.ToString();
                        }
                        else if (lbl6.Text == "")
                        {
                            lbl6.Text = o2.ToString();
                        }
                        else if (lbl7.Text == "")
                        {
                            lbl7.Text = o2.ToString();
                        }
                        else if (lbl8.Text == "")
                        {
                            lbl8.Text = o2.ToString();
                        }
                        else if (lbl9.Text == "")
                        {
                            lbl9.Text = o2.ToString();
                        }
                        else if (lbl11.Text == "")
                        {
                            lbl11.Text = o2.ToString();
                        }
                        else if (lbl12.Text == "")
                        {
                            lbl12.Text = o2.ToString();
                        }
                        else if (lbl13.Text == "")
                        {
                            lbl13.Text = o2.ToString();
                        }
                        else if (lbl14.Text == "")
                        {
                            lbl14.Text = o2.ToString();
                        }
                        else if (lbl15.Text == "")
                        {
                            lbl15.Text = o2.ToString();
                        }
                        else if (lbl16.Text == "")
                        {
                            lbl16.Text = o2.ToString();
                        }
                        else if (lbl17.Text == "")
                        {
                            lbl17.Text = o2.ToString();
                        }
                        else if (lbl18.Text == "")
                        {
                            lbl18.Text = o2.ToString();
                        }
                        else
                        {
                            lbl19.Text = o2.ToString();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Memory Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }       
        private void listfiles(object sender, EventArgs e)
        {
            RadioButton rd = (RadioButton)sender;
            string z = gm.lognchck(rd.Text);
            if (rd.Checked == true)
            {
                lbl1.Text = ""; lbl2.Text = ""; lbl3.Text = ""; lbl4.Text = ""; lbl5.Text = ""; lbl6.Text = ""; lbl7.Text = ""; lbl8.Text = ""; lbl9.Text = ""; lbl11.Text = ""; lbl12.Text = ""; lbl13.Text = ""; lbl14.Text = ""; lbl15.Text = ""; lbl16.Text = ""; lbl17.Text = ""; lbl18.Text = ""; lbl19.Text = "";
                string[] o = lbl_usrname.Text.Split('@');
                string o1 = string.Format("{0}", o);
                foreach (object o2 in gm.info(rd.Text).GetFiles())
                {
                    if (lbl1.Text == "" || lbl2.Text == "" || lbl3.Text == "" || lbl4.Text == "" || lbl5.Text == "" ||
                            lbl6.Text == "" || lbl7.Text == "" || lbl8.Text == "" || lbl9.Text == "" || lbl11.Text == "" ||
                            lbl12.Text == "" || lbl13.Text == "" || lbl14.Text == "" || lbl15.Text == "" || lbl16.Text == "" ||
                            lbl17.Text == "" || lbl18.Text == "" || lbl19.Text == "")
                    {
                        if (lbl1.Text == "")
                        {
                            lbl1.Text = o2.ToString();
                        }
                        else if (lbl2.Text == "")
                        {
                            lbl2.Text = o2.ToString();
                        }
                        else if (lbl3.Text == "")
                        {
                            lbl3.Text = o2.ToString();
                        }
                        else if (lbl4.Text == "")
                        {
                            lbl4.Text = o2.ToString();
                        }
                        else if (lbl5.Text == "")
                        {
                            lbl5.Text = o2.ToString();
                        }
                        else if (lbl6.Text == "")
                        {
                            lbl6.Text = o2.ToString();
                        }
                        else if (lbl7.Text == "")
                        {
                            lbl7.Text = o2.ToString();
                        }
                        else if (lbl8.Text == "")
                        {
                            lbl8.Text = o2.ToString();
                        }
                        else if (lbl9.Text == "")
                        {
                            lbl9.Text = o2.ToString();
                        }
                        else if (lbl11.Text == "")
                        {
                            lbl11.Text = o2.ToString();
                        }
                        else if (lbl12.Text == "")
                        {
                            lbl12.Text = o2.ToString();
                        }
                        else if (lbl13.Text == "")
                        {
                            lbl13.Text = o2.ToString();
                        }
                        else if (lbl14.Text == "")
                        {
                            lbl14.Text = o2.ToString();
                        }
                        else if (lbl15.Text == "")
                        {
                            lbl15.Text = o2.ToString();
                        }
                        else if (lbl16.Text == "")
                        {
                            lbl16.Text = o2.ToString();
                        }
                        else if (lbl17.Text == "")
                        {
                            lbl17.Text = o2.ToString();
                        }
                        else if (lbl18.Text == "")
                        {
                            lbl18.Text = o2.ToString();
                        }
                        else
                        {
                            lbl19.Text = o2.ToString();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Memory Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        private void btn_Compose_Click(object sender, EventArgs e)
        {
            panel5.Show();
            AutoCompleteStringCollection cmpsemail = new AutoCompleteStringCollection();
            foreach (object o3 in cmpse.info("a").GetDirectories())
            {
                cmpsemail.Add(o3.ToString() + "@gmail.com");
                textBox12.AutoCompleteMode = AutoCompleteMode.Suggest;
                textBox12.AutoCompleteSource = AutoCompleteSource.CustomSource;
                textBox12.AutoCompleteCustomSource = cmpsemail;
            }
       }
        private void btn_send_Click(object sender, EventArgs e)
        {
            if (textBox12.Text == "" || textBox15.Text == "")
            {
                MessageBox.Show("Please fill the Receipient/Subject", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string[] s = textBox12.Text.Split('@');
                string s1 = string.Format("{0}", s);
                string[] m = lbl_usrname.Text.Split('@');
                string m1 = string.Format("{0}", m);

                cmpse.sent(s1, m1, textBox15.Text, richTextBox1.Text);

                DialogResult dr = new DialogResult();
                dr = MessageBox.Show("Message Sent Successfully", "Gmail", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (dr == DialogResult.OK)
                {
                    panel5.Hide();
                }
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            RadioButton rd = (RadioButton)sender;                         
            }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
               btn_name = gm.lognchck("Inbox");
            }
            else if (radioButton2.Checked == true)
            {
             btn_name = gm.lognchck("Sent");
            }
            else
            {
               btn_name = gm.lognchck("Trash");
            }

            if (checkBox3.Checked == true || checkBox4.Checked == true || checkBox5.Checked == true || checkBox6.Checked == true || checkBox7.Checked == true || checkBox8.Checked == true || checkBox9.Checked == true || checkBox10.Checked == true || checkBox11.Checked == true || checkBox12.Checked == true || checkBox13.Checked == true || checkBox14.Checked == true ||
                   checkBox15.Checked == true || checkBox16.Checked == true || checkBox17.Checked == true || checkBox18.Checked == true || checkBox19.Checked == true || checkBox20.Checked == true || checkBox21.Checked == true)
            {
                if (checkBox3.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl1.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl1.Text;
                        gm.trash_delete(y: a);
                    }

                }
                if (checkBox4.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl2.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl2.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox5.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl3.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl3.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox6.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl4.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl4.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox7.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl5.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl5.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox8.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl6.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl6.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox9.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl7.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl7.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox10.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl8.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl8.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox11.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl9.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl9.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox12.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl10.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl10.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox13.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl11.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl11.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox14.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl12.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl12.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox15.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl13.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl13.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox16.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl14.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl14.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox17.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl15.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl15.Text;
                        gm.trash_delete(y: a);
                    }

                }
                if (checkBox18.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl16.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl16.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox19.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl17.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl17.Text;
                        gm.trash_delete(y: a);
                    }

                }
                if (checkBox20.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl18.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl18.Text;
                        gm.trash_delete(y: a);
                    }
                }
                if (checkBox21.Checked == true)
                {
                    if (btn_name == "Inbox" || btn_name == "Sent")
                    {
                        string a = lbl19.Text;
                        gm.delete(y: a, q: btn_name);
                    }
                    else
                    {
                        string a = lbl19.Text;
                        gm.trash_delete(y: a);
                    }
                }
            } 
        }

        private void button7_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Remove(Register);
            tabControl1.TabPages.Remove(Mail);
            tabControl1.SelectedTab = tabControl1.TabPages[0];
            textBox2.Text = "";
         }
      }     
}
