﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Gmail_oops
{
    class Compose:gmail
    {
        public Compose()
        {
        }
        public DirectoryInfo info(string m)
        {
            DirectoryInfo di1 = new DirectoryInfo(@"C:\Gmail\");
            return di1;           
        }

        public string sent(string n,string o,string p,string q)
        {
            if (Directory.Exists(@"C:\Gmail\" + n) == true)
            {
                TextWriter tw;
                tw = File.CreateText(@"C:\Gmail\" + n + @"\Inbox\" + p + ".txt");
                tw.WriteLine(q);
                tw.Flush();
                tw.Dispose();
                tw.Close();

                TextWriter tw1;
                tw1 = File.CreateText(@"C:\Gmail\" + o + @"\Sent\" + p + ".txt");
                tw1.WriteLine(q);
                tw1.Flush();
                tw1.Dispose();
                tw1.Close();
            }
           

            return "0";
        }



    }
}
