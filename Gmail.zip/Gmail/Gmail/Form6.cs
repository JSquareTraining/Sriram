﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Gmail
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);

            if (chckbx1.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl1.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl1.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl1.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl1.Text);
                }
            }
            if (chckbx2.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl2.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl2.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl2.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl2.Text);
                }
            }
            if (chckbx3.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl3.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl3.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl3.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl3.Text);
                }
            }
            if (chckbx4.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl4.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl4.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl4.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl4.Text);
                }
            }
            if (chckbx5.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl5.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl5.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl5.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl5.Text);
                }
            }
            if (chckbx6.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl6.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl6.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl6.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl6.Text);
                }
            }
            if (chckbx7.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl7.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl7.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl7.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl7.Text);
                }
            }
            if (chckbx8.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl8.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl8.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl8.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl8.Text);
                }
            }
            if (chckbx9.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl9.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl9.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl9.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl9.Text);
                }
            }
            if (chckbx10.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl10.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl10.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl10.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl10.Text);
                }
            }
            if (chckbx11.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl11.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl11.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl11.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl11.Text);
                }
            }
            if (chckbx12.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl12.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl12.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl12.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl12.Text);
                }
            }
            if (chckbx13.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl13.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl13.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl13.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl13.Text);
                }
            }
            if (chckbx14.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl14.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl14.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl14.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl14.Text);
                }
            }
            if (chckbx15.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl15.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl15.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl15.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl15.Text);
                }
            }
            if (chckbx16.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl16.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl16.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl16.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl16.Text);
                }
            }
            if (chckbx17.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl17.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl17.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl17.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl17.Text);
                }
            }
            if (chckbx18.Checked == true)
            {
                if (File.Exists(@"C:\Gmail\" + s1 + @"\Trash\" + lbl18.Text) == true)
                {
                    File.Delete(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl18.Text);
                }
                else
                {
                    File.Move(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl18.Text, @"C:\Gmail\" + s1 + @"\Trash\" + lbl18.Text);
                }
            }

            
        }

        private void lbl1_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl1.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl2_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl2.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl3_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl3.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl4_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl4.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl5_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl5.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl6_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl6.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl7_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl7.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl8_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl8.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl9_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl9.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl10_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl10.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl11_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl11.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl12_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl12.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl13_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl13.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();

        }

        private void lbl14_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl14.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl15_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl15.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl16_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl16.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl17_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl17.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void lbl18_Click(object sender, EventArgs e)
        {
            string[] s = label1.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"C:\Gmail\" + s1 + @"\Sent Items\" + lbl18.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }
        }
    
}
