﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Gmail
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            pictureBox2.Parent = pictureBox1;
            pictureBox2.BackColor = Color.Transparent;
            textBox1.Text = "First";
            textBox2.Text = "Last";
            textBox1.ForeColor = Color.Gray;
            textBox2.ForeColor = Color.Gray;
            textBox4.Text = "@gmail.co.in";
            textBox4.ForeColor = Color.Gray;
            comboBox1.Text = "Month";
            comboBox2.Text = "Date";
            textBox7.Text = "Year";
            comboBox1.ForeColor = Color.Gray;
            comboBox2.ForeColor = Color.Gray;
            textBox7.ForeColor = Color.Gray;
            comboBox3.Text = "I am a";
            comboBox3.ForeColor = Color.Gray;
            textBox8.Text = "+91";
            textBox8.ForeColor = Color.Gray;
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox1.Text == "First" || textBox2.Text == "Last")
            {
                label3.Text = "You can't leave this empty.";
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                label5.Text = "You can't leave this empty.";
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                label7.Text = "You can't leave this empty.";
            }
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            if (textBox6.Text == "")
            {
                label9.Text = "You can't leave this empty.";
                
            }
            comboBox1.ForeColor = Color.Black;
        }

        private void comboBox2_Click(object sender, EventArgs e)
        {
            if (textBox6.Text == "")
            {
                label9.Text = "You can't leave this empty.";
                
            }
            comboBox2.ForeColor = Color.Black;
        }

        private void textBox7_Click(object sender, EventArgs e)
        {
            textBox7.Text = "";
            textBox7.ForeColor = Color.Black;
        }

        private void comboBox3_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "" || comboBox1.Text == "Month" || comboBox2.Text == "" || comboBox2.Text == "Date" || textBox7.Text == "" || textBox7.Text == "Year")
            {
                label11.Text = "You can't leave this empty.";
            }
            comboBox3.ForeColor = Color.Black;
        }

        private void textBox9_Click(object sender, EventArgs e)
        {
            if (comboBox3.Text == "I am a" || comboBox3.Text == "")
            {
                label13.Text = "You can't leave this empty.";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox1.Text == "First" || textBox2.Text == "Last" || textBox3.Text == "" || textBox5.Text == "" || textBox6.Text == "" || comboBox1.Text == "" || comboBox1.Text == "Month" || comboBox2.Text == "" || comboBox2.Text == "Date" || textBox7.Text == "" || textBox7.Text == "Year" || comboBox3.Text == "I am a" || comboBox3.Text == "")
            {
                MessageBox.Show("Please Fill the Blank Field", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (checkBox1.Checked == true)
                {
                    if (textBox5.Text == textBox6.Text)
                    {
                        if (Directory.Exists(@"C:\Gmail\" + textBox3.Text) == false)
                        {
                            Directory.CreateDirectory(@"C:\Gmail\" + textBox3.Text);
                            Directory.CreateDirectory(@"C:\Gmail\" + textBox3.Text + @"\Inbox");
                            Directory.CreateDirectory(@"C:\Gmail\" + textBox3.Text + @"\Sent Items");
                            Directory.CreateDirectory(@"C:\Gmail\" + textBox3.Text + @"\Trash");
                            Directory.CreateDirectory(@"C:\Gmail\" + textBox3.Text + @"\Contacts");
                            TextWriter tw;
                            tw = File.CreateText(@"C:\Gmail\" + textBox3.Text + @"\" + textBox3.Text + ".txt");
                            tw.WriteLine(textBox1.Text);
                            tw.WriteLine(textBox2.Text);
                            tw.WriteLine(textBox3.Text + "@gmail.com");
                            tw.WriteLine(textBox5.Text);
                            tw.WriteLine(textBox6.Text);
                            tw.WriteLine(comboBox1.Text + comboBox2.Text + textBox7.Text);
                            tw.WriteLine(comboBox3.Text);
                            tw.WriteLine(textBox8.Text + textBox9.Text);
                            tw.Dispose();
                            DialogResult dr = new DialogResult();
                            dr = MessageBox.Show("Gooogle Account has been created Successfully", "Gmail", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            if (dr == DialogResult.OK)
                            {
                                this.Hide();
                                Form1 frm1 = new Form1();
                                frm1.Show();
                            }

                        }
                        else
                        {
                            label5.Text = "User id is not available";
                            label5.ForeColor = Color.Green;
                        }
                    }
                    else
                    {
                        label7.Text = "Password Mismatch.";
                        label7.ForeColor = Color.Green;
                        label9.Text = "Password Mismatch.";
                        label9.ForeColor = Color.Green;
                    }

                }
                else
                {
                    MessageBox.Show("Please agree the terms and conditions", "Gmail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.ForeColor = Color.Black;
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            textBox2.ForeColor = Color.Black;
        }
    }
}
