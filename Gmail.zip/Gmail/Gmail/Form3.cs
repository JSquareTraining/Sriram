﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Gmail
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        string a;
        string a1;
        string a2;
        string a3;
        string a4;
        string a5;
        string a6;
        string a7;
        string a8;
        string a9;
        string a10;
        string a11;
        string a12;
        string a13;
        string a14;
        string a15;
        string a16;
        string a17;
        string a18;

        Form4 frm4 = new Form4();
        private void Form3_Load(object sender, EventArgs e)
        {
            

        }

        public void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

            Form4 frm4 = new Form4();
            frm4.label1.Text = label1.Text;
                if (radioButton1.Checked == true)
                {
                    frm4.MdiParent = this;
                    string[] s = label1.Text.Split('@');
                    string s1 = string.Format("{0}", s);
                    DirectoryInfo di = new DirectoryInfo(@"C:\Gmail\" + s1 + @"\Inbox\");
                    foreach (object o in di.GetFiles())
                    {
                        if (frm4.lbl1.Text == "" || frm4.lbl2.Text == "" || frm4.lbl3.Text == "" || frm4.lbl4.Text == "" || frm4.lbl5.Text == "" ||
                            frm4.lbl6.Text == "" || frm4.lbl7.Text == "" || frm4.lbl8.Text == "" || frm4.lbl9.Text == "" || frm4.lbl10.Text == "" ||
                            frm4.lbl11.Text == "" || frm4.lbl12.Text == "" || frm4.lbl13.Text == "" || frm4.lbl14.Text == "" || frm4.lbl15.Text == "" ||
                            frm4.lbl16.Text == "" || frm4.lbl17.Text == "" || frm4.lbl18.Text == "")
                        {
                            if (frm4.lbl1.Text == "")
                            {
                                frm4.lbl1.Text = o.ToString();
                                a = frm4.lbl1.Text;

                            }
                            else if (frm4.lbl2.Text == "")
                            {
                                frm4.lbl2.Text = o.ToString();
                                a1 = frm4.lbl2.Text;
                            }
                            else if (frm4.lbl3.Text == "")
                            {
                                frm4.lbl3.Text = o.ToString();
                                a2 = frm4.lbl3.Text;
                            }
                            else if (frm4.lbl4.Text == "")
                            {
                                frm4.lbl4.Text = o.ToString();
                                a3 = frm4.lbl4.Text;
                            }
                            else if (frm4.lbl5.Text == "")
                            {
                                frm4.lbl5.Text = o.ToString();
                                a4 = frm4.lbl5.Text;
                            }
                            else if (frm4.lbl6.Text == "")
                            {
                                frm4.lbl6.Text = o.ToString();
                                a5 = frm4.lbl6.Text;
                            }
                            else if (frm4.lbl7.Text == "")
                            {
                                frm4.lbl7.Text = o.ToString();
                                a6 = frm4.lbl7.Text;
                            }
                            else if (frm4.lbl8.Text == "")
                            {
                                frm4.lbl8.Text = o.ToString();
                                a7 = frm4.lbl8.Text;
                            }
                            else if (frm4.lbl9.Text == "")
                            {
                                frm4.lbl9.Text = o.ToString();
                                a8 = frm4.lbl9.Text;
                            }
                            else if (frm4.lbl10.Text == "")
                            {
                                frm4.lbl10.Text = o.ToString();
                                a9 = frm4.lbl10.Text;
                            }
                            else if (frm4.lbl11.Text == "")
                            {
                                frm4.lbl11.Text = o.ToString();
                                a10 = frm4.lbl11.Text;
                            }
                            else if (frm4.lbl12.Text == "")
                            {
                                frm4.lbl12.Text = o.ToString();
                                a11 = frm4.lbl12.Text;
                            }
                            else if (frm4.lbl13.Text == "")
                            {
                                frm4.lbl13.Text = o.ToString();
                                a12 = frm4.lbl13.Text;
                            }
                            else if (frm4.lbl14.Text == "")
                            {
                                frm4.lbl14.Text = o.ToString();
                                a13 = frm4.lbl14.Text;
                            }
                            else if (frm4.lbl15.Text == "")
                            {
                                frm4.lbl15.Text = o.ToString();
                                a14 = frm4.lbl15.Text;
                            }
                            else if (frm4.lbl16.Text == "")
                            {
                                frm4.lbl16.Text = o.ToString();
                                a15 = frm4.lbl16.Text;
                            }
                            else if (frm4.lbl17.Text == "")
                            {
                                frm4.lbl17.Text = o.ToString();
                                a16 = frm4.lbl17.Text;
                            }
                            else
                            {
                                frm4.lbl18.Text = o.ToString();
                                a17 = frm4.lbl18.Text;
                            }


                        }
                        else
                        {
                            MessageBox.Show("Memory Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                    frm4.Show();
                }
                else
                {
                    if (radioButton2.Checked == true)
                    {
                        Form6 frm6 = new Form6();
                        frm6.label1.Text = label1.Text;
                        if (radioButton1.Checked == true)
                        {
                            frm6.MdiParent = this;
                            string[] s = label1.Text.Split('@');
                            string s1 = string.Format("{0}", s);
                            DirectoryInfo di = new DirectoryInfo(@"C:\Gmail\" + s1 + @"\Sent Items\");
                            foreach (object o in di.GetFiles())
                            {
                                if (frm6.lbl1.Text == "" || frm6.lbl2.Text == "" || frm6.lbl3.Text == "" || frm6.lbl4.Text == "" || frm6.lbl5.Text == "" ||
                                    frm6.lbl6.Text == "" || frm6.lbl7.Text == "" || frm6.lbl8.Text == "" || frm6.lbl9.Text == "" || frm6.lbl10.Text == "" ||
                                    frm6.lbl11.Text == "" || frm6.lbl12.Text == "" || frm6.lbl13.Text == "" || frm6.lbl14.Text == "" || frm6.lbl15.Text == "" ||
                                    frm6.lbl16.Text == "" || frm6.lbl17.Text == "" || frm6.lbl18.Text == "")
                                {
                                    if (frm6.lbl1.Text == "")
                                    {
                                        frm6.lbl1.Text = o.ToString();
                                    }
                                    else if (frm6.lbl2.Text == "")
                                    {
                                        frm6.lbl2.Text = o.ToString();
                                    }
                                    else if (frm6.lbl3.Text == "")
                                    {
                                        frm6.lbl3.Text = o.ToString();
                                    }
                                    else if (frm6.lbl4.Text == "")
                                    {
                                        frm6.lbl4.Text = o.ToString();
                                    }
                                    else if (frm6.lbl5.Text == "")
                                    {
                                        frm6.lbl5.Text = o.ToString();
                                    }
                                    else if (frm6.lbl6.Text == "")
                                    {
                                        frm6.lbl6.Text = o.ToString();
                                    }
                                    else if (frm6.lbl7.Text == "")
                                    {
                                        frm6.lbl7.Text = o.ToString();
                                    }
                                    else if (frm6.lbl8.Text == "")
                                    {
                                        frm6.lbl8.Text = o.ToString();
                                    }
                                    else if (frm6.lbl9.Text == "")
                                    {
                                        frm6.lbl9.Text = o.ToString();
                                    }
                                    else if (frm6.lbl10.Text == "")
                                    {
                                        frm6.lbl10.Text = o.ToString();
                                    }
                                    else if (frm6.lbl11.Text == "")
                                    {
                                        frm6.lbl11.Text = o.ToString();
                                    }
                                    else if (frm6.lbl12.Text == "")
                                    {
                                        frm6.lbl12.Text = o.ToString();
                                    }
                                    else if (frm6.lbl13.Text == "")
                                    {
                                        frm6.lbl13.Text = o.ToString();
                                    }
                                    else if (frm6.lbl14.Text == "")
                                    {
                                        frm6.lbl14.Text = o.ToString();
                                    }
                                    else if (frm6.lbl15.Text == "")
                                    {
                                        frm6.lbl15.Text = o.ToString();
                                    }
                                    else if (frm6.lbl16.Text == "")
                                    {
                                        frm6.lbl16.Text = o.ToString();
                                    }
                                    else if (frm6.lbl17.Text == "")
                                    {
                                        frm6.lbl17.Text = o.ToString();
                                    }
                                    else
                                    {
                                        frm6.lbl18.Text = o.ToString();
                                    }


                                }
                                else
                                {
                                    MessageBox.Show("Memory Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }

                            frm6.Show();
                        }
                    }
                }

                 
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Form5 frm5 = new Form5();
            frm5.MdiParent = this;
            frm5.label5.Text = label1.Text;
            DirectoryInfo di3 = new DirectoryInfo(@"C:\Gmail\");
            int i = di3.GetDirectories().Count();
            AutoCompleteStringCollection ogsc = new AutoCompleteStringCollection();
                foreach (object o1 in di3.GetDirectories())
                {
                ogsc.Add(o1.ToString() + "@gmail.com");
                frm5.textBox1.AutoCompleteSource = AutoCompleteSource.CustomSource;
                frm5.textBox1.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                frm5.textBox1.AutoCompleteCustomSource = ogsc;
                }
            

            frm5.Show();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            
            if (radioButton2.Checked == true)
            {
                Form6 frm6 = new Form6();
                frm6.label1.Text = label1.Text;
                if (radioButton2.Checked == true)
                {
                    frm6.MdiParent = this;
                    string[] s = label1.Text.Split('@');
                    string s1 = string.Format("{0}", s);
                    DirectoryInfo di = new DirectoryInfo(@"C:\Gmail\" + s1 + @"\Sent Items\");
                    foreach (object o in di.GetFiles())
                    {
                        if (frm6.lbl1.Text == "" || frm6.lbl2.Text == "" || frm6.lbl3.Text == "" || frm6.lbl4.Text == "" || frm6.lbl5.Text == "" ||
                            frm6.lbl6.Text == "" || frm6.lbl7.Text == "" || frm6.lbl8.Text == "" || frm6.lbl9.Text == "" || frm6.lbl10.Text == "" ||
                            frm6.lbl11.Text == "" || frm6.lbl12.Text == "" || frm6.lbl13.Text == "" || frm6.lbl14.Text == "" || frm6.lbl15.Text == "" ||
                            frm6.lbl16.Text == "" || frm6.lbl17.Text == "" || frm6.lbl18.Text == "")
                        {
                            if (frm6.lbl1.Text == "")
                            {
                                frm6.lbl1.Text = o.ToString();
                            }
                            else if (frm6.lbl2.Text == "")
                            {
                                frm6.lbl2.Text = o.ToString();
                            }
                            else if (frm6.lbl3.Text == "")
                            {
                                frm6.lbl3.Text = o.ToString();
                            }
                            else if (frm6.lbl4.Text == "")
                            {
                                frm6.lbl4.Text = o.ToString();
                            }
                            else if (frm6.lbl5.Text == "")
                            {
                                frm6.lbl5.Text = o.ToString();
                            }
                            else if (frm6.lbl6.Text == "")
                            {
                                frm6.lbl6.Text = o.ToString();
                            }
                            else if (frm6.lbl7.Text == "")
                            {
                                frm6.lbl7.Text = o.ToString();
                            }
                            else if (frm6.lbl8.Text == "")
                            {
                                frm6.lbl8.Text = o.ToString();
                            }
                            else if (frm6.lbl9.Text == "")
                            {
                                frm6.lbl9.Text = o.ToString();
                            }
                            else if (frm6.lbl10.Text == "")
                            {
                                frm6.lbl10.Text = o.ToString();
                            }
                            else if (frm6.lbl11.Text == "")
                            {
                                frm6.lbl11.Text = o.ToString();
                            }
                            else if (frm6.lbl12.Text == "")
                            {
                                frm6.lbl12.Text = o.ToString();
                            }
                            else if (frm6.lbl13.Text == "")
                            {
                                frm6.lbl13.Text = o.ToString();
                            }
                            else if (frm6.lbl14.Text == "")
                            {
                                frm6.lbl14.Text = o.ToString();
                            }
                            else if (frm6.lbl15.Text == "")
                            {
                                frm6.lbl15.Text = o.ToString();
                            }
                            else if (frm6.lbl16.Text == "")
                            {
                                frm6.lbl16.Text = o.ToString();
                            }
                            else if (frm6.lbl17.Text == "")
                            {
                                frm6.lbl17.Text = o.ToString();
                            }
                            else
                            {
                                frm6.lbl18.Text = o.ToString();
                            }


                        }
                        else
                        {
                            MessageBox.Show("Memory Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    
                    frm6.Show();
                }
                
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked == true)
            {
                Form7 frm7 = new Form7();
                frm7.label1.Text = label1.Text;
                if (radioButton3.Checked == true)
                {
                    frm7.MdiParent = this;
                    string[] s = label1.Text.Split('@');
                    string s1 = string.Format("{0}", s);
                    DirectoryInfo di = new DirectoryInfo(@"C:\Gmail\" + s1 + @"\Trash\");
                    foreach (object o in di.GetFiles())
                    {
                        if (frm7.lbl1.Text == "" || frm7.lbl2.Text == "" || frm7.lbl3.Text == "" || frm7.lbl4.Text == "" || frm7.lbl5.Text == "" ||
                            frm7.lbl6.Text == "" || frm7.lbl7.Text == "" || frm7.lbl8.Text == "" || frm7.lbl9.Text == "" || frm7.lbl10.Text == "" ||
                            frm7.lbl11.Text == "" || frm7.lbl12.Text == "" || frm7.lbl13.Text == "" || frm7.lbl14.Text == "" || frm7.lbl15.Text == "" ||
                            frm7.lbl16.Text == "" || frm7.lbl17.Text == "" || frm7.lbl18.Text == "")
                        {
                            if (frm7.lbl1.Text == "")
                            {
                                frm7.lbl1.Text = o.ToString();
                            }
                            else if (frm7.lbl2.Text == "")
                            {
                                frm7.lbl2.Text = o.ToString();
                            }
                            else if (frm7.lbl3.Text == "")
                            {
                                frm7.lbl3.Text = o.ToString();
                            }
                            else if (frm7.lbl4.Text == "")
                            {
                                frm7.lbl4.Text = o.ToString();
                            }
                            else if (frm7.lbl5.Text == "")
                            {
                                frm7.lbl5.Text = o.ToString();
                            }
                            else if (frm7.lbl6.Text == "")
                            {
                                frm7.lbl6.Text = o.ToString();
                            }
                            else if (frm7.lbl7.Text == "")
                            {
                                frm7.lbl7.Text = o.ToString();
                            }
                            else if (frm7.lbl8.Text == "")
                            {
                                frm7.lbl8.Text = o.ToString();
                            }
                            else if (frm7.lbl9.Text == "")
                            {
                                frm7.lbl9.Text = o.ToString();
                            }
                            else if (frm7.lbl10.Text == "")
                            {
                                frm7.lbl10.Text = o.ToString();
                            }
                            else if (frm7.lbl11.Text == "")
                            {
                                frm7.lbl11.Text = o.ToString();
                            }
                            else if (frm7.lbl12.Text == "")
                            {
                                frm7.lbl12.Text = o.ToString();
                            }
                            else if (frm7.lbl13.Text == "")
                            {
                                frm7.lbl13.Text = o.ToString();
                            }
                            else if (frm7.lbl14.Text == "")
                            {
                                frm7.lbl14.Text = o.ToString();
                            }
                            else if (frm7.lbl15.Text == "")
                            {
                                frm7.lbl15.Text = o.ToString();
                            }
                            else if (frm7.lbl16.Text == "")
                            {
                                frm7.lbl16.Text = o.ToString();
                            }
                            else if (frm7.lbl17.Text == "")
                            {
                                frm7.lbl17.Text = o.ToString();
                            }
                            else
                            {
                                frm7.lbl18.Text = o.ToString();
                            }


                        }
                        else
                        {
                            MessageBox.Show("Memory Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                    frm7.Show();
                }

            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Form9 frm9 = new Form9();
            frm9.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Close();
        }
        
       
    }
}
