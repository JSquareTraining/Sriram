﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TreeStructureProject
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }
        Properties.Settings st = new Properties.Settings();
        private void btn_Rgstr_Click(object sender, EventArgs e)
        {
            if (txtbx_CustmrId.Text == "0")
            {
                if (st.Name == "")
                {

                    st.Name = txtbx_nme.Text;
                
                    listbx_Registered.Items.Add(txtbx_CustmrId.Text);

                }
                else
                {
                    MessageBox.Show("Customer Id Not Available", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
            else if (txtbx_CustmrId.Text == "1")
            {
                if (cmbobx_refid.Text == "0")
                {
                    if (st.Name1 == "" || st.Name2 == "" || st.Name3 == "")
                    {
                        if (st.Name1 == "")
                        {
                            st.Name1 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name2 == "")
                        {
                            st.Name2 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name3 == "")
                        {
                            st.Name3 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Select the Reference Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (txtbx_CustmrId.Text == "2")
            {
                if (cmbobx_refid.Text == "0")
                {
                    if (st.Name1 == "" || st.Name2 == "" || st.Name3 == "")
                    {
                        if (st.Name1 == "")
                        {
                            st.Name1 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name2 == "")
                        {
                            st.Name2 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name3 == "")
                        {
                            st.Name3 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "1")
                {
                    if (st.Name4 == "" || st.Name5 == "" || st.Name6 == "")
                    {
                        if (st.Name4 == "")
                        {
                            st.Name4 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name5 == "")
                        {
                            st.Name5 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId);
                        }
                        else if (st.Name6 == "")
                        {
                            st.Name6 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    
                }
            }
            else if (txtbx_CustmrId.Text == "3")
            {
                if (cmbobx_refid.Text == "0")
                {
                    if (st.Name1 == "" || st.Name2 == "" || st.Name3 == "")
                    {
                        if (st.Name1 == "")
                        {
                            st.Name1 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name2 == "")
                        {
                            st.Name2 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name3 == "")
                        {
                            st.Name3 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "1")
                {
                    if (st.Name4 == "" || st.Name5 == "" || st.Name6 == "")
                    {
                        if (st.Name4 == "")
                        {
                            st.Name4 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name5 == "")
                        {
                            st.Name5 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name6 == "")
                        {
                            st.Name6 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "2")
                {
                    if (st.Name7 == "" || st.Name8 == "" || st.Name9 == "")
                    {
                        if (st.Name7 == "")
                        {
                            st.Name7 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name8 == "")
                        {
                            st.Name8 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name9 == "")
                        {
                            st.Name9 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please Select the Reference Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (txtbx_CustmrId.Text == "4")
            {
                if (cmbobx_refid.Text == "0")
                {
                    if (st.Name1 == "" || st.Name2 == "" || st.Name3 == "")
                    {
                        if (st.Name1 == "")
                        {
                            st.Name1 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name2 == "")
                        {
                            st.Name2 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name3 == "")
                        {
                            st.Name3 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "1")
                {
                    if (st.Name4 == "" || st.Name5 == "" || st.Name6 == "")
                    {
                        if (st.Name4 == "")
                        {
                            st.Name4 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name5 == "")
                        {
                            st.Name5 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name6 == "")
                        {
                            st.Name6 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "2")
                {
                    if (st.Name7 == "" || st.Name8 == "" || st.Name9 == "")
                    {
                        if (st.Name7 == "")
                        {
                            st.Name7 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name8 == "")
                        {
                            st.Name8 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name9 == "")
                        {
                            st.Name9 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "3")
                {
                    if (st.Name10 == "" || st.Name11 == "" || st.Name12 == "")
                    {
                        if (st.Name10 == "")
                        {
                            st.Name10 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name11 == "")
                        {
                            st.Name11 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name12 == "")
                        {
                            st.Name12 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please Select the Reference Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else if (txtbx_CustmrId.Text == "5")
            {
                if (cmbobx_refid.Text == "0")
                {
                    if (st.Name1 == "" || st.Name2 == "" || st.Name3 == "")
                    {
                        if (st.Name1 == "")
                        {
                            st.Name1 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name2 == "")
                        {
                            st.Name2 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name3 == "")
                        {
                            st.Name3 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "1")
                {

                    if (st.Name4 == "" || st.Name5 == "" || st.Name6 == "")
                    {
                        if (st.Name4 == "")
                        {
                            st.Name4 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name5 == "")
                        {
                            st.Name5 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name6 == "")
                        {
                            st.Name6 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "2")
                {
                    if (st.Name7 == "" || st.Name8 == "" || st.Name9 == "")
                    {
                        if (st.Name7 == "")
                        {
                            st.Name7 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name8 == "")
                        {
                            st.Name8 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name9 == "")
                        {
                            st.Name9 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "3")
                {
                    if (st.Name10 == "" || st.Name11 == "" || st.Name12 == "")
                    {
                        if (st.Name10 == "")
                        {
                            st.Name10 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name11 == "")
                        {
                            st.Name11 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name12 == "")
                        {
                            st.Name12 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "4")
                {
                    if (st.Name13 == "" || st.Name14 == "" || st.Name15 == "")
                    {
                        if (st.Name13 == "")
                        {
                            st.Name13 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name14 == "")
                        {
                            st.Name14 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name15 == "")
                        {
                            st.Name15 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please Select the Reference Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else if (txtbx_CustmrId.Text == "6")
            {
                if (cmbobx_refid.Text == "0")
                {
                    if (st.Name1 == "" || st.Name2 == "" || st.Name3 == "")
                    {
                        if (st.Name1 == "")
                        {
                            st.Name1 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name2 == "")
                        {
                            st.Name2 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name3 == "")
                        {
                            st.Name3 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "1")
                {

                    if (st.Name4 == "" || st.Name5 == "" || st.Name6 == "")
                    {
                        if (st.Name4 == "")
                        {
                            st.Name4 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name5 == "")
                        {
                            st.Name5 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name6 == "")
                        {
                            st.Name6 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "2")
                {
                    if (st.Name7 == "" || st.Name8 == "" || st.Name9 == "")
                    {
                        if (st.Name7 == "")
                        {
                            st.Name7 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name8 == "")
                        {
                            st.Name8 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name9 == "")
                        {
                            st.Name9 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "3")
                {
                    if (st.Name10 == "" || st.Name11 == "" || st.Name12 == "")
                    {
                        if (st.Name10 == "")
                        {
                            st.Name10 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name11 == "")
                        {
                            st.Name11 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name12 == "")
                        {
                            st.Name12 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "4")
                {
                    if (st.Name13 == "" || st.Name14 == "" || st.Name15 == "")
                    {
                        if (st.Name13 == "")
                        {
                            st.Name13 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name14 == "")
                        {
                            st.Name14 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name15 == "")
                        {
                            st.Name15 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "5")
                {
                    if (st.Name16 == "" || st.Name17 == "" || st.Name18 == "")
                    {
                        if (st.Name16 == "")
                        {
                            st.Name16 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name17 == "")
                        {
                            st.Name17 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name18 == "")
                        {
                            st.Name18 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please Select the Reference Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (txtbx_CustmrId.Text == "7")
            {
                if (cmbobx_refid.Text == "0")
                {
                    if (st.Name1 == "" || st.Name2 == "" || st.Name3 == "")
                    {
                        if (st.Name1 == "")
                        {
                            st.Name1 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name2 == "")
                        {
                            st.Name2 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name3 == "")
                        {
                            st.Name3 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "1")
                {

                    if (st.Name4 == "" || st.Name5 == "" || st.Name6 == "")
                    {
                        if (st.Name4 == "")
                        {
                            st.Name4 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name5 == "")
                        {
                            st.Name5 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name6 == "")
                        {
                            st.Name6 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "2")
                {
                    if (st.Name7 == "" || st.Name8 == "" || st.Name9 == "")
                    {
                        if (st.Name7 == "")
                        {
                            st.Name7 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name8 == "")
                        {
                            st.Name8 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name9 == "")
                        {
                            st.Name9 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "3")
                {
                    if (st.Name10 == "" || st.Name11 == "" || st.Name12 == "")
                    {
                        if (st.Name10 == "")
                        {
                            st.Name10 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name11 == "")
                        {
                            st.Name11 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name12 == "")
                        {
                            st.Name12 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "4")
                {
                    if (st.Name13 == "" || st.Name14 == "" || st.Name15 == "")
                    {
                        if (st.Name13 == "")
                        {
                            st.Name13 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name14 == "")
                        {
                            st.Name14 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name15 == "")
                        {
                            st.Name15 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "5")
                {
                    if (st.Name16 == "" || st.Name17 == "" || st.Name18 == "")
                    {
                        if (st.Name16 == "")
                        {
                            st.Name16 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name17 == "")
                        {
                            st.Name17 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name18 == "")
                        {
                            st.Name18 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "6")
                {
                    if (st.Name19 == "" || st.Name20 == "" || st.Name21 == "")
                    {
                        if (st.Name19 == "")
                        {
                            st.Name19 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name20 == "")
                        {
                            st.Name20 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name21 == "")
                        {
                            st.Name21 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please Select the Reference Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (txtbx_CustmrId.Text == "8")
            {
                if (cmbobx_refid.Text == "0")
                {
                    if (st.Name1 == "" || st.Name2 == "" || st.Name3 == "")
                    {
                        if (st.Name1 == "")
                        {
                            st.Name1 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name2 == "")
                        {
                            st.Name2 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name3 == "")
                        {
                            st.Name3 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "1")
                {

                    if (st.Name4 == "" || st.Name5 == "" || st.Name6 == "")
                    {
                        if (st.Name4 == "")
                        {
                            st.Name4 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name5 == "")
                        {
                            st.Name5 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name6 == "")
                        {
                            st.Name6 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "2")
                {
                    if (st.Name7 == "" || st.Name8 == "" || st.Name9 == "")
                    {
                        if (st.Name7 == "")
                        {
                            st.Name7 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name8 == "")
                        {
                            st.Name8 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name9 == "")
                        {
                            st.Name9 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "3")
                {
                    if (st.Name10 == "" || st.Name11 == "" || st.Name12 == "")
                    {
                        if (st.Name10 == "")
                        {
                            st.Name10 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name11 == "")
                        {
                            st.Name11 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name12 == "")
                        {
                            st.Name12 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "4")
                {
                    if (st.Name13 == "" || st.Name14 == "" || st.Name15 == "")
                    {
                        if (st.Name13 == "")
                        {
                            st.Name13 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name14 == "")
                        {
                            st.Name14 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name15 == "")
                        {
                            st.Name15 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "5")
                {
                    if (st.Name16 == "" || st.Name17 == "" || st.Name18 == "")
                    {
                        if (st.Name16 == "")
                        {
                            st.Name16 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name17 == "")
                        {
                            st.Name17 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name18 == "")
                        {
                            st.Name18 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "6")
                {
                    if (st.Name19 == "" || st.Name20 == "" || st.Name21 == "")
                    {
                        if (st.Name19 == "")
                        {
                            st.Name19 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name20 == "")
                        {
                            st.Name20 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name21 == "")
                        {
                            st.Name21 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if(cmbobx_refid.Text == "7")
                {
                    if (st.Name22 == "" || st.Name23 == "" || st.Name24 == "")
                    {
                        if (st.Name22 == "")
                        {
                            st.Name22 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name23 == "")
                        {
                            st.Name23 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name24 == "")
                        {
                            st.Name24 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please Select the Reference Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (txtbx_CustmrId.Text == "9")
            {
                if (cmbobx_refid.Text == "0")
                {
                    if (st.Name1 == "" || st.Name2 == "" || st.Name3 == "")
                    {
                        if (st.Name1 == "")
                        {
                            st.Name1 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name2 == "")
                        {
                            st.Name2 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name3 == "")
                        {
                            st.Name3 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "1")
                {

                    if (st.Name4 == "" || st.Name5 == "" || st.Name6 == "")
                    {
                        if (st.Name4 == "")
                        {
                            st.Name4 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name5 == "")
                        {
                            st.Name5 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name6 == "")
                        {
                            st.Name6 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "2")
                {
                    if (st.Name7 == "" || st.Name8 == "" || st.Name9 == "")
                    {
                        if (st.Name7 == "")
                        {
                            st.Name7 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name8 == "")
                        {
                            st.Name8 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name9 == "")
                        {
                            st.Name9 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "3")
                {
                    if (st.Name10 == "" || st.Name11 == "" || st.Name12 == "")
                    {
                        if (st.Name10 == "")
                        {
                            st.Name10 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name11 == "")
                        {
                            st.Name11 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name12 == "")
                        {
                            st.Name12 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "4")
                {
                    if (st.Name13 == "" || st.Name14 == "" || st.Name15 == "")
                    {
                        if (st.Name13 == "")
                        {
                            st.Name13 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name14 == "")
                        {
                            st.Name14 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name15 == "")
                        {
                            st.Name15 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "5")
                {
                    if (st.Name16 == "" || st.Name17 == "" || st.Name18 == "")
                    {
                        if (st.Name16 == "")
                        {
                            st.Name16 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name17 == "")
                        {
                            st.Name17 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name18 == "")
                        {
                            st.Name18 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "6")
                {
                    if (st.Name19 == "" || st.Name20 == "" || st.Name21 == "")
                    {
                        if (st.Name19 == "")
                        {
                            st.Name19 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name20 == "")
                        {
                            st.Name20 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name21 == "")
                        {
                            st.Name21 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "7")
                {
                    if (st.Name22 == "" || st.Name23 == "" || st.Name24 == "")
                    {
                        if (st.Name22 == "")
                        {
                            st.Name22 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name23 == "")
                        {
                            st.Name23 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name24 == "")
                        {
                            st.Name24 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "8")
                {
                    if (st.Name25 == "" || st.Name26 == "" || st.Name27 == "")
                    {
                        if (st.Name25 == "")
                        {
                            st.Name25 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name26 == "")
                        {
                            st.Name26 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name27 == "")
                        {
                            st.Name27 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please Select the Reference Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (txtbx_CustmrId.Text == "10")
            {
                if (cmbobx_refid.Text == "0")
                {
                    if (st.Name1 == "" || st.Name2 == "" || st.Name3 == "")
                    {
                        if (st.Name1 == "")
                        {
                            st.Name1 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name2 == "")
                        {
                            st.Name2 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name3 == "")
                        {
                            st.Name3 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "1")
                {

                    if (st.Name4 == "" || st.Name5 == "" || st.Name6 == "")
                    {
                        if (st.Name4 == "")
                        {
                            st.Name4 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name5 == "")
                        {
                            st.Name5 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name6 == "")
                        {
                            st.Name6 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "2")
                {
                    if (st.Name7 == "" || st.Name8 == "" || st.Name9 == "")
                    {
                        if (st.Name7 == "")
                        {
                            st.Name7 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name8 == "")
                        {
                            st.Name8 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name9 == "")
                        {
                            st.Name9 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "3")
                {
                    if (st.Name10 == "" || st.Name11 == "" || st.Name12 == "")
                    {
                        if (st.Name10 == "")
                        {
                            st.Name10 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name11 == "")
                        {
                            st.Name11 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name12 == "")
                        {
                            st.Name12 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "4")
                {
                    if (st.Name13 == "" || st.Name14 == "" || st.Name15 == "")
                    {
                        if (st.Name13 == "")
                        {
                            st.Name13 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name14 == "")
                        {
                            st.Name14 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name15 == "")
                        {
                            st.Name15 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "5")
                {
                    if (st.Name16 == "" || st.Name17 == "" || st.Name18 == "")
                    {
                        if (st.Name16 == "")
                        {
                            st.Name16 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name17 == "")
                        {
                            st.Name17 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name18 == "")
                        {
                            st.Name18 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "6")
                {
                    if (st.Name19 == "" || st.Name20 == "" || st.Name21 == "")
                    {
                        if (st.Name19 == "")
                        {
                            st.Name19 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name20 == "")
                        {
                            st.Name20 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name21 == "")
                        {
                            st.Name21 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "7")
                {
                    if (st.Name22 == "" || st.Name23 == "" || st.Name24 == "")
                    {
                        if (st.Name22 == "")
                        {
                            st.Name22 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name23 == "")
                        {
                            st.Name23 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name24 == "")
                        {
                            st.Name24 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "8")
                {
                    if (st.Name25 == "" || st.Name26 == "" || st.Name27 == "")
                    {
                        if (st.Name25 == "")
                        {
                            st.Name25 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name26 == "")
                        {
                            st.Name26 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name27 == "")
                        {
                            st.Name27 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "9")
                {
                    if (st.Name28 == "" || st.Name29 == "" || st.Name30 == "")
                    {
                        if (st.Name28 == "")
                        {
                            st.Name28 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name29 == "")
                        {
                            st.Name29 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name30 == "")
                        {
                            st.Name30 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please Select the Reference Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (txtbx_CustmrId.Text == "11")
            {
                if (cmbobx_refid.Text == "0")
                {
                    if (st.Name1 == "" || st.Name2 == "" || st.Name3 == "")
                    {
                        if (st.Name1 == "")
                        {
                            st.Name1 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name2 == "")
                        {
                            st.Name2 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name3 == "")
                        {
                            st.Name3 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "1")
                {

                    if (st.Name4 == "" || st.Name5 == "" || st.Name6 == "")
                    {
                        if (st.Name4 == "")
                        {
                            st.Name4 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name5 == "")
                        {
                            st.Name5 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name6 == "")
                        {
                            st.Name6 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "2")
                {
                    if (st.Name7 == "" || st.Name8 == "" || st.Name9 == "")
                    {
                        if (st.Name7 == "")
                        {
                            st.Name7 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name8 == "")
                        {
                            st.Name8 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name9 == "")
                        {
                            st.Name9 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "3")
                {
                    if (st.Name10 == "" || st.Name11 == "" || st.Name12 == "")
                    {
                        if (st.Name10 == "")
                        {
                            st.Name10 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name11 == "")
                        {
                            st.Name11 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name12 == "")
                        {
                            st.Name12 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "4")
                {
                    if (st.Name13 == "" || st.Name14 == "" || st.Name15 == "")
                    {
                        if (st.Name13 == "")
                        {
                            st.Name13 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name14 == "")
                        {
                            st.Name14 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name15 == "")
                        {
                            st.Name15 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "5")
                {
                    if (st.Name16 == "" || st.Name17 == "" || st.Name18 == "")
                    {
                        if (st.Name16 == "")
                        {
                            st.Name16 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name17 == "")
                        {
                            st.Name17 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name18 == "")
                        {
                            st.Name18 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "6")
                {
                    if (st.Name19 == "" || st.Name20 == "" || st.Name21 == "")
                    {
                        if (st.Name19 == "")
                        {
                            st.Name19 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name20 == "")
                        {
                            st.Name20 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name21 == "")
                        {
                            st.Name21 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "7")
                {
                    if (st.Name22 == "" || st.Name23 == "" || st.Name24 == "")
                    {
                        if (st.Name22 == "")
                        {
                            st.Name22 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name23 == "")
                        {
                            st.Name23 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name24 == "")
                        {
                            st.Name24 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "8")
                {
                    if (st.Name25 == "" || st.Name26 == "" || st.Name27 == "")
                    {
                        if (st.Name25 == "")
                        {
                            st.Name25 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name26 == "")
                        {
                            st.Name26 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name27 == "")
                        {
                            st.Name27 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "9")
                {
                    if (st.Name28 == "" || st.Name29 == "" || st.Name30 == "")
                    {
                        if (st.Name28 == "")
                        {
                            st.Name28 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name29 == "")
                        {
                            st.Name29 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name30 == "")
                        {
                            st.Name30 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "10")
                {
                    if (st.Name31 == "" || st.Name32 == "" || st.Name33 == "")
                    {
                        if (st.Name31 == "")
                        {
                            st.Name31 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name32 == "")
                        {
                            st.Name32 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name33 == "")
                        {
                            st.Name33 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please Select the Reference Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (txtbx_CustmrId.Text == "12")
            {
                if (cmbobx_refid.Text == "0")
                {
                    if (st.Name1 == "" || st.Name2 == "" || st.Name3 == "")
                    {
                        if (st.Name1 == "")
                        {
                            st.Name1 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name2 == "")
                        {
                            st.Name2 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name3 == "")
                        {
                            st.Name3 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "1")
                {

                    if (st.Name4 == "" || st.Name5 == "" || st.Name6 == "")
                    {
                        if (st.Name4 == "")
                        {
                            st.Name4 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name5 == "")
                        {
                            st.Name5 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name6 == "")
                        {
                            st.Name6 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "2")
                {
                    if (st.Name7 == "" || st.Name8 == "" || st.Name9 == "")
                    {
                        if (st.Name7 == "")
                        {
                            st.Name7 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name8 == "")
                        {
                            st.Name8 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name9 == "")
                        {
                            st.Name9 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "3")
                {
                    if (st.Name10 == "" || st.Name11 == "" || st.Name12 == "")
                    {
                        if (st.Name10 == "")
                        {
                            st.Name10 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name11 == "")
                        {
                            st.Name11 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name12 == "")
                        {
                            st.Name12 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "4")
                {
                    if (st.Name13 == "" || st.Name14 == "" || st.Name15 == "")
                    {
                        if (st.Name13 == "")
                        {
                            st.Name13 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name14 == "")
                        {
                            st.Name14 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name15 == "")
                        {
                            st.Name15 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "5")
                {
                    if (st.Name16 == "" || st.Name17 == "" || st.Name18 == "")
                    {
                        if (st.Name16 == "")
                        {
                            st.Name16 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name17 == "")
                        {
                            st.Name17 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name18 == "")
                        {
                            st.Name18 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "6")
                {
                    if (st.Name19 == "" || st.Name20 == "" || st.Name21 == "")
                    {
                        if (st.Name19 == "")
                        {
                            st.Name19 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name20 == "")
                        {
                            st.Name20 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name21 == "")
                        {
                            st.Name21 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "7")
                {
                    if (st.Name22 == "" || st.Name23 == "" || st.Name24 == "")
                    {
                        if (st.Name22 == "")
                        {
                            st.Name22 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name23 == "")
                        {
                            st.Name23 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name24 == "")
                        {
                            st.Name24 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "8")
                {
                    if (st.Name25 == "" || st.Name26 == "" || st.Name27 == "")
                    {
                        if (st.Name25 == "")
                        {
                            st.Name25 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name26 == "")
                        {
                            st.Name26 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name27 == "")
                        {
                            st.Name27 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "9")
                {
                    if (st.Name28 == "" || st.Name29 == "" || st.Name30 == "")
                    {
                        if (st.Name28 == "")
                        {
                            st.Name28 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name29 == "")
                        {
                            st.Name29 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name30 == "")
                        {
                            st.Name30 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "10")
                {
                    if (st.Name31 == "" || st.Name32 == "" || st.Name33 == "")
                    {
                        if (st.Name31 == "")
                        {
                            st.Name31 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name32 == "")
                        {
                            st.Name32 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name33 == "")
                        {
                            st.Name33 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (cmbobx_refid.Text == "11")
                {
                    if (st.Name34 == "" || st.Name35 == "" || st.Name36 == "")
                    {
                        if (st.Name34 == "")
                        {
                            st.Name34 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name35 == "")
                        {
                            st.Name35 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else if (st.Name36 == "")
                        {
                            st.Name36 = txtbx_nme.Text;
                            listbx_Registered.Items.Add(txtbx_CustmrId.Text);
                        }
                        else
                        {
                            MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Reference Id is Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please Select the Reference Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please Select the Reference Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_shw_Click(object sender, EventArgs e)
        {
            if (listbx_Registered.Text == "0")
            {
                listbx_Structrd.Items.Add(st.Name);
                listbx_Structrd.Items.Add(st.Name1);
                listbx_Structrd.Items.Add(st.Name2);
                listbx_Structrd.Items.Add(st.Name3);

            }
            else if (listbx_Registered.Text == "1")
            {
                listbx_Structrd.Items.Add(st.Name1);
                listbx_Structrd.Items.Add(st.Name4);
                listbx_Structrd.Items.Add(st.Name5);
                listbx_Structrd.Items.Add(st.Name6);

            }
            else if (listbx_Registered.Text == "2")
            {
                listbx_Structrd.Items.Add(st.Name2);
                listbx_Structrd.Items.Add(st.Name7);
                listbx_Structrd.Items.Add(st.Name8);
                listbx_Structrd.Items.Add(st.Name9);

            }
            else if (listbx_Registered.Text == "3")
            {
                listbx_Structrd.Items.Add(st.Name3);
                listbx_Structrd.Items.Add(st.Name10);
                listbx_Structrd.Items.Add(st.Name11);
                listbx_Structrd.Items.Add(st.Name12);

            }
            else if (listbx_Registered.Text == "4")
            {
                listbx_Structrd.Items.Add(st.Name4);
                listbx_Structrd.Items.Add(st.Name13);
                listbx_Structrd.Items.Add(st.Name14);
                listbx_Structrd.Items.Add(st.Name15);

            }
            else if (listbx_Registered.Text == "5")
            {
                listbx_Structrd.Items.Add(st.Name5);
                listbx_Structrd.Items.Add(st.Name16);
                listbx_Structrd.Items.Add(st.Name17);
                listbx_Structrd.Items.Add(st.Name18);

            }
            else if (listbx_Registered.Text == "7")
            {
                listbx_Structrd.Items.Add(st.Name7);
                listbx_Structrd.Items.Add(st.Name19);
                listbx_Structrd.Items.Add(st.Name20);
                listbx_Structrd.Items.Add(st.Name21);

            }
            else if (listbx_Registered.Text == "8")
            {
                listbx_Structrd.Items.Add(st.Name8);
                listbx_Structrd.Items.Add(st.Name22);
                listbx_Structrd.Items.Add(st.Name23);
                listbx_Structrd.Items.Add(st.Name24);

            }
            else if (listbx_Registered.Text == "9")
            {
                listbx_Structrd.Items.Add(st.Name9);
                listbx_Structrd.Items.Add(st.Name25);
                listbx_Structrd.Items.Add(st.Name26);
                listbx_Structrd.Items.Add(st.Name27);

            }
            else if (listbx_Registered.Text == "10")
            {
                listbx_Structrd.Items.Add(st.Name10);
                listbx_Structrd.Items.Add(st.Name28);
                listbx_Structrd.Items.Add(st.Name29);
                listbx_Structrd.Items.Add(st.Name30);

            }
            else if (listbx_Registered.Text == "11")
            {
                listbx_Structrd.Items.Add(st.Name11);
                listbx_Structrd.Items.Add(st.Name31);
                listbx_Structrd.Items.Add(st.Name32);
                listbx_Structrd.Items.Add(st.Name33);
            }
            else
            {
                MessageBox.Show("Id Not Available","Warning",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
           
        }
    }
}