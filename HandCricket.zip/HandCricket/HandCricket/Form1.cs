﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HandCricket
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int Score = 0;
        int Wicket = 11;
        int Score1 = 0;
        int Wicket1 = 11;
        int count = 1;
        int count1 = 1;
        private void Click1(object sender, EventArgs e)
        {
            if (Wicket > 1)
            {
                Button bt = (Button)sender;
                label1.Text = bt.Text;
                Random rd = new Random();
                var names = new List<String> { "0", "1", "2", "3", "4", "5", "6", "0", "1", "2", "3", "4", "5", "6" };
                int index = rd.Next(names.Count);
                var name = names[index];
                names.RemoveAt(index);
                label2.Text = name;
                if (label1.Text == label2.Text)
                {
                    MessageBox.Show("Out");
                    Wicket = Wicket - 1;
                    if (Wicket == 10)
                    {
                        W10.Hide();
                    }
                    else if (Wicket == 9)
                    {
                        W9.Hide();
                    }
                    else if (Wicket == 8)
                    {
                        W8.Hide();
                    }
                    else if (Wicket == 7)
                    {
                        W7.Hide();
                    }
                    else if (Wicket == 6)
                    {
                        W6.Hide();
                    }
                    else if (Wicket == 5)
                    {
                        W5.Hide();
                    }
                    else if (Wicket == 4)
                    {
                        W4.Hide();
                    }
                    else if (Wicket == 3)
                    {
                        W3.Hide();
                    }
                    else if (Wicket == 2)
                    {
                        W2.Hide();
                    }
                    else if (Wicket == 1)
                    {
                        W1.Hide();
                    }

                }
                else
                {
                    Score = (Score + Convert.ToInt32(label1.Text));
                    label3.Text = Score.ToString();                  
                }
               
            }
            else
            {
                if (count == 1)
                {
                    MessageBox.Show("Player1 Game Finished", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MessageBox.Show("The Target You have given to CPU is " + (Score + 1)+ " .");
                    count = count - 1;
                 
                }
                Button bt = (Button)sender;
                label1.Text = bt.Text;
                
                
                    if (Wicket1 > 1)
                    {
                        if (Score1 < Score)
                        {
                        Random rd = new Random();
                        var names = new List<String> { "0", "1", "2", "3", "4", "5", "6" };
                        int index = rd.Next(names.Count);
                        var name = names[index];
                        names.RemoveAt(index);
                        if (count1 == 1)
                        {
                            label2.Text = "0";
                            count1 = count1 - 1;
                        }
                        else
                        {
                            label2.Text = name;
                        }
                        if (label1.Text == label2.Text)
                        {
                            MessageBox.Show("Out");
                            Wicket1 = Wicket1 - 1;
                            if (Wicket1 == 10)
                            {
                                W20.Hide();
                            }
                            else if (Wicket1 == 9)
                            {
                                W19.Hide();
                            }
                            else if (Wicket1 == 8)
                            {
                                W18.Hide();
                            }
                            else if (Wicket1 == 7)
                            {
                                W17.Hide();
                            }
                            else if (Wicket1 == 6)
                            {
                                W16.Hide();
                            }
                            else if (Wicket1 == 5)
                            {
                                W15.Hide();
                            }
                            else if (Wicket1 == 4)
                            {
                                W14.Hide();
                            }
                            else if (Wicket1 == 3)
                            {
                                W13.Hide();
                            }
                            else if (Wicket1 == 2)
                            {
                                W12.Hide();
                            }
                            else if (Wicket1 == 1)
                            {
                                W11.Hide();
                            }
                        }
                        else
                        {
                            Score1 = (Score1 + Convert.ToInt32(label2.Text));
                            label14.Text = Score1.ToString();
                        }
                    }
                    else
                        {
                            MessageBox.Show("CPU Won the Game", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Close();       
                       }
                }
                else
                {
                    MessageBox.Show("You Won the Game", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                }

            }
        }
}
