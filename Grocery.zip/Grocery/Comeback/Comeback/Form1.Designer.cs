﻿namespace Comeback
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtbxprdct1 = new System.Windows.Forms.TextBox();
            this.txtbxprice1 = new System.Windows.Forms.TextBox();
            this.txtbxqty1 = new System.Windows.Forms.TextBox();
            this.txtbxamt1 = new System.Windows.Forms.TextBox();
            this.txtbxprdct2 = new System.Windows.Forms.TextBox();
            this.txtbxprice2 = new System.Windows.Forms.TextBox();
            this.txtbxqty2 = new System.Windows.Forms.TextBox();
            this.txtbxamt2 = new System.Windows.Forms.TextBox();
            this.txtbxprdct3 = new System.Windows.Forms.TextBox();
            this.txtbxprice3 = new System.Windows.Forms.TextBox();
            this.txtbxqty3 = new System.Windows.Forms.TextBox();
            this.txtbxamt3 = new System.Windows.Forms.TextBox();
            this.txtbxprdct4 = new System.Windows.Forms.TextBox();
            this.txtbxprice4 = new System.Windows.Forms.TextBox();
            this.txtbxqty4 = new System.Windows.Forms.TextBox();
            this.txtbxamt4 = new System.Windows.Forms.TextBox();
            this.txtbxprdct5 = new System.Windows.Forms.TextBox();
            this.txtbxprice5 = new System.Windows.Forms.TextBox();
            this.txtbxqty5 = new System.Windows.Forms.TextBox();
            this.txtbxamt5 = new System.Windows.Forms.TextBox();
            this.txtbxprdct6 = new System.Windows.Forms.TextBox();
            this.txtbxprice6 = new System.Windows.Forms.TextBox();
            this.txtbxqty6 = new System.Windows.Forms.TextBox();
            this.txtbxamt6 = new System.Windows.Forms.TextBox();
            this.txtbxprdct7 = new System.Windows.Forms.TextBox();
            this.txtbxprice7 = new System.Windows.Forms.TextBox();
            this.txtbxqty7 = new System.Windows.Forms.TextBox();
            this.txtbxamt7 = new System.Windows.Forms.TextBox();
            this.txtbxprdct8 = new System.Windows.Forms.TextBox();
            this.txtbxprice8 = new System.Windows.Forms.TextBox();
            this.txtbxqty8 = new System.Windows.Forms.TextBox();
            this.txtbxamt8 = new System.Windows.Forms.TextBox();
            this.txtbxprdct9 = new System.Windows.Forms.TextBox();
            this.txtbxprice9 = new System.Windows.Forms.TextBox();
            this.txtbxqty9 = new System.Windows.Forms.TextBox();
            this.txtbxamt9 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtbxtotal = new System.Windows.Forms.TextBox();
            this.txtbxnetamnt = new System.Windows.Forms.TextBox();
            this.txtbxdiscnt2 = new System.Windows.Forms.TextBox();
            this.txtbxdiscnt1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 24F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(649, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "BILLING";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(42, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(273, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "PRODUCT NAME";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(420, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(273, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "PRICE / QUANTITY";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(797, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(273, 32);
            this.label4.TabIndex = 3;
            this.label4.Text = "QUANTITY";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1162, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(273, 32);
            this.label5.TabIndex = 4;
            this.label5.Text = "AMOUNT";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtbxprdct1
            // 
            this.txtbxprdct1.AutoCompleteCustomSource.AddRange(new string[] {
            "APPLE",
            "BANANA",
            "GOOSEBERRY",
            "GRAPES",
            "GREEN GRAPES",
            "GUAVA",
            "MANGO",
            "MOSAMBI",
            "ORANGE",
            "WATERMELON",
            "POMEGRANTE"});
            this.txtbxprdct1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtbxprdct1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtbxprdct1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprdct1.Location = new System.Drawing.Point(42, 169);
            this.txtbxprdct1.Name = "txtbxprdct1";
            this.txtbxprdct1.Size = new System.Drawing.Size(273, 26);
            this.txtbxprdct1.TabIndex = 5;
            this.txtbxprdct1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxprdct1.TextChanged += new System.EventHandler(this.txtbxprdct1_TextChanged);
            // 
            // txtbxprice1
            // 
            this.txtbxprice1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprice1.Location = new System.Drawing.Point(420, 169);
            this.txtbxprice1.Name = "txtbxprice1";
            this.txtbxprice1.Size = new System.Drawing.Size(273, 26);
            this.txtbxprice1.TabIndex = 6;
            this.txtbxprice1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxqty1
            // 
            this.txtbxqty1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxqty1.Location = new System.Drawing.Point(797, 169);
            this.txtbxqty1.Name = "txtbxqty1";
            this.txtbxqty1.ShortcutsEnabled = false;
            this.txtbxqty1.Size = new System.Drawing.Size(273, 26);
            this.txtbxqty1.TabIndex = 7;
            this.txtbxqty1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxqty1.TextChanged += new System.EventHandler(this.txtbxqty1_TextChanged);
            // 
            // txtbxamt1
            // 
            this.txtbxamt1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxamt1.Location = new System.Drawing.Point(1162, 169);
            this.txtbxamt1.Name = "txtbxamt1";
            this.txtbxamt1.Size = new System.Drawing.Size(273, 26);
            this.txtbxamt1.TabIndex = 8;
            this.txtbxamt1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxprdct2
            // 
            this.txtbxprdct2.AutoCompleteCustomSource.AddRange(new string[] {
            "APPLE",
            "BANANA",
            "GOOSEBERRY",
            "GRAPES",
            "GREEN GRAPES",
            "GUAVA",
            "MANGO",
            "MOSAMBI",
            "ORANGE",
            "WATERMELON",
            "POMEGRANTE"});
            this.txtbxprdct2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtbxprdct2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtbxprdct2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprdct2.Location = new System.Drawing.Point(42, 195);
            this.txtbxprdct2.Name = "txtbxprdct2";
            this.txtbxprdct2.Size = new System.Drawing.Size(273, 26);
            this.txtbxprdct2.TabIndex = 9;
            this.txtbxprdct2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxprdct2.TextChanged += new System.EventHandler(this.txtbxprdct2_TextChanged);
            // 
            // txtbxprice2
            // 
            this.txtbxprice2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprice2.Location = new System.Drawing.Point(420, 195);
            this.txtbxprice2.Name = "txtbxprice2";
            this.txtbxprice2.Size = new System.Drawing.Size(273, 26);
            this.txtbxprice2.TabIndex = 10;
            this.txtbxprice2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxqty2
            // 
            this.txtbxqty2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxqty2.Location = new System.Drawing.Point(797, 195);
            this.txtbxqty2.Name = "txtbxqty2";
            this.txtbxqty2.Size = new System.Drawing.Size(273, 26);
            this.txtbxqty2.TabIndex = 11;
            this.txtbxqty2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxqty2.TextChanged += new System.EventHandler(this.txtbxqty2_TextChanged);
            // 
            // txtbxamt2
            // 
            this.txtbxamt2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxamt2.Location = new System.Drawing.Point(1162, 195);
            this.txtbxamt2.Name = "txtbxamt2";
            this.txtbxamt2.Size = new System.Drawing.Size(273, 26);
            this.txtbxamt2.TabIndex = 12;
            this.txtbxamt2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxprdct3
            // 
            this.txtbxprdct3.AutoCompleteCustomSource.AddRange(new string[] {
            "APPLE",
            "BANANA",
            "GOOSEBERRY",
            "GRAPES",
            "GREEN GRAPES",
            "GUAVA",
            "MANGO",
            "MOSAMBI",
            "ORANGE",
            "WATERMELON",
            "POMEGRANTE"});
            this.txtbxprdct3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtbxprdct3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtbxprdct3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprdct3.Location = new System.Drawing.Point(42, 221);
            this.txtbxprdct3.Name = "txtbxprdct3";
            this.txtbxprdct3.Size = new System.Drawing.Size(273, 26);
            this.txtbxprdct3.TabIndex = 13;
            this.txtbxprdct3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxprdct3.TextChanged += new System.EventHandler(this.txtbxprdct3_TextChanged);
            // 
            // txtbxprice3
            // 
            this.txtbxprice3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprice3.Location = new System.Drawing.Point(420, 221);
            this.txtbxprice3.Name = "txtbxprice3";
            this.txtbxprice3.Size = new System.Drawing.Size(273, 26);
            this.txtbxprice3.TabIndex = 14;
            this.txtbxprice3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxqty3
            // 
            this.txtbxqty3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxqty3.Location = new System.Drawing.Point(797, 221);
            this.txtbxqty3.Name = "txtbxqty3";
            this.txtbxqty3.Size = new System.Drawing.Size(273, 26);
            this.txtbxqty3.TabIndex = 15;
            this.txtbxqty3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxqty3.TextChanged += new System.EventHandler(this.txtbxqty3_TextChanged);
            // 
            // txtbxamt3
            // 
            this.txtbxamt3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxamt3.Location = new System.Drawing.Point(1162, 221);
            this.txtbxamt3.Name = "txtbxamt3";
            this.txtbxamt3.Size = new System.Drawing.Size(273, 26);
            this.txtbxamt3.TabIndex = 16;
            this.txtbxamt3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxprdct4
            // 
            this.txtbxprdct4.AutoCompleteCustomSource.AddRange(new string[] {
            "APPLE",
            "BANANA",
            "GOOSEBERRY",
            "GRAPES",
            "GREEN GRAPES",
            "GUAVA",
            "MANGO",
            "MOSAMBI",
            "ORANGE",
            "WATERMELON",
            "POMEGRANTE"});
            this.txtbxprdct4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtbxprdct4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtbxprdct4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprdct4.Location = new System.Drawing.Point(42, 247);
            this.txtbxprdct4.Name = "txtbxprdct4";
            this.txtbxprdct4.Size = new System.Drawing.Size(273, 26);
            this.txtbxprdct4.TabIndex = 17;
            this.txtbxprdct4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxprdct4.TextChanged += new System.EventHandler(this.txtbxprdct4_TextChanged);
            // 
            // txtbxprice4
            // 
            this.txtbxprice4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprice4.Location = new System.Drawing.Point(420, 247);
            this.txtbxprice4.Name = "txtbxprice4";
            this.txtbxprice4.Size = new System.Drawing.Size(273, 26);
            this.txtbxprice4.TabIndex = 18;
            this.txtbxprice4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxqty4
            // 
            this.txtbxqty4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxqty4.Location = new System.Drawing.Point(797, 247);
            this.txtbxqty4.Name = "txtbxqty4";
            this.txtbxqty4.Size = new System.Drawing.Size(273, 26);
            this.txtbxqty4.TabIndex = 19;
            this.txtbxqty4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxqty4.TextChanged += new System.EventHandler(this.txtbxqty4_TextChanged);
            // 
            // txtbxamt4
            // 
            this.txtbxamt4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxamt4.Location = new System.Drawing.Point(1162, 247);
            this.txtbxamt4.Name = "txtbxamt4";
            this.txtbxamt4.Size = new System.Drawing.Size(273, 26);
            this.txtbxamt4.TabIndex = 20;
            this.txtbxamt4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxprdct5
            // 
            this.txtbxprdct5.AutoCompleteCustomSource.AddRange(new string[] {
            "APPLE",
            "BANANA",
            "GOOSEBERRY",
            "GRAPES",
            "GREEN GRAPES",
            "GUAVA",
            "MANGO",
            "MOSAMBI",
            "ORANGE",
            "WATERMELON",
            "POMEGRANTE"});
            this.txtbxprdct5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtbxprdct5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtbxprdct5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprdct5.Location = new System.Drawing.Point(42, 273);
            this.txtbxprdct5.Name = "txtbxprdct5";
            this.txtbxprdct5.Size = new System.Drawing.Size(273, 26);
            this.txtbxprdct5.TabIndex = 21;
            this.txtbxprdct5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxprdct5.TextChanged += new System.EventHandler(this.txtbxprdct5_TextChanged);
            // 
            // txtbxprice5
            // 
            this.txtbxprice5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprice5.Location = new System.Drawing.Point(420, 273);
            this.txtbxprice5.Name = "txtbxprice5";
            this.txtbxprice5.Size = new System.Drawing.Size(273, 26);
            this.txtbxprice5.TabIndex = 22;
            this.txtbxprice5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxqty5
            // 
            this.txtbxqty5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxqty5.Location = new System.Drawing.Point(797, 273);
            this.txtbxqty5.Name = "txtbxqty5";
            this.txtbxqty5.Size = new System.Drawing.Size(273, 26);
            this.txtbxqty5.TabIndex = 23;
            this.txtbxqty5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxqty5.TextChanged += new System.EventHandler(this.txtbxqty5_TextChanged);
            // 
            // txtbxamt5
            // 
            this.txtbxamt5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxamt5.Location = new System.Drawing.Point(1162, 273);
            this.txtbxamt5.Name = "txtbxamt5";
            this.txtbxamt5.Size = new System.Drawing.Size(273, 26);
            this.txtbxamt5.TabIndex = 24;
            this.txtbxamt5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxprdct6
            // 
            this.txtbxprdct6.AutoCompleteCustomSource.AddRange(new string[] {
            "APPLE",
            "BANANA",
            "GOOSEBERRY",
            "GRAPES",
            "GREEN GRAPES",
            "GUAVA",
            "MANGO",
            "MOSAMBI",
            "ORANGE",
            "WATERMELON",
            "POMEGRANTE"});
            this.txtbxprdct6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtbxprdct6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtbxprdct6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprdct6.Location = new System.Drawing.Point(42, 299);
            this.txtbxprdct6.Name = "txtbxprdct6";
            this.txtbxprdct6.Size = new System.Drawing.Size(273, 26);
            this.txtbxprdct6.TabIndex = 25;
            this.txtbxprdct6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxprdct6.TextChanged += new System.EventHandler(this.txtbxprdct6_TextChanged);
            // 
            // txtbxprice6
            // 
            this.txtbxprice6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprice6.Location = new System.Drawing.Point(420, 299);
            this.txtbxprice6.Name = "txtbxprice6";
            this.txtbxprice6.Size = new System.Drawing.Size(273, 26);
            this.txtbxprice6.TabIndex = 26;
            this.txtbxprice6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxqty6
            // 
            this.txtbxqty6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxqty6.Location = new System.Drawing.Point(797, 299);
            this.txtbxqty6.Name = "txtbxqty6";
            this.txtbxqty6.Size = new System.Drawing.Size(273, 26);
            this.txtbxqty6.TabIndex = 27;
            this.txtbxqty6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxqty6.TextChanged += new System.EventHandler(this.txtbxqty6_TextChanged);
            // 
            // txtbxamt6
            // 
            this.txtbxamt6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxamt6.Location = new System.Drawing.Point(1162, 299);
            this.txtbxamt6.Name = "txtbxamt6";
            this.txtbxamt6.Size = new System.Drawing.Size(273, 26);
            this.txtbxamt6.TabIndex = 28;
            this.txtbxamt6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxprdct7
            // 
            this.txtbxprdct7.AutoCompleteCustomSource.AddRange(new string[] {
            "APPLE",
            "BANANA",
            "GOOSEBERRY",
            "GRAPES",
            "GREEN GRAPES",
            "GUAVA",
            "MANGO",
            "MOSAMBI",
            "ORANGE",
            "WATERMELON",
            "POMEGRANTE"});
            this.txtbxprdct7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtbxprdct7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtbxprdct7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprdct7.Location = new System.Drawing.Point(42, 325);
            this.txtbxprdct7.Name = "txtbxprdct7";
            this.txtbxprdct7.Size = new System.Drawing.Size(273, 26);
            this.txtbxprdct7.TabIndex = 29;
            this.txtbxprdct7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxprdct7.TextChanged += new System.EventHandler(this.txtbxprdct7_TextChanged);
            // 
            // txtbxprice7
            // 
            this.txtbxprice7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprice7.Location = new System.Drawing.Point(420, 325);
            this.txtbxprice7.Name = "txtbxprice7";
            this.txtbxprice7.Size = new System.Drawing.Size(273, 26);
            this.txtbxprice7.TabIndex = 30;
            this.txtbxprice7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxqty7
            // 
            this.txtbxqty7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxqty7.Location = new System.Drawing.Point(797, 325);
            this.txtbxqty7.Name = "txtbxqty7";
            this.txtbxqty7.Size = new System.Drawing.Size(273, 26);
            this.txtbxqty7.TabIndex = 31;
            this.txtbxqty7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxqty7.TextChanged += new System.EventHandler(this.txtbxqty7_TextChanged);
            // 
            // txtbxamt7
            // 
            this.txtbxamt7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxamt7.Location = new System.Drawing.Point(1162, 325);
            this.txtbxamt7.Name = "txtbxamt7";
            this.txtbxamt7.Size = new System.Drawing.Size(273, 26);
            this.txtbxamt7.TabIndex = 32;
            this.txtbxamt7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxprdct8
            // 
            this.txtbxprdct8.AutoCompleteCustomSource.AddRange(new string[] {
            "APPLE",
            "BANANA",
            "GOOSEBERRY",
            "GRAPES",
            "GREEN GRAPES",
            "GUAVA",
            "MANGO",
            "MOSAMBI",
            "ORANGE",
            "WATERMELON",
            "POMEGRANTE"});
            this.txtbxprdct8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtbxprdct8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtbxprdct8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprdct8.Location = new System.Drawing.Point(42, 351);
            this.txtbxprdct8.Name = "txtbxprdct8";
            this.txtbxprdct8.Size = new System.Drawing.Size(273, 26);
            this.txtbxprdct8.TabIndex = 33;
            this.txtbxprdct8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxprdct8.TextChanged += new System.EventHandler(this.txtbxprdct8_TextChanged);
            // 
            // txtbxprice8
            // 
            this.txtbxprice8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprice8.Location = new System.Drawing.Point(420, 351);
            this.txtbxprice8.Name = "txtbxprice8";
            this.txtbxprice8.Size = new System.Drawing.Size(273, 26);
            this.txtbxprice8.TabIndex = 34;
            this.txtbxprice8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxqty8
            // 
            this.txtbxqty8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxqty8.Location = new System.Drawing.Point(797, 351);
            this.txtbxqty8.Name = "txtbxqty8";
            this.txtbxqty8.Size = new System.Drawing.Size(273, 26);
            this.txtbxqty8.TabIndex = 35;
            this.txtbxqty8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxqty8.TextChanged += new System.EventHandler(this.txtbxqty8_TextChanged);
            // 
            // txtbxamt8
            // 
            this.txtbxamt8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxamt8.Location = new System.Drawing.Point(1162, 351);
            this.txtbxamt8.Name = "txtbxamt8";
            this.txtbxamt8.Size = new System.Drawing.Size(273, 26);
            this.txtbxamt8.TabIndex = 36;
            this.txtbxamt8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxprdct9
            // 
            this.txtbxprdct9.AutoCompleteCustomSource.AddRange(new string[] {
            "APPLE",
            "BANANA",
            "GOOSEBERRY",
            "GRAPES",
            "GREEN GRAPES",
            "GUAVA",
            "MANGO",
            "MOSAMBI",
            "ORANGE",
            "WATERMELON",
            "POMEGRANTE"});
            this.txtbxprdct9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.txtbxprdct9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtbxprdct9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprdct9.Location = new System.Drawing.Point(42, 377);
            this.txtbxprdct9.Name = "txtbxprdct9";
            this.txtbxprdct9.Size = new System.Drawing.Size(273, 26);
            this.txtbxprdct9.TabIndex = 37;
            this.txtbxprdct9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxprdct9.TextChanged += new System.EventHandler(this.txtbxprdct9_TextChanged);
            // 
            // txtbxprice9
            // 
            this.txtbxprice9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxprice9.Location = new System.Drawing.Point(420, 377);
            this.txtbxprice9.Name = "txtbxprice9";
            this.txtbxprice9.Size = new System.Drawing.Size(273, 26);
            this.txtbxprice9.TabIndex = 38;
            this.txtbxprice9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxqty9
            // 
            this.txtbxqty9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxqty9.Location = new System.Drawing.Point(797, 377);
            this.txtbxqty9.Name = "txtbxqty9";
            this.txtbxqty9.Size = new System.Drawing.Size(273, 26);
            this.txtbxqty9.TabIndex = 39;
            this.txtbxqty9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxqty9.TextChanged += new System.EventHandler(this.txtbxqty9_TextChanged);
            // 
            // txtbxamt9
            // 
            this.txtbxamt9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxamt9.Location = new System.Drawing.Point(1162, 377);
            this.txtbxamt9.Name = "txtbxamt9";
            this.txtbxamt9.Size = new System.Drawing.Size(273, 26);
            this.txtbxamt9.TabIndex = 40;
            this.txtbxamt9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(838, 415);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(273, 32);
            this.label6.TabIndex = 41;
            this.label6.Text = "TOTAL";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(838, 458);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(273, 32);
            this.label7.TabIndex = 42;
            this.label7.Text = "DISCOUNT";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(838, 508);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(273, 32);
            this.label8.TabIndex = 43;
            this.label8.Text = "NETAMOUNT";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtbxtotal
            // 
            this.txtbxtotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtbxtotal.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxtotal.Location = new System.Drawing.Point(1162, 415);
            this.txtbxtotal.Name = "txtbxtotal";
            this.txtbxtotal.Size = new System.Drawing.Size(273, 32);
            this.txtbxtotal.TabIndex = 44;
            this.txtbxtotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxnetamnt
            // 
            this.txtbxnetamnt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtbxnetamnt.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxnetamnt.Location = new System.Drawing.Point(1162, 508);
            this.txtbxnetamnt.Name = "txtbxnetamnt";
            this.txtbxnetamnt.Size = new System.Drawing.Size(273, 32);
            this.txtbxnetamnt.TabIndex = 46;
            this.txtbxnetamnt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxdiscnt2
            // 
            this.txtbxdiscnt2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtbxdiscnt2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxdiscnt2.Location = new System.Drawing.Point(1310, 458);
            this.txtbxdiscnt2.Name = "txtbxdiscnt2";
            this.txtbxdiscnt2.Size = new System.Drawing.Size(125, 32);
            this.txtbxdiscnt2.TabIndex = 47;
            this.txtbxdiscnt2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbxdiscnt1
            // 
            this.txtbxdiscnt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtbxdiscnt1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbxdiscnt1.Location = new System.Drawing.Point(1162, 458);
            this.txtbxdiscnt1.Name = "txtbxdiscnt1";
            this.txtbxdiscnt1.Size = new System.Drawing.Size(131, 32);
            this.txtbxdiscnt1.TabIndex = 48;
            this.txtbxdiscnt1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxdiscnt1.TextChanged += new System.EventHandler(this.txtbxdiscnt1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(1506, 587);
            this.Controls.Add(this.txtbxdiscnt1);
            this.Controls.Add(this.txtbxdiscnt2);
            this.Controls.Add(this.txtbxnetamnt);
            this.Controls.Add(this.txtbxtotal);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtbxamt9);
            this.Controls.Add(this.txtbxqty9);
            this.Controls.Add(this.txtbxprice9);
            this.Controls.Add(this.txtbxprdct9);
            this.Controls.Add(this.txtbxamt8);
            this.Controls.Add(this.txtbxqty8);
            this.Controls.Add(this.txtbxprice8);
            this.Controls.Add(this.txtbxprdct8);
            this.Controls.Add(this.txtbxamt7);
            this.Controls.Add(this.txtbxqty7);
            this.Controls.Add(this.txtbxprice7);
            this.Controls.Add(this.txtbxprdct7);
            this.Controls.Add(this.txtbxamt6);
            this.Controls.Add(this.txtbxqty6);
            this.Controls.Add(this.txtbxprice6);
            this.Controls.Add(this.txtbxprdct6);
            this.Controls.Add(this.txtbxamt5);
            this.Controls.Add(this.txtbxqty5);
            this.Controls.Add(this.txtbxprice5);
            this.Controls.Add(this.txtbxprdct5);
            this.Controls.Add(this.txtbxamt4);
            this.Controls.Add(this.txtbxqty4);
            this.Controls.Add(this.txtbxprice4);
            this.Controls.Add(this.txtbxprdct4);
            this.Controls.Add(this.txtbxamt3);
            this.Controls.Add(this.txtbxqty3);
            this.Controls.Add(this.txtbxprice3);
            this.Controls.Add(this.txtbxprdct3);
            this.Controls.Add(this.txtbxamt2);
            this.Controls.Add(this.txtbxqty2);
            this.Controls.Add(this.txtbxprice2);
            this.Controls.Add(this.txtbxprdct2);
            this.Controls.Add(this.txtbxamt1);
            this.Controls.Add(this.txtbxqty1);
            this.Controls.Add(this.txtbxprice1);
            this.Controls.Add(this.txtbxprdct1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "BILLING";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtbxprdct1;
        private System.Windows.Forms.TextBox txtbxprice1;
        private System.Windows.Forms.TextBox txtbxqty1;
        private System.Windows.Forms.TextBox txtbxamt1;
        private System.Windows.Forms.TextBox txtbxprdct2;
        private System.Windows.Forms.TextBox txtbxprice2;
        private System.Windows.Forms.TextBox txtbxqty2;
        private System.Windows.Forms.TextBox txtbxamt2;
        private System.Windows.Forms.TextBox txtbxprdct3;
        private System.Windows.Forms.TextBox txtbxprice3;
        private System.Windows.Forms.TextBox txtbxqty3;
        private System.Windows.Forms.TextBox txtbxamt3;
        private System.Windows.Forms.TextBox txtbxprdct4;
        private System.Windows.Forms.TextBox txtbxprice4;
        private System.Windows.Forms.TextBox txtbxqty4;
        private System.Windows.Forms.TextBox txtbxamt4;
        private System.Windows.Forms.TextBox txtbxprdct5;
        private System.Windows.Forms.TextBox txtbxprice5;
        private System.Windows.Forms.TextBox txtbxqty5;
        private System.Windows.Forms.TextBox txtbxamt5;
        private System.Windows.Forms.TextBox txtbxprdct6;
        private System.Windows.Forms.TextBox txtbxprice6;
        private System.Windows.Forms.TextBox txtbxqty6;
        private System.Windows.Forms.TextBox txtbxamt6;
        private System.Windows.Forms.TextBox txtbxprdct7;
        private System.Windows.Forms.TextBox txtbxprice7;
        private System.Windows.Forms.TextBox txtbxqty7;
        private System.Windows.Forms.TextBox txtbxamt7;
        private System.Windows.Forms.TextBox txtbxprdct8;
        private System.Windows.Forms.TextBox txtbxprice8;
        private System.Windows.Forms.TextBox txtbxqty8;
        private System.Windows.Forms.TextBox txtbxamt8;
        private System.Windows.Forms.TextBox txtbxprdct9;
        private System.Windows.Forms.TextBox txtbxprice9;
        private System.Windows.Forms.TextBox txtbxqty9;
        private System.Windows.Forms.TextBox txtbxamt9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtbxtotal;
        private System.Windows.Forms.TextBox txtbxnetamnt;
        private System.Windows.Forms.TextBox txtbxdiscnt2;
        private System.Windows.Forms.TextBox txtbxdiscnt1;

        public System.EventHandler txtbxtotal_TextChanged { get; set; }
    }
}

