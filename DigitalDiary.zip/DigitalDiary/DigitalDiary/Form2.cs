﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace DigitalDiary
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_close1_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Close();
        }

        private void btn_crteuser_Click(object sender, EventArgs e)
        {
            if (txtbx_username.Text == "" || txtbx_pswd.Text == "" || txtbx_cnfrmpswd.Text == "")
            {
                MessageBox.Show("Please Enter the Blank Field", "Digital Diary 1.0", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(txtbx_pswd.Text == txtbx_cnfrmpswd.Text)
            {
                if (Directory.Exists(@"C:\Digital Diary 1.0\" + txtbx_username.Text) == false)
                {
                    Directory.CreateDirectory(@"C:\Digital Diary 1.0\" + txtbx_username.Text);
                    TextWriter tw;
                    tw = File.CreateText(@"C:\Digital Diary 1.0\" + txtbx_username.Text + @"\" +txtbx_username.Text+ ".txt");
                    tw.WriteLine(txtbx_username.Text);
                    tw.WriteLine(txtbx_pswd.Text);
                    tw.WriteLine(txtbx_cnfrmpswd.Text);
                    tw.WriteLine(txtbx_pswdqstn.Text);
                    tw.WriteLine(txtbx_pswdanswr.Text);
                    tw.Dispose();

                    txtbx_username.Text = "";
                    txtbx_pswd.Text = "";
                    txtbx_cnfrmpswd.Text = "";
                    txtbx_pswdqstn.Text = "";
                    txtbx_pswdanswr.Text = "";

                    DialogResult dr = new DialogResult();
                    dr = MessageBox.Show("New User Created Succesfully", "Digital Diary 1.0", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (dr == DialogResult.OK)
                    {
                        this.Hide();
                        Form1 frm1 = new Form1();
                        frm1.Show();
                    }

                }
                else
                {
                    MessageBox.Show("User Name Already Exists", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Password / Confirm Password not Matched", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                label10.Visible = false;
                label11.Visible = false;
                listbx_availbleuser.Visible = false;
                btn_newuser.Visible = false;
                btn_deleteuser.Visible = false;


                label1.Visible = true;
                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;
                label8.Visible = true;
                txtbx_username.Visible = true;
                txtbx_pswd.Visible = true;
                txtbx_cnfrmpswd.Visible = true;
                txtbx_pswdqstn.Visible = true;
                txtbx_pswdanswr.Visible = true;
                btn_close1.Visible = true;
                btn_crteuser.Visible = true;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
                label1.Visible = false;
                label2.Visible = false;
                label3.Visible = false;
                label4.Visible = false;
                label5.Visible = false;
                label6.Visible = false;
                label8.Visible = false;
                txtbx_username.Visible = false;
                txtbx_pswd.Visible = false;
                txtbx_cnfrmpswd.Visible = false;
                txtbx_pswdqstn.Visible = false;
                txtbx_pswdanswr.Visible = false;
                btn_close1.Visible = false;
                btn_crteuser.Visible = false;

                label10.Visible = true;
                label11.Visible = true;
                listbx_availbleuser.Visible = true;
                btn_newuser.Visible = true;
                btn_deleteuser.Visible = true;
                btn_close2.Visible = true;

                DirectoryInfo di = new DirectoryInfo(@"C:\Digital Diary 1.0\");
                foreach (object d in di.GetDirectories())
                {
                    listbx_availbleuser.Items.Add(d);
                   
                   
                }



            }

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                label10.Visible = false;
                label11.Visible = false;
                listbx_availbleuser.Visible = false;
                btn_newuser.Visible = false;
                btn_deleteuser.Visible = false;


                label1.Visible = true;
                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;
                label8.Visible = true;
                txtbx_username.Visible = true;
                txtbx_pswd.Visible = true;
                txtbx_cnfrmpswd.Visible = true;
                txtbx_pswdqstn.Visible = true;
                txtbx_pswdanswr.Visible = true;
                btn_close1.Visible = true;
                btn_crteuser.Visible = true;
            }

        }

        private void btn_close2_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Close();
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            radioButton1.Checked = true;
        }

        private void btn_deleteuser_Click(object sender, EventArgs e)
        {
            DirectoryInfo di1 = new DirectoryInfo(@"C:\Digital Diary 1.0\" + listbx_availbleuser.SelectedItem + @"\");
            foreach (object o1 in di1.GetFiles())
            {
                File.Delete(@"C:\Digital Diary 1.0\" + listbx_availbleuser.SelectedItem + @"\"+ o1);
            }
            Directory.Delete(@"C:\Digital Diary 1.0\" + listbx_availbleuser.SelectedItem);
            listbx_availbleuser.Items.Remove(listbx_availbleuser.SelectedItem);
        }
    }
}
