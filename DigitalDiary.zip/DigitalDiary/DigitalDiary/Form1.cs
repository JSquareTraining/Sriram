﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace DigitalDiary
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Parent = pictureBox1;
            label1.BackColor = Color.Transparent;

            DirectoryInfo di2 = new DirectoryInfo(@"C:\Digital Diary 1.0\");
            foreach (object d in di2.GetDirectories())
            {
                cmbx_usernme.Items.Add(d);


            }
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 frm2 = new Form2();
            frm2.Show();
            
        }

        private void btn_login_Click(object sender, EventArgs e)
        {

            if (cmbx_usernme.Text == "" || txtbx_pswd.Text == "")
            {
                MessageBox.Show("Please Enter the Username/Password", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (Directory.Exists(@"C:\Digital Diary 1.0\" + cmbx_usernme.SelectedItem) == true)
                {
                    DirectoryInfo di3 = new DirectoryInfo(@"C:\Digital Diary 1.0\" + cmbx_usernme.SelectedItem + @"/");
                    TextReader tr;
                    tr = File.OpenText(@"C:\Digital Diary 1.0\" + cmbx_usernme.SelectedItem + @"/" + cmbx_usernme.SelectedItem + ".txt");
                    if (cmbx_usernme.Text == tr.ReadLine() && txtbx_pswd.Text == tr.ReadLine())
                    {
                        DialogResult dr = new DialogResult();
                        dr =MessageBox.Show("Login Successfull", "Digital Diary 1.0", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        if (dr == DialogResult.OK)
                        {
                            this.Hide();
                            Form3 frm3 = new Form3();
                            frm3.lbl_username.Text = cmbx_usernme.Text;
                            frm3.Show();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter the Username / Password Correctly", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Username Not found in the Database", "Digital Diary 1.0", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            if (cmbx_usernme.Text == "")
            {
                MessageBox.Show("Please Choose the Username", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (Directory.Exists(@"C:\Digital Diary 1.0\" + cmbx_usernme.SelectedItem) == true)
                {
                    DirectoryInfo di3 = new DirectoryInfo(@"C:\Digital Diary 1.0\" + cmbx_usernme.SelectedItem + @"/");
                    TextReader tr;
                    tr = File.OpenText(@"C:\Digital Diary 1.0\" + cmbx_usernme.SelectedItem + @"/" + cmbx_usernme.SelectedItem + ".txt");
                    tr.ReadLine();
                    tr.ReadLine();
                    if (tr.ReadLine() != "")
                    {
                        DialogResult dr3 = new DialogResult();
                        dr3 = MessageBox.Show(tr.ReadLine(), "Digital Diary 1.0", MessageBoxButtons.OK, MessageBoxIcon.Question);
                        if (dr3 == DialogResult.OK)
                        {
                            txtbx_frgtpswd.Visible = true;
                            button1.Visible = true;
                            
                        }

                    }
                    else
                    {
                        MessageBox.Show("The Option is Not Availbale to you", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtbx_frgtpswd.Text != "")
            {
                if (Directory.Exists(@"C:\Digital Diary 1.0\" + cmbx_usernme.SelectedItem) == true)
                {
                    DirectoryInfo di3 = new DirectoryInfo(@"C:\Digital Diary 1.0\" + cmbx_usernme.SelectedItem + @"/");
                    TextReader tr;
                    tr = File.OpenText(@"C:\Digital Diary 1.0\" + cmbx_usernme.SelectedItem + @"/" + cmbx_usernme.SelectedItem + ".txt");
                    tr.ReadLine();
                   string s =  tr.ReadLine();
                    tr.ReadLine();
                   string s1 = tr.ReadLine();
                    if (txtbx_frgtpswd.Text == tr.ReadLine())
                    {
                        MessageBox.Show(s);
                    }
                    else
                    {
                        MessageBox.Show("The Answer is Wrong","Warning",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    }
                }
            }
        }

       
    }
}
