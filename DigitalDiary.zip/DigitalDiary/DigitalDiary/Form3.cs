﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Diagnostics;

namespace DigitalDiary
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        
        private void Form3_Load(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                richTextBox1.Text = "";
                button1.Visible = true;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            richTextBox1.ReadOnly = true;
            string s1 = monthCalendar1.SelectionStart.ToShortDateString();
            if (radioButton2.Checked == true)
            {
                button1.Visible = false;
                if (File.Exists(@"C:\Digital Diary 1.0\" + lbl_username.Text + @"\" + s1 + ".txt") == true)
                {
                    TextReader tr;
                    tr = File.OpenText(@"C:\Digital Diary 1.0\" + lbl_username.Text + @"\" + s1 + ".txt");
                    richTextBox1.Text = tr.ReadToEnd();
                    tr.Dispose();
                }
                else
                {
                    MessageBox.Show("The Diary on that day is Blank", "My Digital Diary 1.0", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            
            if (radioButton1.Checked == true)
            {
                richTextBox1.ReadOnly = false;
                richTextBox1.Text = "";
                button1.Visible = true;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s = monthCalendar1.SelectionStart.ToShortDateString();
            if (File.Exists(@"C:\Digital Diary 1.0\" + lbl_username.Text + @"\" + s + ".txt") == false)
            {
                TextWriter tw;
                tw = File.CreateText(@"C:\Digital Diary 1.0\" + lbl_username.Text + @"\" + s +".txt");
                tw.WriteLine(richTextBox1.Text);
                tw.Dispose();

            }
            else
            {
                TextWriter tw1;
                tw1 = File.AppendText(@"C:\Digital Diary 1.0\" + lbl_username.Text + @"\" + s + ".txt");
                tw1.WriteLine(richTextBox1.Text);
                tw1.Dispose();

            }
            richTextBox1.Text = "";
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            radioButton1.Checked = true;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked == true)
            {
                this.Hide();
                Form4 frm4 = new Form4();
              
                frm4.label2.Text = lbl_username.Text;
               
                frm4.Show();
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm1 = new Form1();
            frm1.Show();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Text != "")
            {
                DialogResult dr = new DialogResult();
                dr = MessageBox.Show("Do you want save this Content ?", "Digital Diary 1.0", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                if (dr == DialogResult.Yes)
                {
                    string s = monthCalendar1.SelectionStart.ToShortDateString();
                    if (File.Exists(@"C:\Digital Diary 1.0\" + lbl_username.Text + @"\" + s + ".txt") == false)
                    {
                        TextWriter tw;
                        tw = File.CreateText(@"C:\Digital Diary 1.0\" + lbl_username.Text + @"\" + s + ".txt");
                        tw.WriteLine(richTextBox1.Text);
                        tw.Dispose();

                    }
                    else
                    {
                        TextWriter tw1;
                        tw1 = File.AppendText(@"C:\Digital Diary 1.0\" + lbl_username.Text + @"\" + s + ".txt");
                        tw1.WriteLine(richTextBox1.Text);
                        tw1.Dispose();

                    }
                    richTextBox1.Text = "";
                }
                else if (dr == DialogResult.No)
                {
                    richTextBox1.Text = " ";
                }
                else
                {

                }

            }
            else
            {
                richTextBox1.Text = "";
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string s = monthCalendar1.SelectionStart.ToShortDateString();
            if (File.Exists(@"C:\Digital Diary 1.0\" + lbl_username.Text + @"\" + s + ".txt") == false)
            {
                TextWriter tw;
                tw = File.CreateText(@"C:\Digital Diary 1.0\" + lbl_username.Text + @"\" + s + ".txt");
                tw.WriteLine(richTextBox1.Text);
                tw.Dispose();

            }
            else
            {
                TextWriter tw1;
                tw1 = File.AppendText(@"C:\Digital Diary 1.0\" + lbl_username.Text + @"\" + s + ".txt");
                tw1.WriteLine(richTextBox1.Text);
                tw1.Dispose();

            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm1 = new Form1();
            frm1.Show();
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
            pasteToolStripMenuItem.Enabled = true;
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
            pasteToolStripMenuItem.Enabled = true;
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void dateTimeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = DateTime.Now.ToString();
        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectAll();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            copyToolStripMenuItem.Enabled = richTextBox1.SelectionLength > 0;
            cutToolStripMenuItem.Enabled = richTextBox1.SelectionLength > 0;
           
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label4.Visible = true;
            textBox1.Visible = true;
            btn_replace.Visible = true;
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                string s1 = richTextBox1.SelectedText;
                richTextBox1.Text = richTextBox1.Text.Replace(s1, textBox1.Text);
            }
            label4.Visible = false;
            textBox1.Visible = false;
            btn_replace.Visible = false;
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
            richTextBox1.Font = fontDialog1.Font;
        }

        private void calculatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("calc");
        }

        private void commandPromptToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("cmd");
        }

        private void notepadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("notepad");
        }

        private void wordpadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("wordpad");
        }

        private void controlPanelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("taskmgr");
        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

       

        

        
    }
}
