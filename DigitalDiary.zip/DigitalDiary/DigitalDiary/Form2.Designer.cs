﻿namespace DigitalDiary
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_deleteuser = new System.Windows.Forms.Button();
            this.btn_newuser = new System.Windows.Forms.Button();
            this.txtbx_pswdanswr = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.listbx_availbleuser = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_crteuser = new System.Windows.Forms.Button();
            this.txtbx_pswd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_close1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbx_cnfrmpswd = new System.Windows.Forms.TextBox();
            this.txtbx_pswdqstn = new System.Windows.Forms.TextBox();
            this.txtbx_username = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.btn_close2 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.btn_deleteuser);
            this.panel1.Controls.Add(this.btn_newuser);
            this.panel1.Controls.Add(this.txtbx_pswdanswr);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.listbx_availbleuser);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btn_crteuser);
            this.panel1.Controls.Add(this.txtbx_pswd);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.btn_close1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtbx_cnfrmpswd);
            this.panel1.Controls.Add(this.txtbx_pswdqstn);
            this.panel1.Controls.Add(this.txtbx_username);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(239, 33);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(403, 347);
            this.panel1.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(51, 269);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(324, 15);
            this.label8.TabIndex = 13;
            this.label8.Text = "( If you want to deactivate this function just leave this field empty)";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_deleteuser
            // 
            this.btn_deleteuser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_deleteuser.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_deleteuser.Image = ((System.Drawing.Image)(resources.GetObject("btn_deleteuser.Image")));
            this.btn_deleteuser.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_deleteuser.Location = new System.Drawing.Point(284, 110);
            this.btn_deleteuser.Name = "btn_deleteuser";
            this.btn_deleteuser.Size = new System.Drawing.Size(96, 25);
            this.btn_deleteuser.TabIndex = 18;
            this.btn_deleteuser.Text = "Delete User";
            this.btn_deleteuser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_deleteuser.UseVisualStyleBackColor = false;
            this.btn_deleteuser.Click += new System.EventHandler(this.btn_deleteuser_Click);
            // 
            // btn_newuser
            // 
            this.btn_newuser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_newuser.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newuser.Image = ((System.Drawing.Image)(resources.GetObject("btn_newuser.Image")));
            this.btn_newuser.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_newuser.Location = new System.Drawing.Point(284, 79);
            this.btn_newuser.Name = "btn_newuser";
            this.btn_newuser.Size = new System.Drawing.Size(96, 25);
            this.btn_newuser.TabIndex = 17;
            this.btn_newuser.Text = "New User";
            this.btn_newuser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_newuser.UseVisualStyleBackColor = false;
            this.btn_newuser.Click += new System.EventHandler(this.btn_newuser_Click);
            // 
            // txtbx_pswdanswr
            // 
            this.txtbx_pswdanswr.Location = new System.Drawing.Point(182, 287);
            this.txtbx_pswdanswr.Name = "txtbx_pswdanswr";
            this.txtbx_pswdanswr.Size = new System.Drawing.Size(193, 20);
            this.txtbx_pswdanswr.TabIndex = 12;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(34, 41);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 13);
            this.label11.TabIndex = 16;
            this.label11.Text = "Available User";
            // 
            // listbx_availbleuser
            // 
            this.listbx_availbleuser.FormattingEnabled = true;
            this.listbx_availbleuser.Location = new System.Drawing.Point(37, 57);
            this.listbx_availbleuser.Name = "listbx_availbleuser";
            this.listbx_availbleuser.Size = new System.Drawing.Size(231, 277);
            this.listbx_availbleuser.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 246);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(156, 23);
            this.label6.TabIndex = 11;
            this.label6.Text = "Password Answer:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(221, 26);
            this.label10.TabIndex = 14;
            this.label10.Text = "User Administration";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "New User";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_crteuser
            // 
            this.btn_crteuser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_crteuser.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_crteuser.Image = ((System.Drawing.Image)(resources.GetObject("btn_crteuser.Image")));
            this.btn_crteuser.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_crteuser.Location = new System.Drawing.Point(277, 313);
            this.btn_crteuser.Name = "btn_crteuser";
            this.btn_crteuser.Size = new System.Drawing.Size(98, 25);
            this.btn_crteuser.TabIndex = 10;
            this.btn_crteuser.Text = "Create User";
            this.btn_crteuser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_crteuser.UseVisualStyleBackColor = false;
            this.btn_crteuser.Click += new System.EventHandler(this.btn_crteuser_Click);
            // 
            // txtbx_pswd
            // 
            this.txtbx_pswd.Location = new System.Drawing.Point(182, 113);
            this.txtbx_pswd.Name = "txtbx_pswd";
            this.txtbx_pswd.PasswordChar = '*';
            this.txtbx_pswd.Size = new System.Drawing.Size(193, 20);
            this.txtbx_pswd.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(156, 23);
            this.label4.TabIndex = 5;
            this.label4.Text = "Confirm Password:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btn_close1
            // 
            this.btn_close1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_close1.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close1.Image = ((System.Drawing.Image)(resources.GetObject("btn_close1.Image")));
            this.btn_close1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_close1.Location = new System.Drawing.Point(182, 313);
            this.btn_close1.Name = "btn_close1";
            this.btn_close1.Size = new System.Drawing.Size(82, 25);
            this.btn_close1.TabIndex = 9;
            this.btn_close1.Text = "Close";
            this.btn_close1.UseVisualStyleBackColor = false;
            this.btn_close1.Click += new System.EventHandler(this.btn_close1_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(71, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 3;
            this.label3.Text = "Password:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(71, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Username:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtbx_cnfrmpswd
            // 
            this.txtbx_cnfrmpswd.Location = new System.Drawing.Point(182, 168);
            this.txtbx_cnfrmpswd.Name = "txtbx_cnfrmpswd";
            this.txtbx_cnfrmpswd.PasswordChar = '*';
            this.txtbx_cnfrmpswd.Size = new System.Drawing.Size(193, 20);
            this.txtbx_cnfrmpswd.TabIndex = 6;
            // 
            // txtbx_pswdqstn
            // 
            this.txtbx_pswdqstn.Location = new System.Drawing.Point(182, 224);
            this.txtbx_pswdqstn.Name = "txtbx_pswdqstn";
            this.txtbx_pswdqstn.Size = new System.Drawing.Size(193, 20);
            this.txtbx_pswdqstn.TabIndex = 8;
            // 
            // txtbx_username
            // 
            this.txtbx_username.Location = new System.Drawing.Point(182, 62);
            this.txtbx_username.Name = "txtbx_username";
            this.txtbx_username.Size = new System.Drawing.Size(193, 20);
            this.txtbx_username.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 199);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 23);
            this.label5.TabIndex = 7;
            this.label5.Text = "Password Question:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(-5, -1);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(254, 31);
            this.label7.TabIndex = 1;
            this.label7.Text = "User Administration";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(60, 76);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 24);
            this.label9.TabIndex = 2;
            this.label9.Text = "Actions";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.AntiqueWhite;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.radioButton2);
            this.panel2.Controls.Add(this.radioButton1);
            this.panel2.Location = new System.Drawing.Point(21, 103);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(194, 71);
            this.panel2.TabIndex = 3;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(13, 39);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(161, 20);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "User Administration";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(13, 14);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(109, 20);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Create User";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // btn_close2
            // 
            this.btn_close2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_close2.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close2.Image = ((System.Drawing.Image)(resources.GetObject("btn_close2.Image")));
            this.btn_close2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_close2.Location = new System.Drawing.Point(12, 347);
            this.btn_close2.Name = "btn_close2";
            this.btn_close2.Size = new System.Drawing.Size(82, 25);
            this.btn_close2.TabIndex = 19;
            this.btn_close2.Text = "Close";
            this.btn_close2.UseVisualStyleBackColor = false;
            this.btn_close2.Visible = false;
            this.btn_close2.Click += new System.EventHandler(this.btn_close2_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(632, 380);
            this.Controls.Add(this.btn_close2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel1);
            this.Name = "Form2";
            this.Text = "My Digital Diary - User Administration";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtbx_username;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtbx_pswd;
        private System.Windows.Forms.TextBox txtbx_pswdqstn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtbx_cnfrmpswd;
        private System.Windows.Forms.Button btn_crteuser;
        private System.Windows.Forms.Button btn_close1;
        private System.Windows.Forms.TextBox txtbx_pswdanswr;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.ListBox listbx_availbleuser;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btn_deleteuser;
        private System.Windows.Forms.Button btn_newuser;
        private System.Windows.Forms.Button btn_close2;
    }
}