﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.color1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.blck = new System.Windows.Forms.Label();
            this.wht = new System.Windows.Forms.Label();
            this.red = new System.Windows.Forms.Label();
            this.kn1 = new System.Windows.Forms.Label();
            this.kn2 = new System.Windows.Forms.Label();
            this.kn3 = new System.Windows.Forms.Label();
            this.dr = new System.Windows.Forms.Label();
            this.kn4 = new System.Windows.Forms.Label();
            this.kn12 = new System.Windows.Forms.Label();
            this.kn11 = new System.Windows.Forms.Label();
            this.kn10 = new System.Windows.Forms.Label();
            this.kn9 = new System.Windows.Forms.Label();
            this.kn8 = new System.Windows.Forms.Label();
            this.kn7 = new System.Windows.Forms.Label();
            this.kn6 = new System.Windows.Forms.Label();
            this.kn5 = new System.Windows.Forms.Label();
            this.kn20 = new System.Windows.Forms.Label();
            this.kn19 = new System.Windows.Forms.Label();
            this.kn18 = new System.Windows.Forms.Label();
            this.kn17 = new System.Windows.Forms.Label();
            this.kn16 = new System.Windows.Forms.Label();
            this.kn15 = new System.Windows.Forms.Label();
            this.kn14 = new System.Windows.Forms.Label();
            this.kn13 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.whtspce = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-1, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1921, 28);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-1, 23);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(2000, 98);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.click);
            // 
            // color1
            // 
            this.color1.BackColor = System.Drawing.Color.Black;
            this.color1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.color1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.color1.Location = new System.Drawing.Point(676, 29);
            this.color1.Name = "color1";
            this.color1.Size = new System.Drawing.Size(35, 35);
            this.color1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label1.Location = new System.Drawing.Point(676, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Color  1";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Location = new System.Drawing.Point(726, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 35);
            this.label3.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label4.Location = new System.Drawing.Point(726, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 29);
            this.label4.TabIndex = 6;
            this.label4.Text = "Color  2";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // blck
            // 
            this.blck.BackColor = System.Drawing.Color.Black;
            this.blck.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.blck.Location = new System.Drawing.Point(784, 30);
            this.blck.Name = "blck";
            this.blck.Size = new System.Drawing.Size(20, 20);
            this.blck.TabIndex = 7;
            this.blck.Click += new System.EventHandler(this.click);
            // 
            // wht
            // 
            this.wht.BackColor = System.Drawing.Color.White;
            this.wht.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.wht.Location = new System.Drawing.Point(810, 30);
            this.wht.Name = "wht";
            this.wht.Size = new System.Drawing.Size(20, 20);
            this.wht.TabIndex = 8;
            this.wht.Click += new System.EventHandler(this.click);
            // 
            // red
            // 
            this.red.BackColor = System.Drawing.Color.Red;
            this.red.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.red.Location = new System.Drawing.Point(836, 30);
            this.red.Name = "red";
            this.red.Size = new System.Drawing.Size(20, 20);
            this.red.TabIndex = 9;
            this.red.Click += new System.EventHandler(this.click);
            // 
            // kn1
            // 
            this.kn1.BackColor = System.Drawing.Color.Maroon;
            this.kn1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn1.Location = new System.Drawing.Point(862, 30);
            this.kn1.Name = "kn1";
            this.kn1.Size = new System.Drawing.Size(20, 20);
            this.kn1.TabIndex = 10;
            this.kn1.Click += new System.EventHandler(this.click);
            // 
            // kn2
            // 
            this.kn2.BackColor = System.Drawing.Color.DarkRed;
            this.kn2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn2.Location = new System.Drawing.Point(888, 30);
            this.kn2.Name = "kn2";
            this.kn2.Size = new System.Drawing.Size(20, 20);
            this.kn2.TabIndex = 11;
            this.kn2.Click += new System.EventHandler(this.click);
            // 
            // kn3
            // 
            this.kn3.BackColor = System.Drawing.Color.DarkRed;
            this.kn3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn3.Location = new System.Drawing.Point(914, 30);
            this.kn3.Name = "kn3";
            this.kn3.Size = new System.Drawing.Size(20, 20);
            this.kn3.TabIndex = 12;
            this.kn3.Click += new System.EventHandler(this.click);
            // 
            // dr
            // 
            this.dr.BackColor = System.Drawing.Color.OrangeRed;
            this.dr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dr.Location = new System.Drawing.Point(940, 30);
            this.dr.Name = "dr";
            this.dr.Size = new System.Drawing.Size(20, 20);
            this.dr.TabIndex = 13;
            this.dr.Click += new System.EventHandler(this.click);
            // 
            // kn4
            // 
            this.kn4.BackColor = System.Drawing.Color.Chocolate;
            this.kn4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn4.Location = new System.Drawing.Point(966, 30);
            this.kn4.Name = "kn4";
            this.kn4.Size = new System.Drawing.Size(20, 20);
            this.kn4.TabIndex = 14;
            this.kn4.Click += new System.EventHandler(this.click);
            // 
            // kn12
            // 
            this.kn12.BackColor = System.Drawing.Color.YellowGreen;
            this.kn12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn12.Location = new System.Drawing.Point(966, 50);
            this.kn12.Name = "kn12";
            this.kn12.Size = new System.Drawing.Size(20, 20);
            this.kn12.TabIndex = 22;
            this.kn12.Click += new System.EventHandler(this.click);
            // 
            // kn11
            // 
            this.kn11.BackColor = System.Drawing.Color.MintCream;
            this.kn11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn11.Location = new System.Drawing.Point(940, 50);
            this.kn11.Name = "kn11";
            this.kn11.Size = new System.Drawing.Size(20, 20);
            this.kn11.TabIndex = 21;
            this.kn11.Click += new System.EventHandler(this.click);
            // 
            // kn10
            // 
            this.kn10.BackColor = System.Drawing.Color.DarkViolet;
            this.kn10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn10.Location = new System.Drawing.Point(914, 50);
            this.kn10.Name = "kn10";
            this.kn10.Size = new System.Drawing.Size(20, 20);
            this.kn10.TabIndex = 20;
            this.kn10.Click += new System.EventHandler(this.click);
            // 
            // kn9
            // 
            this.kn9.BackColor = System.Drawing.Color.Fuchsia;
            this.kn9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn9.Location = new System.Drawing.Point(888, 50);
            this.kn9.Name = "kn9";
            this.kn9.Size = new System.Drawing.Size(20, 20);
            this.kn9.TabIndex = 19;
            this.kn9.Click += new System.EventHandler(this.click);
            // 
            // kn8
            // 
            this.kn8.BackColor = System.Drawing.Color.Orchid;
            this.kn8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn8.Location = new System.Drawing.Point(862, 50);
            this.kn8.Name = "kn8";
            this.kn8.Size = new System.Drawing.Size(20, 20);
            this.kn8.TabIndex = 18;
            this.kn8.Click += new System.EventHandler(this.click);
            // 
            // kn7
            // 
            this.kn7.BackColor = System.Drawing.Color.Crimson;
            this.kn7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn7.Location = new System.Drawing.Point(836, 50);
            this.kn7.Name = "kn7";
            this.kn7.Size = new System.Drawing.Size(20, 20);
            this.kn7.TabIndex = 17;
            this.kn7.Click += new System.EventHandler(this.click);
            // 
            // kn6
            // 
            this.kn6.BackColor = System.Drawing.Color.Pink;
            this.kn6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn6.Location = new System.Drawing.Point(810, 50);
            this.kn6.Name = "kn6";
            this.kn6.Size = new System.Drawing.Size(20, 20);
            this.kn6.TabIndex = 16;
            this.kn6.Click += new System.EventHandler(this.click);
            // 
            // kn5
            // 
            this.kn5.BackColor = System.Drawing.Color.LightPink;
            this.kn5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn5.Location = new System.Drawing.Point(784, 50);
            this.kn5.Name = "kn5";
            this.kn5.Size = new System.Drawing.Size(20, 20);
            this.kn5.TabIndex = 15;
            this.kn5.Click += new System.EventHandler(this.click);
            // 
            // kn20
            // 
            this.kn20.BackColor = System.Drawing.Color.Khaki;
            this.kn20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn20.Location = new System.Drawing.Point(966, 71);
            this.kn20.Name = "kn20";
            this.kn20.Size = new System.Drawing.Size(20, 20);
            this.kn20.TabIndex = 30;
            this.kn20.Click += new System.EventHandler(this.click);
            // 
            // kn19
            // 
            this.kn19.BackColor = System.Drawing.Color.Gold;
            this.kn19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn19.Location = new System.Drawing.Point(940, 71);
            this.kn19.Name = "kn19";
            this.kn19.Size = new System.Drawing.Size(20, 20);
            this.kn19.TabIndex = 29;
            this.kn19.Click += new System.EventHandler(this.click);
            // 
            // kn18
            // 
            this.kn18.BackColor = System.Drawing.Color.Yellow;
            this.kn18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn18.Location = new System.Drawing.Point(914, 71);
            this.kn18.Name = "kn18";
            this.kn18.Size = new System.Drawing.Size(20, 20);
            this.kn18.TabIndex = 28;
            this.kn18.Click += new System.EventHandler(this.click);
            // 
            // kn17
            // 
            this.kn17.BackColor = System.Drawing.Color.OliveDrab;
            this.kn17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn17.Location = new System.Drawing.Point(888, 71);
            this.kn17.Name = "kn17";
            this.kn17.Size = new System.Drawing.Size(20, 20);
            this.kn17.TabIndex = 27;
            this.kn17.Click += new System.EventHandler(this.click);
            // 
            // kn16
            // 
            this.kn16.BackColor = System.Drawing.Color.OliveDrab;
            this.kn16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn16.Location = new System.Drawing.Point(862, 71);
            this.kn16.Name = "kn16";
            this.kn16.Size = new System.Drawing.Size(20, 20);
            this.kn16.TabIndex = 26;
            this.kn16.Click += new System.EventHandler(this.click);
            // 
            // kn15
            // 
            this.kn15.BackColor = System.Drawing.Color.Indigo;
            this.kn15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn15.Location = new System.Drawing.Point(836, 71);
            this.kn15.Name = "kn15";
            this.kn15.Size = new System.Drawing.Size(20, 20);
            this.kn15.TabIndex = 25;
            this.kn15.Click += new System.EventHandler(this.click);
            // 
            // kn14
            // 
            this.kn14.BackColor = System.Drawing.Color.LightSteelBlue;
            this.kn14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn14.Location = new System.Drawing.Point(810, 71);
            this.kn14.Name = "kn14";
            this.kn14.Size = new System.Drawing.Size(20, 20);
            this.kn14.TabIndex = 24;
            this.kn14.Click += new System.EventHandler(this.click);
            // 
            // kn13
            // 
            this.kn13.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.kn13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.kn13.Location = new System.Drawing.Point(784, 71);
            this.kn13.Name = "kn13";
            this.kn13.Size = new System.Drawing.Size(20, 20);
            this.kn13.TabIndex = 23;
            this.kn13.Click += new System.EventHandler(this.click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(1001, 29);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(48, 82);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 31;
            this.pictureBox3.TabStop = false;
            // 
            // whtspce
            // 
            this.whtspce.BackColor = System.Drawing.SystemColors.Window;
            this.whtspce.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.whtspce.Cursor = System.Windows.Forms.Cursors.Hand;
            this.whtspce.Location = new System.Drawing.Point(-1, 124);
            this.whtspce.Name = "whtspce";
            this.whtspce.Size = new System.Drawing.Size(1921, 538);
            this.whtspce.TabIndex = 32;
            this.whtspce.MouseClick += new System.Windows.Forms.MouseEventHandler(this.whtspce_MouseClick);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(0, 630);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(1362, 27);
            this.pictureBox4.TabIndex = 33;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(0, 610);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(1362, 20);
            this.pictureBox5.TabIndex = 34;
            this.pictureBox5.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1362, 657);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.whtspce);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.kn20);
            this.Controls.Add(this.kn19);
            this.Controls.Add(this.kn18);
            this.Controls.Add(this.kn17);
            this.Controls.Add(this.kn16);
            this.Controls.Add(this.kn15);
            this.Controls.Add(this.kn14);
            this.Controls.Add(this.kn13);
            this.Controls.Add(this.kn12);
            this.Controls.Add(this.kn11);
            this.Controls.Add(this.kn10);
            this.Controls.Add(this.kn9);
            this.Controls.Add(this.kn8);
            this.Controls.Add(this.kn7);
            this.Controls.Add(this.kn6);
            this.Controls.Add(this.kn5);
            this.Controls.Add(this.kn4);
            this.Controls.Add(this.dr);
            this.Controls.Add(this.kn3);
            this.Controls.Add(this.kn2);
            this.Controls.Add(this.kn1);
            this.Controls.Add(this.red);
            this.Controls.Add(this.wht);
            this.Controls.Add(this.blck);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.color1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Paint";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label color1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label blck;
        private System.Windows.Forms.Label wht;
        private System.Windows.Forms.Label red;
        private System.Windows.Forms.Label kn1;
        private System.Windows.Forms.Label kn2;
        private System.Windows.Forms.Label kn3;
        private System.Windows.Forms.Label dr;
        private System.Windows.Forms.Label kn4;
        private System.Windows.Forms.Label kn12;
        private System.Windows.Forms.Label kn11;
        private System.Windows.Forms.Label kn10;
        private System.Windows.Forms.Label kn9;
        private System.Windows.Forms.Label kn8;
        private System.Windows.Forms.Label kn7;
        private System.Windows.Forms.Label kn6;
        private System.Windows.Forms.Label kn5;
        private System.Windows.Forms.Label kn20;
        private System.Windows.Forms.Label kn19;
        private System.Windows.Forms.Label kn18;
        private System.Windows.Forms.Label kn17;
        private System.Windows.Forms.Label kn16;
        private System.Windows.Forms.Label kn15;
        private System.Windows.Forms.Label kn14;
        private System.Windows.Forms.Label kn13;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label whtspce;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;


    }
}

